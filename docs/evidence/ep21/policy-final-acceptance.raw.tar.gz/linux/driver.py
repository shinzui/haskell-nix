import json,subprocess,time,hashlib
from pathlib import Path
revision='2565350fded53dcb5753d3974f841789fed60595'
before='22bca73ced6dd20e32c74812878dacba4c1fc6aa'
root=Path('/tmp/ep21-retirement-final-linux-'+revision[:7]);root.mkdir(exist_ok=False)
results=[]
def run(name,command,output=None):
 start=time.monotonic()
 with (root/(name+'.log')).open('w') as log:
  if output:
   with output.open('w') as out: r=subprocess.run(command,stdout=out,stderr=log)
  else:r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
 result={'name':name,'command':command,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-start};results.append(result)
 (root/'progress.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(result),flush=True)
 if r.returncode:raise SystemExit(r.returncode)
for label,selected in [('before',before),('after',revision)]:
 apply='f: f {root="/workspace";system="x86_64-linux";revision='+json.dumps(selected)+';}'
 run('cohort-'+label,['nix','eval','--impure','--json','--file','/tmp/ep21-retirement-cohort-identities.nix','--apply',apply,'--max-jobs','0','--builders',''],root/('cohort-'+label+'.json'))
assert json.loads((root/'cohort-before.json').read_text())==json.loads((root/'cohort-after.json').read_text())
for label,selected in [('before',before),('after',revision)]:
 apply='f: f {root='+json.dumps('git+file:///workspace?rev='+selected)+';system="x86_64-linux";}'
 run('retained-reports-'+label,['nix','eval','--impure','--json','--file','/tmp/ep21-runtime-3-reports.nix','--apply',apply,'--max-jobs','0','--builders',''],root/('retained-reports-'+label+'.json'))
assert json.loads((root/'retained-reports-before.json').read_text())==json.loads((root/'retained-reports-after.json').read_text())
apply='f: f {root='+json.dumps('git+file:///workspace?rev='+revision)+';system="x86_64-linux";}'
run('retained-identities',['nix','eval','--impure','--json','--file','/tmp/ep21-runtime-3-identity-matrix.nix','--apply',apply,'--max-jobs','0','--builders',''],root/'retained-identities.json')
assert json.loads(Path('/tmp/ep21-runtime-3-linux-identities.json').read_text())==json.loads((root/'retained-identities.json').read_text())
run('full-flake-check',['nix','flake','check','git+file:///workspace?rev='+revision,'--print-build-logs','--no-update-lock-file','--max-jobs','1','--cores','8','--builders',''])
(root/'receipt.json').write_text(json.dumps({'revision':revision,'before_revision':before,'status':'passed','cohort':{'cells':4,'packages_per_cell':370,'compiler_and_recipes_equal':True},'history':{'generations':[1,2,3],'channels':['github','hackage'],'owned_entries':311,'derivations':274,'explicit_absences':37,'identities_unchanged':True,'generation_3_reports_unchanged':True},'results':results,'execution':'User-selected translated Apple amd64 Linux guest; independent warm store, read-only source; sandbox=false/filter-syscalls=false. No physical-x86 performance or fresh-worker claim.'},indent=2)+'\n')
print('EP21_FINAL_RETIREMENT_LINUX_PASSED',flush=True)

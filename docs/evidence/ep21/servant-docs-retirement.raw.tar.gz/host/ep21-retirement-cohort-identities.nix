{ root, revision ? null, system }:
let
  c = builtins.getFlake (if revision == null then root else "git+file://${root}?rev=${revision}");
  lib = c.inputs.nixpkgs.lib;
  pkgs = import c.inputs.nixpkgs { inherit system; };
  generated = builtins.attrNames (import (c.outPath + "/generated/cohort-versions.nix")).packages;
in lib.genAttrs [ "github" "hackage" ] (channel:
  lib.genAttrs [ "ghc9124" "ghc9141" ] (compiler:
    let scope = pkgs.haskell.packages.${compiler}.override {
      overrides = c.lib.haskellExtensions.${channel} pkgs.haskell.lib.compose pkgs;
    }; in {
      compiler = scope.ghc.drvPath;
      packages = lib.genAttrs generated (name: scope.${name}.drvPath);
    }))

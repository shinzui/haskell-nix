import datetime,hashlib,json,subprocess,time,traceback
from pathlib import Path
out=Path('/tmp/ep21-linux-retained-matrix-v3');out.mkdir(exist_ok=False)
rows=[]
try:
 for kind,selectors in [('retained',[(c,g) for c in ['github','hackage'] for g in ['1','2']])]:
  for channel,selector in selectors:
   observations={}
   for label,revision in [('before','03e159c82728de215bfc4b4a0fd6a5bd902c3b01'),('after','903c93ee40fc131b94f07506f290750d8ba376fc')]:
    attr=f'{kind}.x86_64-linux.{channel}."{selector}"'
    command=['nix','eval','--json','--impure','--file','/tmp/ep21-linux-migration-identities.nix','--argstr','channelPath','/workspace','--argstr','revision',revision,'--apply','value: value.'+attr,'--max-jobs','1','--cores','8','--builders','']
    started=time.monotonic();run=subprocess.run(command,capture_output=True);elapsed=time.monotonic()-started
    prefix=f'{kind}-{channel}-{selector}-{label}';(out/(prefix+'.stdout.json')).write_bytes(run.stdout);(out/(prefix+'.stderr.log')).write_bytes(run.stderr)
    observation={'command':command,'exit_code':run.returncode,'elapsed_seconds':elapsed,'stdout_sha256':hashlib.sha256(run.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(run.stderr).hexdigest()}
    if run.returncode:raise RuntimeError(prefix+' failed; see raw log')
    observation['value']=json.loads(run.stdout);observations[label]=observation
   before,after=observations['before']['value'],observations['after']['value']
   assert before==after,(kind,channel,selector,'identity or applicability changed')
   packages=after if kind=='current' else after['packages'];counts={}
   for package in packages.values():counts[package['status']]=counts.get(package['status'],0)+1
   row={'kind':kind,'channel':channel,'selector':selector,'observations':observations,'equal':True,'status_counts':counts};rows.append(row)
   print(kind,channel,selector,'unchanged',counts,flush=True)
 result={'schema_version':1,'before_revision':'03e159c82728de215bfc4b4a0fd6a5bd902c3b01','after_revision':'903c93ee40fc131b94f07506f290750d8ba376fc','observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'system':'x86_64-linux','execution':'User-selected Apple amd64 container with translation; sandbox=false/filter-syscalls=false. Identity/guard queries only, no package-test or physical-x86 performance claim.','cells':rows,'status':'passed'}
 (out/'receipt.json').write_text(json.dumps(result,indent=2)+'\n');Path('/tmp/ep21-linux-retained-matrix-v3.status').write_text('0\n')
except BaseException:
 traceback.print_exc();(out/'partial.json').write_text(json.dumps(rows,indent=2)+'\n');Path('/tmp/ep21-linux-retained-matrix-v3.status').write_text('1\n');raise

{ revision ? null, channelPath ? "/Users/shinzui/Keikaku/bokuno/haskell-nix" }:
let
  channel = builtins.getFlake (if revision == null then channelPath else "git+file://${channelPath}?rev=${revision}");
  lib = channel.inputs.nixpkgs.lib;
  systems = [ "aarch64-darwin" "x86_64-linux" ];
  channels = [ "github" "hackage" ];
  compilers = [ "ghc9124" "ghc9141" ];
  identify = names: scope: lib.genAttrs names (name:
    let result = builtins.tryEval (if scope.${name} == null then null else scope.${name}.drvPath);
    in if result.success then { status = if result.value == null then "absent" else "evaluated"; identity = result.value; }
    else { status = "blocked-by-evaluation-guard"; identity = null; });
  current = lib.genAttrs systems (system:
    let pkgs = import channel.inputs.nixpkgs { inherit system; };
    in lib.genAttrs channels (sourceChannel:
      lib.genAttrs compilers (compiler:
        let scope = pkgs.haskell.packages.${compiler}.override {
          overrides = channel.lib.haskellExtensions.${sourceChannel} pkgs.haskell.lib.compose pkgs;
        }; in identify (builtins.attrNames channel.lib.registries.${sourceChannel}) scope)));
  retained = lib.genAttrs systems (system:
    let pkgs = import channel.inputs.nixpkgs { inherit system; };
    in lib.genAttrs channels (sourceChannel:
      lib.genAttrs [ "1" "2" ] (generation:
        let record = builtins.head (builtins.filter (record: record.generation == builtins.fromJSON generation) channel.lib.runtimePackageSets.keiro-runtime);
        runtime = channel.lib.mkRuntimePackageSet {
          runtime = "keiro-runtime";
          generation = builtins.fromJSON generation;
          channel = sourceChannel;
          inherit (record) applicationSelections;
        };
        scope = runtime.mkApplicationScope pkgs (_: _: { });
        in {
          fingerprint = runtime.metadata.fingerprint;
          compiler = scope.ghc.drvPath;
          packages = identify (builtins.attrNames runtime.metadata.ownership) scope;
        })));
in { inherit current retained; }

import datetime,hashlib,json,subprocess,time,traceback
from pathlib import Path
out=Path('/tmp/ep21-linux-construction-capture');out.mkdir(exist_ok=False)
revision='903c93ee40fc131b94f07506f290750d8ba376fc'
try:
 command=['nix','build','--no-link','--json','git+file:///workspace?rev='+revision+'#haskell-nix-update','--max-jobs','1','--cores','8','--builders','','-L']
 started=time.monotonic()
 with (out/'updater-build.json').open('w') as stdout,(out/'updater-build.log').open('w') as stderr:run=subprocess.run(command,stdout=stdout,stderr=stderr)
 assert run.returncode==0,'updater realization failed'
 build={'command':command,'exit_code':run.returncode,'elapsed_seconds':time.monotonic()-started}
 binary=json.loads((out/'updater-build.json').read_text())[0]['outputs']['out']+'/bin/haskell-nix-update'
 cells=[]
 for compiler in ['ghc9124','ghc9141']:
  for channel in ['github','hackage']:
   expression='let flake = builtins.getFlake "git+file:///workspace?rev='+revision+'"; pkgs = import flake.inputs.nixpkgs { system = "x86_64-linux"; }; in import (flake.outPath + "/checks/compatibility-capture.nix") { lib = pkgs.lib; inherit pkgs; mkFirstPartyPackageSet = flake.lib.mkFirstPartyPackageSet; compiler = '+json.dumps(compiler)+'; channel = '+json.dumps(channel)+'; }'
   command=['nix','eval','--impure','--json','--expr',expression,'--max-jobs','1','--cores','8','--builders','']
   started=time.monotonic();run=subprocess.run(command,capture_output=True);elapsed=time.monotonic()-started;key=channel+'-'+compiler
   (out/(key+'.json')).write_bytes(run.stdout);(out/(key+'.log')).write_bytes(run.stderr);assert run.returncode==0,key+' construction failed'
   data=json.loads(run.stdout);assert all(p['ordinary']==p['captured'] for p in data['identities'].values());assert not data['report']['problems']
   context=out/(key+'-context.json');context.write_text(json.dumps(data['report'],indent=2)+'\n')
   check=[binary,'compatibility','check','--context',str(context)];checked=subprocess.run(check,capture_output=True);(out/(key+'-check.log')).write_bytes(checked.stdout+checked.stderr);assert checked.returncode==0,key+' CLI check failed'
   cells.append({'compiler':compiler,'channel':channel,'command':command,'elapsed_seconds':elapsed,'context_sha256':hashlib.sha256(context.read_bytes()).hexdigest(),'identities':data['identities'],'entries':len(data['report']['entries']),'check_command':check,'check_exit_code':checked.returncode})
   print(key,'capture and native CLI check passed',flush=True)
 result={'schema_version':1,'system':'x86_64-linux','revision':revision,'updater_build':build,'cells':cells,'status':'passed','qualification':'User-selected Apple translated amd64 guest. Exact diagnostic/ordinary recipe identities and native report/check interchange only; source assertions, package tests and individual workaround necessity remain unverified.'}
 (out/'receipt.json').write_text(json.dumps(result,indent=2)+'\n');Path('/tmp/ep21-linux-construction-capture.status').write_text('0\n')
except BaseException:
 traceback.print_exc();Path('/tmp/ep21-linux-construction-capture.status').write_text('1\n');raise

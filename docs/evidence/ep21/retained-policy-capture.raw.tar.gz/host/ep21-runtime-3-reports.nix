{ root, system }:
let c = builtins.getFlake root;
    pkgs = import c.inputs.nixpkgs { inherit system; };
in c.inputs.nixpkgs.lib.genAttrs [ "github" "hackage" ] (channel:
  (import (c.outPath + "/checks/runtime-compatibility.nix") {
    lib = c.inputs.nixpkgs.lib;
    inherit pkgs channel;
    updater = c.packages.${system}.haskell-nix-update;
    mkRuntimePackageSet = c.lib.mkRuntimePackageSet;
  }).report)

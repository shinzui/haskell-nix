{ root, system }:
let
  channel = builtins.getFlake root;
  lib = channel.inputs.nixpkgs.lib;
  pkgs = import channel.inputs.nixpkgs { inherit system; };
in
lib.genAttrs [ "github" "hackage" ] (sourceChannel:
  lib.genAttrs [ "1" "2" "3" ] (generation:
    let
      record = builtins.head (builtins.filter
        (record: record.generation == builtins.fromJSON generation)
        channel.lib.runtimePackageSets.keiro-runtime);
      selected = channel.lib.mkRuntimePackageSet {
        runtime = "keiro-runtime";
        generation = builtins.fromJSON generation;
        channel = sourceChannel;
        inherit (record) applicationSelections;
      };
      scope = selected.mkApplicationScope pkgs (_: _: { });
    in {
      fingerprint = selected.metadata.fingerprint;
      compiler = scope.ghc.drvPath;
      packages = lib.genAttrs (builtins.attrNames selected.metadata.ownership)
        (name: if scope.${name} == null then null else scope.${name}.drvPath);
      bytestringLexing = {
        derivation = scope.bytestring-lexing.drvPath;
        selection = scope.bytestring-lexing.cohortBuildPolicySelection or null;
      };
    }))

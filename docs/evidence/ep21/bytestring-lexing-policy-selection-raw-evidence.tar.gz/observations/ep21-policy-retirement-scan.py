import json
import subprocess
import time
from pathlib import Path

out = Path("/tmp/ep21-policy-retirement-scan")
out.mkdir(exist_ok=False)
template = """
let
  flake = builtins.getFlake (toString /Users/shinzui/Keikaku/bokuno/haskell-nix);
  pkgs = import flake.inputs.nixpkgs { system = "aarch64-darwin"; };
  selected = flake.lib.mkFirstPartyPackageSet {
    packageSet = "default"; channel = SOURCE_CHANNEL; captureCompatibility = true;
  };
  scope = pkgs.haskell.packages.COMPILER.override {
    overrides = selected.haskellExtension pkgs.haskell.lib.compose pkgs;
  };
  names = builtins.filter (name: name != "retrie")
    (builtins.attrNames flake.lib.registries.SOURCE_CHANNEL);
  report = flake.lib.capturedCompatibilityReport {
    inherit scope names; packageSet = "default"; channel = SOURCE_CHANNEL;
    system = "aarch64-darwin";
  };
in {
  inherit (report) inputIdentity policyIdentity problems;
  candidates = builtins.filter (entry: entry.retirementCandidate) report.entries;
  entries = map (entry: {
    inherit (entry) id package status retirementCandidate;
  }) report.entries;
  excluded = [ "retrie: unchanged pre-existing broken-package guard" ];
}
"""
for compiler in ["ghc9124", "ghc9141"]:
    for channel in ["github", "hackage"]:
        expression = template.replace("SOURCE_CHANNEL", json.dumps(channel)).replace("COMPILER", compiler)
        command = ["nix", "eval", "--impure", "--json", "--expr", expression, "--max-jobs", "1", "--builders", ""]
        started = time.monotonic()
        run = subprocess.run(command, capture_output=True)
        key = channel + "-" + compiler
        (out / (key + ".json")).write_bytes(run.stdout)
        (out / (key + ".log")).write_bytes(run.stderr)
        if run.returncode:
            print(key, "failed; inspect raw log", flush=True)
            raise SystemExit(run.returncode)
        data = json.loads(run.stdout)
        print(key, "entries", len(data["entries"]), "candidates",
              [(e["id"], e["package"]) for e in data["candidates"]],
              "problems", data["problems"], "seconds", time.monotonic() - started, flush=True)

from pathlib import Path
import json,subprocess,tempfile,time
worker=Path(tempfile.mkdtemp(prefix='ep19-linux-cache-worker-',dir='/tmp')).resolve()
python='/nix/store/b5bpi6zfajzzrwwpgba2q6li3nnya4bs-python3-3.14.7/bin/python3'
cmd=[python,'/tmp/ep19-cohort-cache.py','verify','--receipt','/tmp/ep19-retained-cache-linux-publication.json','--store','local?root='+str(worker),'--evidence','/tmp/ep19-retained-cache-linux-substitution.json'];start=time.perf_counter()
with Path('/tmp/ep19-retained-cache-linux-substitution.log').open('w') as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
Path('/tmp/ep19-retained-cache-linux-substitution-driver.json').write_text(json.dumps({'command':cmd,'exit_code':r.returncode,'elapsed_seconds':time.perf_counter()-start,'scope':'New empty alternate store in translated x86_64 Linux Apple guest; existing owner verifies exact published closure with builds disabled.'},indent=2)+'\n');raise SystemExit(r.returncode)

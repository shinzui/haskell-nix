{
  inputs.channel.url = "git+file:///Users/shinzui/Keikaku/bokuno/haskell-nix?rev=3453274d8dd718c016549b64f8cc3d8345864220";
  inputs.rei = {
    url = "path:/tmp/ep18-rei-resource-aware-split-v2/baseline";
    flake = false;
  };
  outputs = { channel, rei, ... }:
    let
      forSystem = system:
        let
          p = import channel.inputs.nixpkgs { inherit system; };
          h = p.haskell.lib.compose;
          mk = import (channel + "/lib/mkRuntimePackageSet.nix") { lib = p.lib; root = channel.outPath; };
          input = builtins.fromJSON (builtins.readFile (rei + "/nix/runtime-selection.json"));
          selected = mk (input // { generation = 4; channel = "github"; });
          app = import (rei + "/nix/haskell-overlay.nix") {
            pkgs = p; haskellLib = h; gitRev = "bad0388"; sourceRoot = rei.outPath;
          };
          consumer = (selected.mkApplicationScope p app).rei-cli;
          expected = {
            aarch64-darwin = "/nix/store/l6afxry8yviihkab53lb13n3awn371iy-rei-cli-7.1.0.0.drv";
            x86_64-linux = "/nix/store/gswfags3naialnr46c7dqhbcy0sv4xiy-rei-cli-7.1.0.0.drv";
          };
        in { default = assert consumer.drvPath == expected.${system}; consumer; };
    in { packages = builtins.listToAttrs (map (system: { name = system; value = forSystem system; }) [ "aarch64-darwin" "x86_64-linux" ]); };
}

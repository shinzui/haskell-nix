module Main (main) where

import CohortModelTest qualified
import CohortCompareTest qualified
import CohortGenerateTest qualified
import CohortGenerateIOTest qualified
import CohortRecipesTest qualified
import CohortRecipeArtifactsTest qualified
import CohortTest qualified
import CompatibilityTest qualified
import CompatibilityVerifyTest qualified
import AdapterTest qualified
import Data.ByteString qualified as ByteString
import Data.ByteString.Lazy qualified as LazyByteString
import Data.Text (Text)
import HaskellNix.Update.Catalog (decodeFamilyCatalog, encodeFamilyCatalog)
import HaskellNix.Update.Cli
import HaskellNix.Update.Cohort.Cli (CohortCommand (..))
import HaskellNix.Update.PackageLock (decodePackageLock, decodePackageLockForRefresh, encodePackageLock)
import HaskellNix.Update.Types (FamilyCatalog, FamilyName (..), PackageLock (..), RefreshTarget (..), SnapshotGeneration (..), UpdateGroupName (..))
import Options.Applicative (ParserResult (..), defaultPrefs, execParserPure)
import Paths_haskell_nix_update (getDataFileName)
import PackageSetTest qualified
import PlannerTest qualified
import Test.Tasty (TestTree, defaultMain, testGroup)
import Test.Tasty.HUnit (assertBool, assertFailure, testCase, (@?=))
import RuntimeTest qualified
import WorkflowTest qualified

main :: IO ()
main = defaultMain tests

tests :: TestTree
tests =
  testGroup
    "haskell-nix-update"
    [ CompatibilityVerifyTest.tests,
      CompatibilityTest.tests,
      RuntimeTest.tests,
      CohortModelTest.tests,
      CohortCompareTest.tests,
      CohortGenerateTest.tests,
      CohortGenerateIOTest.tests,
      CohortRecipesTest.tests,
      CohortRecipeArtifactsTest.tests,
      CohortTest.tests,
      catalogTests,
      packageLockTests,
      PackageSetTest.tests,
      cliTests,
      AdapterTest.tests,
      PlannerTest.tests,
      WorkflowTest.tests
    ]

catalogTests :: TestTree
catalogTests =
  testGroup
    "family catalog"
    [ testCase "valid fixture round-trips canonically" $ do
        bytes <- readFixture "valid/config.json"
        catalog <- assertRight (decodeFamilyCatalog bytes)
        let encoded = encodeFamilyCatalog catalog
        assertTrailingNewline encoded
        decodeFamilyCatalog (LazyByteString.toStrict encoded) @?= Right catalog,
      testCase "duplicate families are rejected" $
        assertInvalidCatalog "invalid/config-duplicate-family.json",
      testCase "unknown override keys are rejected" $
        assertInvalidCatalog "invalid/config-unknown-override-key.json",
      testCase "excluding an overridden package is rejected" $
        assertInvalidCatalog "invalid/config-excluded-and-overridden.json"
    ]

packageLockTests :: TestTree
packageLockTests =
  testGroup
    "package lock"
    [ testCase "valid fixture round-trips canonically" $ do
        catalog <- readValidCatalog
        bytes <- readFixture "valid/lock.json"
        packageLock <- assertRight (decodePackageLock catalog bytes)
        let encoded = encodePackageLock packageLock
        assertTrailingNewline encoded
        decodePackageLock catalog (LazyByteString.toStrict encoded) @?= Right packageLock,
      testCase "refresh accepts a lock missing newly configured families" $ do
        catalog <- readValidCatalog
        let bytes = LazyByteString.toStrict (encodePackageLock (PackageLock 1 []))
        assertLeft (decodePackageLock catalog bytes)
        decodePackageLockForRefresh catalog bytes @?= Right (PackageLock 1 []),
      testGroup
        "invalid EP-1 fixtures"
        [ testCase fileName (assertInvalidLock fileName)
          | fileName <-
              [ "invalid/lock-absolute-path.json",
                "invalid/lock-parent-path.json",
                "invalid/lock-dot-segment-path.json",
                "invalid/lock-mismatched-family.json",
                "invalid/lock-mismatched-input.json",
                "invalid/lock-malformed-version.json",
                "invalid/lock-malformed-hash.json",
                "invalid/lock-duplicate-package.json"
              ]
        ]
    ]

cliTests :: TestTree
cliTests =
  testGroup
    "CLI parser"
    [ testCase "cohort lock lookup accepts a nested input path" $
        case execParserPure defaultPrefs parserInfo ["cohort", "resolve-channel-lock", "--lock", "consumer.lock", "--input-path", "application/library/haskell-nix"] of
          Success (Cohort (CohortResolveChannelLock lockPath inputPath)) -> do
            lockPath @?= "consumer.lock"
            inputPath @?= "application/library/haskell-nix"
          other -> assertFailure ("unexpected parser result: " <> show other),
      testCase "refresh accepts package-set, mixed scope, profile, and dry-run" $
        case execParserPure defaultPrefs parserInfo ["refresh", "--package-set", "candidate", "--family", "alpha", "--group", "runtime", "--compatibility-profile", "legacy", "--dry-run"] of
          Success (Refresh RefreshOptions {packageSet, targets, compatibilityProfile, dryRun}) -> do
            packageSet @?= Just "candidate"
            targets @?= [TargetFamily (FamilyName "alpha"), TargetGroup (UpdateGroupName "runtime")]
            compatibilityProfile @?= Just "legacy"
            dryRun @?= True
          other -> assertFailure ("unexpected parser result: " <> show other),
      testCase "check defaults to all families and offline" $
        case execParserPure defaultPrefs parserInfo ["check"] of
          Success (Check CheckOptions {packageSet, targets, online}) -> do
            packageSet @?= Nothing
            targets @?= []
            online @?= False
          other -> assertFailure ("unexpected parser result: " <> show other),
      testCase "migrate-lock parses named historical imports" $
        case execParserPure defaultPrefs parserInfo ["migrate-lock", "--package-set", "stable", "--import-set", "old=HEAD~1", "--dry-run"] of
          Success (MigrateLock MigrateOptions {packageSet, importSets, dryRun}) -> do
            packageSet @?= "stable"
            importSets @?= [("old", "HEAD~1")]
            dryRun @?= True
          other -> assertFailure ("unexpected parser result: " <> show other),
      testCase "package-set select requires one selection source" $
        case execParserPure defaultPrefs parserInfo ["package-set", "select", "--package-set", "candidate", "--group", "runtime", "--generation", "3"] of
          Success (PackageSetCommand (SelectPackageSetGroup packageSet group selection dryRun)) -> do
            packageSet @?= "candidate"
            group @?= UpdateGroupName "runtime"
            selection @?= Left (SnapshotGeneration 3)
            dryRun @?= False
          other -> assertFailure ("unexpected parser result: " <> show other)
    ]

assertInvalidCatalog :: FilePath -> IO ()
assertInvalidCatalog fileName = do
  bytes <- readFixture fileName
  assertLeft (decodeFamilyCatalog bytes)

assertInvalidLock :: FilePath -> IO ()
assertInvalidLock fileName = do
  catalog <- readValidCatalog
  bytes <- readFixture fileName
  assertLeft (decodePackageLock catalog bytes)

readValidCatalog :: IO FamilyCatalog
readValidCatalog = readFixture "valid/config.json" >>= assertRight . decodeFamilyCatalog

readFixture :: FilePath -> IO ByteString.ByteString
readFixture relativePath = getDataFileName ("test/fixtures/" <> relativePath) >>= ByteString.readFile

assertRight :: Show error => Either error value -> IO value
assertRight = either (assertFailure . show) pure

assertLeft :: Show value => Either Text value -> IO ()
assertLeft result =
  case result of
    Left _ -> pure ()
    Right value -> assertFailure ("expected validation failure, decoded: " <> show value)

assertTrailingNewline :: LazyByteString.ByteString -> IO ()
assertTrailingNewline bytes =
  assertBool "canonical JSON must end in exactly one newline" $
    not (LazyByteString.null bytes)
      && LazyByteString.last bytes == 10
      && (LazyByteString.length bytes == 1 || LazyByteString.index bytes (LazyByteString.length bytes - 2) /= 10)

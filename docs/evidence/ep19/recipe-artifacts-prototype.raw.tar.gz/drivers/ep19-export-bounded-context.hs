{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE OverloadedRecordDot #-}
import Data.Aeson
import Data.ByteString qualified as BS
import Data.ByteString.Lazy qualified as LBS
import Data.Map.Strict qualified as Map
import Data.Text qualified as T
import Data.Text.IO qualified as TIO
import Data.Time
import Distribution.Version (Version)
import HaskellNix.Update.Cohort.Context
import HaskellNix.Update.Cohort.Freeze
import HaskellNix.Update.Cohort.Generate
import HaskellNix.Update.Cohort.GenerateIO
import HaskellNix.Update.Cohort.GenerationTypes
import HaskellNix.Update.Cohort.Model (parseVersion)
import HaskellNix.Update.Cohort.Types
import HaskellNix.Update.Hackage
import HaskellNix.Update.Process
import HaskellNix.Update.Types
import System.Directory
import System.FilePath
main = do
 let retained = "packages/runtimes/keiro-runtime/1/recipes"
     output = "/tmp/ep19-bounded-artifact-inputs"
 createDirectoryIfMissing True output
 allSources <- BS.readFile (retained </> "cabal/cohort-sources.json") >>= either fail pure . eitherDecodeStrict' :: IO (Map.Map T.Text PlanPackage)
 document <- TIO.readFile (retained </> "cabal/cohort.freeze") >>= either (fail . T.unpack) pure . parseFreezeDocument
 let sources = Map.filterWithKey (\name package -> name == "base64-bytestring" || package.source == Boot) allSources
 boot <- either (fail . T.unpack) pure (traverse (parseVersion . (.version)) (Map.filter ((== Boot) . (.source)) sources))
 let context = GenerationContext document{freezeVersions = Map.restrictKeys document.freezeVersions (Map.keysSet sources), freezeFlags = Map.restrictKeys document.freezeFlags (Map.keysSet sources)} sources boot Map.empty (GenerationPolicy Map.empty Map.empty) Map.empty Map.empty Map.empty
 value <- either (fail . T.unpack) pure (generationContextValue context)
 classified <- either (fail . T.unpack) pure (classifyCohort context)
 cutoff <- parseTimeM True defaultTimeLocale "%Y-%m-%dT%H:%M:%SZ" (T.unpack document.freezeIndexState)
 client <- defaultHttpClient
 entries <- resolveGeneratedEntries defaultProcessRunner client cutoff classified (Map.singleton "base64-bytestring" (either (error . T.unpack) id (parseVersion "1.2.1.0"), SriHash "sha256-Oe2u9XbsjSFi10dsUqlZbjoz+Bl5jn+s3xTTCono/oE=")) >>= either (fail . show) pure
 let entry = entries Map.! "base64-bytestring"; revision = entry.selectedRevision
 LBS.writeFile (output </> "generation-context.json") (encode value)
 LBS.writeFile (output </> "selected-revision.json") (encode (object ["number" .= revision.revisionNumber,"sha256" .= revision.revisionSha256,"time" .= revision.revisionTime]))
 copyFile "/tmp/mp4-ep19-group-inputs/base64-bytestring.cabal" (output </> "base64-bytestring.cabal")
 copyFile "/tmp/mp4-ep19-group-inputs/base64-bytestring-1.2.1.0.tar.gz" (output </> "base64-bytestring-1.2.1.0.tar.gz")
 putStrLn ("Exported typed bounded retained context: " <> show (Map.size sources) <> " classified packages; one generated root")

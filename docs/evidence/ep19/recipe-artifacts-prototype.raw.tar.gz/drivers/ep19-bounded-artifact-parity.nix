let
  channel = builtins.getFlake "git+file:///Users/shinzui/Keikaku/bokuno/haskell-nix?rev=56b88d52db389f66880fb7a3b273929a6cfeaec6";
  pkgs = import channel.inputs.nixpkgs { system = "aarch64-darwin"; };
  hl = pkgs.haskell.lib.compose;
  runtime = channel.lib.mkRuntimePackageSet
    (builtins.fromJSON (builtins.readFile /tmp/ep18-rei-resource-aware-split-v2/baseline/nix/runtime-selection.json));
  extension = import /tmp/ep19-bounded-artifacts-v1/extension.nix {
    inherit pkgs;
    haskellLib = hl;
    policyExtension = _final: previous: {
      base64-bytestring = hl.dontCheck previous.base64-bytestring;
    };
  };
  applicationOverlay = import /tmp/ep18-rei-resource-aware-split-v2/baseline/nix/haskell-overlay.nix {
    inherit pkgs;
    haskellLib = hl;
    gitRev = "bad0388";
    sourceRoot = /tmp/ep18-rei-resource-aware-split-v2/baseline;
  };
  applicationLegacy = (runtime.mkApplicationScope pkgs applicationOverlay).rei-cli;
  applicationCandidate = (runtime.mkApplicationScope pkgs (pkgs.lib.composeExtensions extension applicationOverlay)).rei-cli;
  artifactManifest = builtins.fromJSON (builtins.readFile /tmp/ep19-bounded-artifacts-v1/manifest.json);
  legacy = runtime.mkApplicationScope pkgs (_: _: { });
  checked = runtime.mkApplicationScope pkgs extension;
  scoped = pkgs.haskell.packages.ghc9124.override {
    overrides = pkgs.lib.composeExtensions (runtime.haskellExtension hl pkgs) extension;
  };
in
{
  scopedIdentity = scoped.base64-bytestring.drvPath;
  identity =
    assert artifactManifest.configuration.policyIdentity == runtime.metadata.fingerprint;
    assert applicationLegacy.drvPath == applicationCandidate.drvPath;
    assert legacy.base64-bytestring.drvPath == checked.base64-bytestring.drvPath;
    assert legacy.base64-bytestring.drvPath == scoped.base64-bytestring.drvPath;
    {
      legacy = legacy.base64-bytestring.drvPath;
      candidate = checked.base64-bytestring.drvPath;
      scoped = scoped.base64-bytestring.drvPath;
      compiler = checked.ghc.drvPath;
      runtime = runtime.metadata.fingerprint;
      consumerLegacy = applicationLegacy.drvPath;
      consumerCandidate = applicationCandidate.drvPath;
    };
}

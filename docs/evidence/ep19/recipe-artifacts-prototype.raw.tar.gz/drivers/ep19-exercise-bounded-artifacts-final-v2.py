from pathlib import Path
import json,subprocess,time,shutil,hashlib,os
root=Path('/tmp/ep19-bounded-artifact-inputs');relocated=Path('/tmp/ep19-bounded-artifact-inputs-relocated-final-v2');shutil.copytree(root,relocated)
binary=Path('/Users/shinzui/Keikaku/bokuno/haskell-nix/dist-newstyle/build/aarch64-osx/ghc-9.12.4/haskell-nix-update-0.1.0.0/x/haskell-nix-update/build/haskell-nix-update/haskell-nix-update');results=[]
base=Path('/tmp/ep19-bounded-artifacts-v1');other=Path('/tmp/ep19-bounded-artifacts-final-v2-copy');logs=Path('/tmp/ep19-bounded-artifacts-exercise-final-v2');logs.mkdir(exist_ok=False)
def tree(path):return {str(p.relative_to(path)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(path.rglob('*')) if p.is_file()}
def run(name,operation,context,target,expected=0):
 command=[str(binary),'cohort','recipes',operation,'--context',str(context),'--out',str(target)];start=time.perf_counter();env=os.environ.copy()
 env.update({'HTTP_PROXY':'http://127.0.0.1:9','HTTPS_PROXY':'http://127.0.0.1:9','ALL_PROXY':'http://127.0.0.1:9'})
 r=subprocess.run(command,capture_output=True,text=True,env=env);(logs/(name+'.log')).write_text(r.stdout+r.stderr);results.append({'name':name,'command':command,'exit_code':r.returncode,'elapsed_seconds':time.perf_counter()-start,'external_http_proxy':'unreachable loopback; only supplied local archives and metadata required'});assert r.returncode==expected,(name,r.stdout,r.stderr)
first=tree(base)
run('repeat-generate','generate',root/'context.json',base);assert tree(base)==first
run('offline-check','check',root/'context.json',base);assert tree(base)==first
run('relocated-generate','generate',relocated/'context.json',other);assert tree(other)==first
for name in ['base64-bytestring.cabal','base64-bytestring-1.2.1.0.tar.gz']:
 p=relocated/name;original=p.read_bytes()
 try:
  p.write_bytes(original+b'\ncontrolled metadata/archive drift\n');run('reject-'+name,'generate',relocated/'context.json',other,1);assert tree(other)==first
 finally:p.write_bytes(original)
drift=logs/'drift-output';shutil.copytree(base,drift);(drift/'extension.nix').write_text((drift/'extension.nix').read_text()+'# controlled drift\n');before=tree(drift);run('reject-artifact-drift','check',root/'context.json',drift,1);assert tree(drift)==before
(logs/'receipt.json').write_text(json.dumps({'status':'passed','results':results,'artifact_tree_sha256s':first,'relocation_byte_identical':True,'repeat_byte_identical':True,'check_preserves_outputs':True,'drift_preserves_accepted_outputs':True,'source_pins':'Classified explicitly; existing constructors retained. This is one generated Hackage root from retained generation 1, not a production migration or full M2/M3 acceptance.'},indent=2)+'\n');print('all real-tool artifact exercises passed')

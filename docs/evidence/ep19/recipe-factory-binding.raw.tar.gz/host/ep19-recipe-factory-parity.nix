let
 root = /Users/shinzui/Keikaku/bokuno/haskell-nix;
 f = builtins.getFlake "git+file:///Users/shinzui/Keikaku/bokuno/haskell-nix?rev=80f6e1e590f1e70b81e4aa8f0da692cb88f1b524";
 p = import f.inputs.nixpkgs {system="aarch64-darwin";}; h = p.haskell.lib.compose;
 r = f.lib.mkRuntimePackageSet ((builtins.fromJSON (builtins.readFile /tmp/ep18-rei-resource-aware-split-v2/baseline/nix/runtime-selection.json)) // {generation=3;});
 retained = root + "/${r.metadata.recipeDirectory}";
 mk = name: import (root + "/lib/${name}") {lib=p.lib;};
 factory = import (root + "/lib/mkFirstPartyPackageSet.nix") {
  lib=p.lib;
  mkFirstPartyRegistries=mk "mkFirstPartyRegistries.nix";
  mkHaskellExtension=mk "mkHaskellExtension.nix";
  mkHaskellOverlay=mk "mkHaskellOverlay.nix";
 };
 config = {
  config=builtins.fromJSON (builtins.readFile (retained + "/config/first-party-families.json"));
  lock=builtins.fromJSON (builtins.readFile (retained + "/packages/first-party-lock.json"));
  cohortVersions=r.comparisonContext.versions;
  commonRegistry=import (retained + "/overlays/registry.nix");
  compatibilityProfiles=import (retained + "/overlays/compatibility-profiles.nix");
  supportedGhcs=["ghc9124"];
 };
 artifacts={
  recipes=/tmp/ep19-recipe-factory-artifacts;
  context=builtins.fromJSON (builtins.readFile /tmp/ep19-recipe-factory-inputs/context.json);
  manifest=builtins.fromJSON (builtins.readFile /tmp/ep19-recipe-factory-artifacts/manifest.json);
 };
 construct = generatedRecipes: factory (config // {inherit generatedRecipes;}) {selections=r.selections;channel="github";};
 before=construct null; after=construct artifacts;
 app=import /tmp/ep18-rei-resource-aware-split-v2/baseline/nix/haskell-overlay.nix {
  pkgs=p;haskellLib=h;gitRev="bad0388";sourceRoot=/tmp/ep18-rei-resource-aware-split-v2/baseline;
 };
 scope=selected: p.haskell.packages.ghc9124.override {overrides=p.lib.composeExtensions (selected.haskellExtension h p) app;};
 legacy=scope before; candidate=scope after;
 rootOnly=scope after;
 in {
 application=candidate.rei-cli;
 scoped=rootOnly.base64-bytestring.drvPath;
 identity=assert r.validateApplicationScope p legacy;
  assert r.validateApplicationScope p candidate;
  assert legacy.base64-bytestring.drvPath==candidate.base64-bytestring.drvPath;
  assert legacy.rei-cli.drvPath==candidate.rei-cli.drvPath;
  {baseline=legacy.base64-bytestring.drvPath;generated=candidate.base64-bytestring.drvPath;consumerBaseline=legacy.rei-cli.drvPath;consumerGenerated=candidate.rei-cli.drvPath;runtime=r.metadata.fingerprint;};
 }

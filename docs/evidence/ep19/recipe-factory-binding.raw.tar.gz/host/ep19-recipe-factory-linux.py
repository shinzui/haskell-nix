from pathlib import Path
import subprocess,json,tarfile,time
root=Path('/tmp/ep19-recipe-factory-linux-v1');root.mkdir(exist_ok=False)
with tarfile.open('/tmp/ep19-recipe-factory-inputs.tar.gz') as tar:tar.extractall(root,filter='data')
source=root/'rei-source';source.mkdir()
with tarfile.open(root/'rei-source.tar') as tar:tar.extractall(source,filter='data')
previous=Path('/tmp/ep19-recipe-roles-linux-816ae29-v1/payload/inputs/context.json');tools=json.loads(previous.read_text())['configuration'];context=root/'inputs/context.json';value=json.loads(context.read_text())
for field in ['system','converter','extractor']:value['configuration'][field]=tools[field]
context.write_text(json.dumps(value,sort_keys=True,indent=2)+'\n');output=root/'artifacts';results=[]
updater=json.loads(Path('/tmp/ep19-recipe-roles-native-linux-outputs.json').read_text())[0]['outputs']['out']+'/bin/haskell-nix-update'
def run(name,command):
 start=time.monotonic()
 with (root/(name+'.json')).open('w') as out,(root/(name+'.log')).open('w') as err:r=subprocess.run(command,stdout=out,stderr=err)
 results.append({'name':name,'command':command,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-start});assert r.returncode==0,(name,(root/(name+'.log')).read_text()[-4000:]);return json.loads((root/(name+'.json')).read_text()) if (root/(name+'.json')).read_text().strip().startswith(('{','[','"')) else None
run('generate',[updater,'cohort','recipes','generate','--context',str(context),'--out',str(output)])
run('check',[updater,'cohort','recipes','check','--context',str(context),'--out',str(output)])
s=(root/'darwin-parity.nix').read_text().replace('/Users/shinzui/Keikaku/bokuno/haskell-nix','/workspace').replace('/tmp/ep18-rei-resource-aware-split-v2/baseline/nix/runtime-selection.json',str(source)+'/nix/runtime-selection.json').replace('/tmp/ep18-rei-resource-aware-split-v2/baseline',str(source)).replace('/tmp/ep19-recipe-factory-artifacts',str(output)).replace('/tmp/ep19-recipe-factory-inputs',str(context.parent)).replace('aarch64-darwin','x86_64-linux')
parity=root/'parity.nix';parity.write_text(s)
run('no-ifd',['nix','eval','--impure','--json','--file',str(parity),'scoped','--option','allow-import-from-derivation','false','--max-jobs','0','--builders',''])
identity=run('identity',['nix','eval','--impure','--json','--file',str(parity),'identity','--max-jobs','1','--cores','8','--builders',''])
run('focused',['nix','eval','--impure','--json','--expr','let f=builtins.getFlake "git+file:///workspace?rev=816ae297b25103865b5d026924590c2b5be67cd8"; lib=f.inputs.nixpkgs.lib; tests=import /workspace/checks/generated-recipe-binding.nix {inherit lib;}; in builtins.mapAttrs (_: t: t.expr == t.expected) tests'])
assert all(json.loads((root/'focused.json').read_text()).values())
(root/'receipt.json').write_text(json.dumps({'status':'passed','results':results,'identity':identity,'real_rei_source':'mori://shinzui/rei at bad0388f722af9e29187c2adfef5ed97fd0ca92f (artifact URI pending)','scope':'Opt-in live factory consumes a validated bounded Hackage context; generation-3 independent runtime validation remains active for both scopes. Apple translated guest; no performance, production or full retained-generation adoption claim.'},indent=2)+'\n');print('FACTORY_LINUX_PASSED',flush=True)

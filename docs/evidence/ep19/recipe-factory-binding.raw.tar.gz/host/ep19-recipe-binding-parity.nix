let
  channel = builtins.getFlake "git+file:///Users/shinzui/Keikaku/bokuno/haskell-nix?rev=c924d18d7266b48fdbafd85a3f46074465b1ff55";
  pkgs = import channel.inputs.nixpkgs { system = "aarch64-darwin"; };
  hl = pkgs.haskell.lib.compose;
  runtime = channel.lib.mkRuntimePackageSet
    (builtins.fromJSON (builtins.readFile /tmp/ep18-rei-resource-aware-split-v2/baseline/nix/runtime-selection.json));
  manifest = builtins.fromJSON (builtins.readFile /tmp/ep19-recipe-roles-artifacts-v1/manifest.json);
  basePolicy = _final: previous: {
    base64-bytestring = hl.dontCheck previous.base64-bytestring;
    cmark-gfm = hl.dontCheck previous.cmark-gfm;
  };
  normalizedPolicy = final: previous: (basePolicy final previous) // {
    cmark-gfm =
      # The immutable metadata declares pkgconfig False by default, matching
      # the solved flag. Remove only the converter's redundant spelling to
      # reproduce the existing source constructor's complete arguments.
      assert manifest.packages.cmark-gfm.sourcePin.metadataSha256 == "ed52f082c176d2f21e481a5b9c6ab02bd1ad7f6cf4044dd8bc9cd25dafb29853";
      assert (builtins.head manifest.generationContext.sources.cmark-gfm.identities).flags.pkgconfig == false;
      hl.overrideCabal
        (args: { configureFlags = builtins.filter (flag: flag != "-f-pkgconfig") (args.configureFlags or [ ]); })
        (hl.dontCheck previous.cmark-gfm);
  };
  extensionFor = policyExtension: (import /Users/shinzui/Keikaku/bokuno/haskell-nix/lib/mkGeneratedRecipeExtension.nix {lib = pkgs.lib;}) {
    inherit manifest policyExtension;
    recipes = /tmp/ep19-recipe-roles-artifacts-v1;
    context = builtins.fromJSON (builtins.readFile /tmp/ep19-recipe-roles-inputs/context.json);
  } hl pkgs;
  extension = extensionFor normalizedPolicy;
  legacy = runtime.mkApplicationScope pkgs (_: _: { });
  raw = runtime.mkApplicationScope pkgs (extensionFor basePolicy);
  checked = runtime.mkApplicationScope pkgs extension;
  scoped = pkgs.haskell.packages.ghc9124.override {
    overrides = pkgs.lib.composeExtensions (runtime.haskellExtension hl pkgs) extension;
  };
  applicationOverlay = import /tmp/ep18-rei-resource-aware-split-v2/baseline/nix/haskell-overlay.nix {
    inherit pkgs;
    haskellLib = hl;
    gitRev = "bad0388";
    sourceRoot = /tmp/ep18-rei-resource-aware-split-v2/baseline;
  };
  applicationLegacy = (runtime.mkApplicationScope pkgs applicationOverlay).rei-cli;
  applicationCandidate = (runtime.mkApplicationScope pkgs (pkgs.lib.composeExtensions extension applicationOverlay)).rei-cli;
  strict = package: hl.overrideCabal (_: { doCheck = true; jailbreak = false; }) package;
in
{
  scoped = { cmark-gfm = scoped.cmark-gfm.drvPath; base64-bytestring = scoped.base64-bytestring.drvPath; };
  validation = strict checked.cmark-gfm;
  identity =
    assert checked.base64-bytestring.drvPath == legacy.base64-bytestring.drvPath;
    assert checked.cmark-gfm.drvPath == legacy.cmark-gfm.drvPath;
    assert checked.cmark-gfm.drvPath == scoped.cmark-gfm.drvPath;
    assert applicationLegacy.drvPath == applicationCandidate.drvPath;
    assert (strict legacy.cmark-gfm).drvPath == (strict checked.cmark-gfm).drvPath;
    {
      legacy = legacy.cmark-gfm.drvPath;
      candidate = checked.cmark-gfm.drvPath;
      rawCandidate = raw.cmark-gfm.drvPath;
      base64-bytestring = checked.base64-bytestring.drvPath;
      consumerLegacy = applicationLegacy.drvPath;
      consumerCandidate = applicationCandidate.drvPath;
      origin = (import /Users/shinzui/Keikaku/bokuno/haskell-nix/lib/cohortSource.nix { inherit (pkgs) lib; }).record checked.cmark-gfm.cohortSourceOrigin.source;
      rawConfigureFlags = raw.cmark-gfm.configureFlags;
      legacyConfigureFlags = legacy.cmark-gfm.configureFlags;
      normalizedConfigureFlags = checked.cmark-gfm.configureFlags;
      validation = (strict checked.cmark-gfm).drvPath;
    };
}

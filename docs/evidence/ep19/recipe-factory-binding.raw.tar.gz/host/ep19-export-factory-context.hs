{-# LANGUAGE OverloadedRecordDot #-}
{-# LANGUAGE OverloadedStrings #-}
import Data.ByteString qualified as BS
import Data.Text.IO qualified as T
import Data.Map.Strict qualified as Map
import HaskellNix.Update.Cohort.RecipeArtifacts qualified as R
import HaskellNix.Update.Cohort.Render (canonicalJSON)
main :: IO ()
main = do
 original <- BS.readFile "/tmp/ep19-recipe-roles-inputs/context.json" >>= either (fail . show) pure . R.decodeRecipeContext
 let cfg = original.configuration
     selected = original { R.packages = Map.delete "cmark-gfm" original.packages, R.configuration = cfg { R.policyIdentity = "1454decc0402e63a9c07a86e00fa0bcb0967d666b79a51123aedb7d7dacfee45" } }
 value <- either (fail . show) pure (R.recipeContextValue selected)
 T.writeFile "/tmp/ep19-recipe-factory-inputs/context.json" (canonicalJSON value <> "\n")

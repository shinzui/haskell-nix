from pathlib import Path
import subprocess,json,time
results=[]
for name,args in [('no-ifd',['scoped','--option','allow-import-from-derivation','false']),('identity',['identity'])]:
 command=['nix','eval','--impure','--json','--file','/tmp/ep19-recipe-factory-parity.nix']+args+['--max-jobs','0','--builders',''];start=time.monotonic()
 with Path('/tmp/ep19-recipe-factory-final-'+name+'.json').open('w') as out,Path('/tmp/ep19-recipe-factory-final-'+name+'.log').open('w') as err:r=subprocess.run(command,stdout=out,stderr=err)
 results.append({'name':name,'command':command,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-start});assert r.returncode==0
Path('/tmp/ep19-recipe-factory-final-receipt.json').write_text(json.dumps({'status':'passed','results':results,'identity':json.loads(Path('/tmp/ep19-recipe-factory-final-identity.json').read_text())},indent=2)+'\n');print('Final factory evaluation passed')

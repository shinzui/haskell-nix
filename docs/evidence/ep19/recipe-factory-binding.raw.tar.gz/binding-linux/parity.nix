let
 f=builtins.getFlake "git+file:///workspace?rev=816ae297b25103865b5d026924590c2b5be67cd8";
 p=import f.inputs.nixpkgs {system="x86_64-linux";};h=p.haskell.lib.compose;
 r=f.lib.mkRuntimePackageSet {runtime="keiro-runtime";generation=1;channel="github";disableProfiling=true;disableHaddock=true;applicationSelections={kioku=8;okf=5;openapi-hs=1;relay-pagination=3;servant-openapi-hs=1;shikumi-baikai=9;};};
 m=builtins.fromJSON (builtins.readFile /tmp/ep19-recipe-roles-linux-816ae29-v1/artifacts/manifest.json);
 policy = _: prev:{base64-bytestring=h.dontCheck prev.base64-bytestring;
 cmark-gfm=assert m.packages.cmark-gfm.sourcePin.metadataSha256=="ed52f082c176d2f21e481a5b9c6ab02bd1ad7f6cf4044dd8bc9cd25dafb29853";
 assert (builtins.head m.generationContext.sources.cmark-gfm.identities).flags.pkgconfig==false;
 h.overrideCabal (a:{configureFlags=builtins.filter (flag: flag !="-f-pkgconfig") (a.configureFlags or []);}) (h.dontCheck prev.cmark-gfm);};
 ext=(import /workspace/lib/mkGeneratedRecipeExtension.nix {lib=p.lib;}) {manifest=m;recipes=/tmp/ep19-recipe-roles-linux-816ae29-v1/artifacts;context=builtins.fromJSON (builtins.readFile /tmp/ep19-recipe-roles-linux-816ae29-v1/payload/inputs/context.json);policyExtension=policy;} h p;
 legacy=r.mkApplicationScope p (_: _: { }); checked=r.mkApplicationScope p ext;
 scoped=p.haskell.packages.ghc9124.override {overrides=p.lib.composeExtensions (r.haskellExtension h p) ext;};
 strict = pkg: h.overrideCabal (_:{doCheck=true;jailbreak=false;}) pkg;
 in {scoped={cmark-gfm=scoped.cmark-gfm.drvPath;base64-bytestring=scoped.base64-bytestring.drvPath;};
 validation=strict checked.cmark-gfm;
 identity=assert legacy.cmark-gfm.drvPath==checked.cmark-gfm.drvPath;
 assert legacy.base64-bytestring.drvPath==checked.base64-bytestring.drvPath;
 assert scoped.cmark-gfm.drvPath==checked.cmark-gfm.drvPath;
 assert (strict legacy.cmark-gfm).drvPath==(strict checked.cmark-gfm).drvPath;
 {legacy=legacy.cmark-gfm.drvPath;candidate=checked.cmark-gfm.drvPath;validation=(strict checked.cmark-gfm).drvPath;runtime=r.metadata.fingerprint;};}

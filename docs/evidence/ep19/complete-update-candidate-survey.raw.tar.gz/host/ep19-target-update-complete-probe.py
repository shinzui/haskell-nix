from pathlib import Path
import concurrent.futures,json,subprocess
sources=json.loads(Path('cabal/cohort-sources.json').read_text());runtime=json.loads(Path('packages/runtime-lock.json').read_text())['runtimes']['keiro-runtime'][-1]['ownership'];root=Path('/tmp/ep19-target-update-complete-probe');root.mkdir(exist_ok=False)
names=sorted(name for name,p in sources.items() if p['source']=='Hackage')
def probe(name):
 output=root/(name+'.json');r=subprocess.run(['curl','--fail','--location','--silent','--show-error','--max-time','30','https://hackage-content.haskell.org/package/'+name+'/preferred.json','--output',str(output)],capture_output=True,text=True)
 if r.returncode:return {'package':name,'error':r.stderr.strip()}
 data=json.loads(output.read_text());versions=data.get('normal-version',[])
 if not versions:return {'package':name,'error':'no preferred normal versions'}
 latest=max(versions,key=lambda v:tuple(map(int,v.split('.'))));current=sources[name]['version'];return {'package':name,'selected':current,'registry_preferred_latest':latest,'higher_release':tuple(map(int,latest.split('.')))>tuple(map(int,current.split('.'))),'runtime_owned':name in runtime}
with concurrent.futures.ThreadPoolExecutor(4) as pool:rows=list(pool.map(probe,names))
(root/'receipt.json').write_text(json.dumps({'scope':'Complete current cohort Hackage registry survey; current preferred releases are not an assertion of fixed-index or bounds admissibility. No inputs changed.','packages':rows},indent=2)+'\n')
print('Checked',len(rows),'cohort Hackage packages',flush=True)
for row in rows:
 if row.get('higher_release') or 'error' in row:print(row,flush=True)

from pathlib import Path
import hashlib,io,json,re,tarfile
repo=Path('/Users/shinzui/Keikaku/bokuno/haskell-nix');tmp=Path('/tmp');members={}
def add(p,n):members[n]=Path(p).read_bytes()
survey=json.loads((tmp/'ep19-target-update-complete-probe/receipt.json').read_text());rows=survey['packages'];assert len(rows)==420 and not [r for r in rows if 'error' in r];higher=[r for r in rows if r['higher_release']];assert len(higher)==17
before=tmp/'ep19-http2-update-before';work=tmp/'ep19-targeted-update-rehearsal'
for p in before.iterdir():assert p.read_bytes()==(work/'cabal'/p.name).read_bytes();add(p,'before-and-after/'+p.name)
assert json.loads((repo/'cabal/inventory-inputs.json').read_text())['indexState']=='2026-10-16T12:29:59Z';assert not (tmp/'ep19-http2-rejected-index-retained.config').exists()
for dirname in ['ep19-target-update-complete-probe','ep19-remaining-target-metadata','ep19-target-update-release-metadata']:
 for p in sorted((tmp/dirname).glob('*')):
  if p.is_file():add(p,dirname+'/'+p.name)
for name in ['ep19-target-update-complete-probe.py','ep19-target-update-complete-probe.log','ep19-targeted-update-http2.log','ep19-targeted-update-http2-driver.json','ep19-http2-5.4.9.cabal','ep19-http2-5.4.8.cabal','ep19-http2-5.4.9.html','ep19-http2-5.4.9-page.txt','ep19-http2-upstream-tags.txt','ep19-http2-index-proposal.diff','ep19-http2-index-rejection.json','ep19-http2-index-rejection.log','ep19-tagged-0.9.html','ep19-tagged-0.9-page.txt','ep19-time-manager-0.4.0.html','ep19-time-manager-0.4.0-page.txt']:add(tmp/name,'host/'+name)
for name in ['cabal/common.config','cabal/inventory-inputs.json','cabal/rei-family-cohort/rei-family-cohort.cabal','cli/haskell-nix-update/src/HaskellNix/Update/Cohort/Cli.hs','scripts/cohort-update.py']:add(repo/name,'code/'+name)
source=json.loads((repo/'cabal/cohort-sources.json').read_text())
for name,path in [('aeson',tmp/'ep19-remaining-target-metadata/aeson-2.2.5.1.cabal'),('warp',tmp/'ep19-remaining-target-metadata/warp-3.4.16.cabal'),('http2',tmp/'ep19-http2-5.4.8.cabal')]:assert {i['pkg-cabal-sha256'] for i in source[name]['identities']}=={hashlib.sha256(path.read_bytes()).hexdigest()}
constraints={
'Diff':'Pinned Dhall requires Diff >=0.2 && <1.1; previous real no-op/conflict receipt applies.',
'QuickCheck':'common.config retains QuickCheck <2.19.',
'aeson':'The recorded aggregate package requires aeson <2.3.',
'crypton':'The recorded aggregate package requires crypton <1.2.',
'crypton-x509':'Both newer 1.9.2 and 1.10.0 require crypton >=2, outside crypton <1.2.',
'crypton-x509-store':'New 1.10.0 requires crypton-x509 >=1.10; unrelated x509 remains 1.9.1.',
'crypton-x509-system':'New 1.10.0 requires x509/store >=1.10; unrelated versions remain on 1.9.',
'crypton-x509-validation':'New 1.10.0 requires crypton >=2.1.8 and x509/store >=1.10.',
'hasql':'The recorded aggregate package requires hasql <1.11.',
'hasql-notifications':'New 0.2.6.0 requires hasql >=2.0 and hasql-pool >=1.5; both unrelated versions stay fixed.',
'hasql-pool':'The recorded aggregate package requires hasql-pool <1.5.',
'hpke':'Both newer 0.2.1 and 0.3.0 require crypton >=2, outside crypton <1.2.',
'http2':'Only newer preferred release 5.4.9 was uploaded after the fixed index; the actual fixed-index solve is a no-op.',
 'tagged':'Exact selected aeson metadata requires tagged ^>=0.8.7, excluding 0.9.',
 'text-iso8601':'Exact selected aeson metadata requires text-iso8601 ^>=0.1.1, excluding 0.2.0.0.',
 'time-manager':'Exact selected http2 metadata requires time-manager <0.4. The selected Warp already admits <0.5; Warp is not the blocker.',
 'tls':'All newer 2.4.7 through 2.4.11 require crypton >=2.1, outside crypton <1.2.'}
assert set(constraints)=={r['package'] for r in higher}
for r in higher:r['blocking_fact']=constraints[r['package']]
assert '2026-10-17T11:06:55Z' in (tmp/'ep19-http2-5.4.9-page.txt').read_text();assert 'fd352c5af5922a06370d4e65a0eb7e15e1d40153\trefs/tags/v5.4.9' in (tmp/'ep19-http2-upstream-tags.txt').read_text();assert 'explicit broad update is required' in (tmp/'ep19-http2-index-rejection.log').read_text()
log=(tmp/'ep19-targeted-update-http2.log').read_text();stage=Path(re.search(r'Targeted candidate and diagnostic logs: (\S+)',log)[1])
for name in ['retained.config','cohort.project','common.config','solve.log','cohort.freeze','cohort-sources.json','cohort-impact.txt','cohort-report.txt','dist-newstyle/cache/plan.json']:add(stage/name,'http2-stage/'+name)
add(Path(__file__),'record.py')
archive=repo/'docs/evidence/ep19/complete-update-candidate-survey.raw.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for name,data in sorted(members.items()):
  info=tarfile.TarInfo(name);info.size=len(data);tar.addfile(info,io.BytesIO(data))
hashes={n:hashlib.sha256(d).hexdigest() for n,d in sorted(members.items())}
with tarfile.open(archive) as tar:
 for row in tar.getmembers():assert hashlib.sha256(tar.extractfile(row).read()).hexdigest()==hashes[row.name]
receipt={'schema_version':1,'revision':'fe6f329','status':'Complete preferred-release survey and real http2 no-op; explicit transition required for a positive rehearsal','source_observation_scope':'All 420 Hackage-sourced entries in the Cabal plan, including entries whose Nix source ownership differs; not a claim of 420 generated Nix recipes.','surveyed_entries':420,'higher_preferred_releases':higher,'fixed_index':'2026-10-16T12:29:59Z','http2':{'selected':'5.4.8','latest_preferred':'5.4.9','uploaded_at':'2026-10-17T11:06:55Z','project':'mori://kazu-yamamoto/http2','upstream_tag':'v5.4.9','upstream_revision':'fd352c5af5922a06370d4e65a0eb7e15e1d40153','source_path':'http2.cabal','source_artifact_uri':'pending','metadata_source':'https://hackage-content.haskell.org/package/http2-5.4.9','fixed_index_solve':json.loads((tmp/'ep19-targeted-update-http2-driver.json').read_text()),'all_four_accepted_outputs_unchanged':True},'selected_parent_metadata_hashes_verified':['aeson-2.2.5.1','warp-3.4.16','http2-5.4.8'],'index_guard':json.loads((tmp/'ep19-http2-index-rejection.json').read_text()),'proposal':{'status':'Unapplied; explicit user direction pending','proposed_index':'2026-10-17T11:06:56Z','files':['cabal/common.config','cabal/inventory-inputs.json'],'unrelated_versions_and_identities_must_remain_unchanged':True,'existing_workflow_requires_explicit_broad_update_transition':True},'limits':['No index, bounds, source policy, compiler or production selection changed; no positive targeted update/rollback acceptance.','The 17 exclusion facts concern current preferred normal releases under the existing recorded constraints; no unpreferred release was selected to obtain an artificial update.','Only Diff and http2 have real fixed-index no-op runs here. Remaining exclusions are metadata/bounds evidence, not new solver runs or native compatibility results.','Mori registry remains unavailable; intended canonical upstream project URI and exact upstream tag/source path are provided with source-artifact URI pending.','Initial source inspection guessed Warp might exclude time-manager 0.4; exact selected metadata disproved that. The verified blocker is http2 <0.4.','Tagged 0.9 is registered upstream but the queried repository tags do not contain that release; no new tagged pin or compatibility workaround is selected.'],'raw_archive':{'path':str(archive.relative_to(repo)),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':hashes}}
(repo/'docs/evidence/ep19/complete-update-candidate-survey.json').write_text(json.dumps(receipt,indent=2)+'\n');print('Verified',len(hashes),'raw members; all 420 entries surveyed, 17 higher preferred releases classified')

{ mkDerivation, base, bytestring, HUnit, lib, src, text }:
mkDerivation {
  pname = "cmark-gfm";
  version = "0.2.6";
  src = src;
  configureFlags = [ "-f-pkgconfig" ];
  libraryHaskellDepends = [ base bytestring text ];
  testHaskellDepends = [ base HUnit text ];
  homepage = "https://github.com/kivikakk/cmark-gfm-hs";
  description = "Fast, accurate GitHub Flavored Markdown parser and renderer";
  license = lib.licenses.bsd3;
}

{-# LANGUAGE OverloadedStrings #-}
import Data.Aeson (encode)
import Data.ByteString.Lazy qualified as LBS
import Data.Map.Strict qualified as Map
import HaskellNix.Update.Cohort.RecipeArtifacts (inspectRecipeRoles)
import HaskellNix.Update.Process (defaultProcessRunner)
import System.Directory (listDirectory)
import System.FilePath ((</>), takeFileName)
import Data.List (sort)
main :: IO ()
main = do
 let directory = "checks/fixtures/generated-recipes/packages"
 names <- sort <$> listDirectory directory
 rows <- mapM (\name -> do
   roles <- inspectRecipeRoles defaultProcessRunner (directory </> name) >>= either (fail . show) pure
   pure (takeFileName name, roles)) names
 LBS.writeFile "/tmp/ep19-role-fixture-inventory.json" (encode (Map.fromList rows) <> "\n")
 putStrLn ("Inspected " <> show (length rows) <> " converter functions with IFD disabled")

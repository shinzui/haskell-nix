{-# LANGUAGE OverloadedStrings #-}
import Data.Aeson (encode)
import Data.ByteString qualified as BS
import Data.ByteString.Lazy qualified as LBS
import Data.Text qualified as Text
import HaskellNix.Update.Cohort.RecipeArtifacts qualified as Recipes
import System.Environment (getArgs)
main :: IO ()
main = do
 args <- getArgs
 case args of
  [input, output] -> do
   context <- BS.readFile input >>= either (fail . Text.unpack) pure . Recipes.decodeRecipeContext
   value <- either (fail . Text.unpack) pure (Recipes.recipeContextValue context{Recipes.formatVersion = 2})
   LBS.writeFile output (encode value <> "\n")
  _ -> fail "expected input context and output context paths"

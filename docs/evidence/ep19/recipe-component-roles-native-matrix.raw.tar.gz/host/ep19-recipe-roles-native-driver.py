from pathlib import Path
import subprocess,json,time,concurrent.futures
rev=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
def run(system):
 prefix='/tmp/ep19-recipe-roles-native-'+system
 target=('git+file:///workspace' if system=='linux' else 'git+file:///Users/shinzui/Keikaku/bokuno/haskell-nix')+'?rev='+rev+'#checks.'+('x86_64-linux' if system=='linux' else 'aarch64-darwin')+'.haskell-nix-update'
 nix=['nix','build',target,'--no-link','--json','-L','--max-jobs','1','--cores','8' if system=='linux' else '16','--builders','']
 if system=='linux':
  import shlex
  cmd=['container','exec','--env','NIX_CONFIG=experimental-features = nix-command flakes\nfilter-syscalls = false\nsandbox = false','mp3-linux-builder','sh','-c',shlex.join(nix)+' > '+prefix+'-outputs.json 2> '+prefix+'.log']
 else:cmd=nix
 start=time.monotonic()
 with Path(prefix+'-driver.log').open('w') as out:
  if system=='linux':r=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT)
  else:
   with Path(prefix+'-outputs.json').open('w') as outputs:r=subprocess.run(cmd,stdout=outputs,stderr=out)
 receipt={'revision':rev,'command':cmd,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-start}
 Path(prefix+'-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');assert r.returncode==0,(system,r.returncode)
 return system
with concurrent.futures.ThreadPoolExecutor(2) as pool:
 for result in pool.map(run,['darwin','linux']):print(result,'passed',flush=True)

from pathlib import Path
import subprocess,json,tarfile,time,hashlib,os
rev='816ae297b25103865b5d026924590c2b5be67cd8';root=Path('/tmp/ep19-recipe-roles-linux-'+rev[:7]+'-v1');root.mkdir(exist_ok=False);results=[]
def run(name,command,expected=0):
 start=time.monotonic();env=os.environ.copy()
 if name in ['generate','check','repeat','reject-metadata','reject-role-drift','reject-revision-label','relocation']:
  env.update({'HTTP_PROXY':'http://127.0.0.1:9','HTTPS_PROXY':'http://127.0.0.1:9','ALL_PROXY':'http://127.0.0.1:9'})
 with (root/(name+'.out')).open('w') as out,(root/(name+'.log')).open('w') as err:r=subprocess.run(command,stdout=out,stderr=err,env=env)
 results.append({'name':name,'command':command,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-start});(root/'progress.json').write_text(json.dumps(results,indent=2)+'\n');assert r.returncode==expected,(name,(root/(name+'.log')).read_text()[-3500:]);return (root/(name+'.out')).read_text()
payload=root/'payload';payload.mkdir()
with tarfile.open('/workspace/docs/evidence/ep19/recipe-component-roles.raw.tar.gz') as t:t.extractall(payload,filter='data')
expr='let f=builtins.getFlake "git+file:///workspace?rev='+rev+'"; p=import f.inputs.nixpkgs {system="x86_64-linux";}; in '
converter=json.loads(run('converter',['nix','build','--impure','--expr',expr+'p.buildPackages.haskellPackages.cabal2nix-unstable.bin','--no-link','--json','--max-jobs','1','--cores','8','--builders','']))[0]
extractor=json.loads(run('extractor',['nix','build','--impure','--expr',expr+'p.gnutar','--no-link','--json','--max-jobs','1','--cores','8','--builders','']))[0]
converterOutput=converter['outputs']['bin'];extractorOutput=extractor['outputs']['out']
cv=run('converter-version',[converterOutput+'/bin/cabal2nix','--version']).strip();tv=run('extractor-version',[extractorOutput+'/bin/tar','--version']).splitlines()[0]
context=payload/'inputs/context.json';value=json.loads(context.read_text());value['configuration']['system']='x86_64-linux';value['configuration']['converter']={'derivation':converter['drvPath'],'output':converterOutput,'version':cv};value['configuration']['extractor']={'derivation':extractor['drvPath'],'output':extractorOutput,'version':tv};context.write_text(json.dumps(value,sort_keys=True,indent=2)+'\n')
updater=json.loads(Path('/tmp/ep19-recipe-roles-native-linux-outputs.json').read_text())[0]['outputs']['out']+'/bin/haskell-nix-update';output=root/'artifacts'
def tree(d):return {str(p.relative_to(d)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(d.rglob('*')) if p.is_file()}
run('generate',[updater,'cohort','recipes','generate','--context',str(context),'--out',str(output)]);first=tree(output)
run('check',[updater,'cohort','recipes','check','--context',str(context),'--out',str(output)]);assert first==tree(output)
run('repeat',[updater,'cohort','recipes','generate','--context',str(context),'--out',str(output)]);assert first==tree(output)
metadata=context.parent/'cmark-gfm.cabal';original=metadata.read_bytes()
try:
 metadata.write_bytes(original+b'\ncontrolled metadata drift\n');run('reject-metadata',[updater,'cohort','recipes','generate','--context',str(context),'--out',str(output)],1);assert first==tree(output)
finally:metadata.write_bytes(original)
# Format 2 inspects exact converter functions and records identity/component roles.
import shutil
m=json.loads((output/'manifest.json').read_text());assert m['schemaVersion']==2
assert m['packages']['base64-bytestring']['convertedMetadata']['revision']=='1'
assert m['packages']['cmark-gfm']['convertedMetadata']['revision'] is None
assert m['packages']['cmark-gfm']['dependenciesByComponent']['libraryHaskellDepends']==['base','bytestring','text']
relocated=root/'relocated-inputs';shutil.copytree(context.parent,relocated)
relocatedOutput=root/'relocated-artifacts'
run('relocation',[updater,'cohort','recipes','generate','--context',str(relocated/'context.json'),'--out',str(relocatedOutput)]);assert first==tree(relocatedOutput)
damaged=root/'damaged-roles';shutil.copytree(output,damaged);p=damaged/'manifest.json';damagedManifest=json.loads(p.read_text());del damagedManifest['packages']['cmark-gfm']['dependenciesByComponent']['testHaskellDepends'];p.write_text(json.dumps(damagedManifest));before=tree(damaged)
run('reject-role-drift',[updater,'cohort','recipes','check','--context',str(context),'--out',str(damaged)],1);assert before==tree(damaged)
originalContext=context.read_bytes();changed=json.loads(originalContext)
try:
 changed['packages']['base64-bytestring']['revision']['number']=0;context.write_text(json.dumps(changed))
 run('reject-revision-label',[updater,'cohort','recipes','generate','--context',str(context),'--out',str(output)],1);assert first==tree(output)
 assert 'converted metadata revision disagrees' in (root/'reject-revision-label.log').read_text()
finally:context.write_bytes(originalContext)
# Seed the ordinary immutable source name from the verified local archive.
# This is warm-store correctness evidence, never a fresh-worker receipt.
run('source-seed',['nix','--offline','store','prefetch-file','--json','--unpack','--name','source','--expected-hash',value['packages']['cmark-gfm']['unpackedHash'],'file://'+str(context.parent/'cmark-gfm-hs-a9014e8.tar.gz')])
parity=root/'parity.nix';parity.write_text('''let
 f=builtins.getFlake "git+file:///workspace?rev='''+rev+'''";
 p=import f.inputs.nixpkgs {system="x86_64-linux";};h=p.haskell.lib.compose;
 r=f.lib.mkRuntimePackageSet {runtime="keiro-runtime";generation=1;channel="github";disableProfiling=true;disableHaddock=true;applicationSelections={kioku=8;okf=5;openapi-hs=1;relay-pagination=3;servant-openapi-hs=1;shikumi-baikai=9;};};
 m=builtins.fromJSON (builtins.readFile '''+str(output)+'''/manifest.json);
 policy = _: prev:{base64-bytestring=h.dontCheck prev.base64-bytestring;
 cmark-gfm=assert m.packages.cmark-gfm.sourcePin.metadataSha256=="ed52f082c176d2f21e481a5b9c6ab02bd1ad7f6cf4044dd8bc9cd25dafb29853";
 assert (builtins.head m.generationContext.sources.cmark-gfm.identities).flags.pkgconfig==false;
 h.overrideCabal (a:{configureFlags=builtins.filter (flag: flag !="-f-pkgconfig") (a.configureFlags or []);}) (h.dontCheck prev.cmark-gfm);};
 ext=import '''+str(output)+'''/extension.nix {pkgs=p;haskellLib=h;policyExtension=policy;};
 legacy=r.mkApplicationScope p (_: _: { }); checked=r.mkApplicationScope p ext;
 scoped=p.haskell.packages.ghc9124.override {overrides=p.lib.composeExtensions (r.haskellExtension h p) ext;};
 strict = pkg: h.overrideCabal (_:{doCheck=true;jailbreak=false;}) pkg;
 in {scoped={cmark-gfm=scoped.cmark-gfm.drvPath;base64-bytestring=scoped.base64-bytestring.drvPath;};
 validation=strict checked.cmark-gfm;
 identity=assert legacy.cmark-gfm.drvPath==checked.cmark-gfm.drvPath;
 assert legacy.base64-bytestring.drvPath==checked.base64-bytestring.drvPath;
 assert scoped.cmark-gfm.drvPath==checked.cmark-gfm.drvPath;
 assert (strict legacy.cmark-gfm).drvPath==(strict checked.cmark-gfm).drvPath;
 {legacy=legacy.cmark-gfm.drvPath;candidate=checked.cmark-gfm.drvPath;validation=(strict checked.cmark-gfm).drvPath;runtime=r.metadata.fingerprint;};}
''')
noIfd=json.loads(run('no-ifd',['nix','eval','--impure','--json','--file',str(parity),'scoped','--option','allow-import-from-derivation','false','--max-jobs','0','--builders','']))
identity=json.loads(run('parity',['nix','eval','--impure','--json','--file',str(parity),'identity','--max-jobs','1','--cores','8','--builders','']))
# The unchanged strict derivation already passed 22 tests in the preceding matrix.
prior=json.loads(Path('/tmp/ep19-source-pin-linux-44bb697-v2/receipt.json').read_text())
assert identity['validation']==prior['identity']['validation']
(root/'receipt.json').write_text(json.dumps({'revision':rev,'status':'passed','system':'x86_64-linux','execution':'Apple amd64 guest with Rosetta translation, independent warm store; sandbox/filter-syscalls false. Local source seeded under its normal immutable name. No physical x86 performance or fresh-worker claim.','results':results,'artifact_tree_sha256s':first,'identity':identity,'scoped_no_ifd':noIfd,'strict_original_bounds_prior_receipt':'/tmp/ep19-source-pin-linux-44bb697-v2/receipt.json','strict_test_derivation_unchanged':True,'component_roles':{n:p['dependenciesByComponent'] for n,p in m['packages'].items()},'scope':'One Hackage root and the existing cmark-gfm Git fork. Exact raw function bytes retained; guarded default-false flag spelling reproduces the legacy constructor. Actual Rei consumer parity accepted separately on Darwin; broader effective flags and retained factory integration pending.'},indent=2)+'\n');print('RECIPE_ROLES_LINUX_PASSED',flush=True)

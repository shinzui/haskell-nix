from pathlib import Path
import tarfile,json,subprocess,os,time,shutil
root=Path('/tmp/ep19-retained-recipe-staging-linux-v1');root.mkdir(exist_ok=False)
with tarfile.open('/tmp/ep19-retained-recipe-darwin-staged.tar.gz') as tar:tar.extractall(root,filter='data')
previous=json.loads(Path('/tmp/ep19-recipe-factory-linux-v1/inputs/context.json').read_text())['configuration'];updater=json.loads(Path('/tmp/ep19-recipe-roles-native-linux-outputs.json').read_text())[0]['outputs']['out']+'/bin/haskell-nix-update';env=os.environ.copy();env.update({'HTTP_PROXY':'http://127.0.0.1:9','HTTPS_PROXY':'http://127.0.0.1:9','ALL_PROXY':'http://127.0.0.1:9'});results=[]
for channel in ['github','hackage']:
 base=root/'x86_64-linux'/channel;inputs=base/'inputs';inputs.mkdir(parents=True)
 original=root/'darwin'/channel/'inputs'
 for name in ['base64-bytestring.cabal','base64-bytestring-1.2.1.0.tar.gz']:shutil.copyfile(original/name,inputs/name)
 ctx=json.loads((original/'context.json').read_text());ctx['configuration']['system']='x86_64-linux';ctx['configuration']['converter']=previous['converter'];(inputs/'context.json').write_text(json.dumps(ctx,sort_keys=True,indent=2)+'\n')
 for operation in ['generate','check']:
  command=[updater,'cohort','recipes',operation,'--context',str(inputs/'context.json'),'--out',str(base/'recipes')];start=time.monotonic()
  with (base/(operation+'.log')).open('w') as log:r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,env=env)
  results.append({'channel':channel,'operation':operation,'command':command,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-start});assert r.returncode==0
 assert (base/'recipes/packages/base64-bytestring.nix').read_bytes()==(root/'darwin'/channel/'recipes/packages/base64-bytestring.nix').read_bytes()
(root/'linux-receipt.json').write_text(json.dumps({'status':'passed','results':results,'raw_functions_equal_darwin':True,'scope':'Staged for upcoming retained capture; not a published generation or production selection.'},indent=2)+'\n')
with tarfile.open('/tmp/ep19-retained-recipe-linux-staged.tar.gz','w:gz') as tar:
 tar.add(root/'x86_64-linux',arcname='x86_64-linux');tar.add(root/'linux-receipt.json',arcname='linux-receipt.json')
print('STAGED_LINUX_RECIPE_CELLS_PASSED',flush=True)

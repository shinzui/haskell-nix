from pathlib import Path
import subprocess,json,shutil,hashlib,time
root=Path('/tmp/ep19-recipe-freshness-exercise');root.mkdir(exist_ok=False);source=Path('/Users/shinzui/Keikaku/bokuno/haskell-nix');cell=source/'packages/runtimes/keiro-runtime/4/recipes/config/generated-recipes/keiro-runtime/aarch64-darwin/github';shutil.copytree(cell,root/'cell');binary=source/'dist-newstyle/build/aarch64-osx/ghc-9.12.4/haskell-nix-update-0.1.0.0/x/haskell-nix-update/build/haskell-nix-update/haskell-nix-update';context=root/'cell/inputs/context.json';commands=root/'commands.json'
with commands.open('w') as output:subprocess.run([str(binary),'cohort','recipes','commands','--context',str(context)],stdout=output,check=True)
model=json.loads(commands.read_text());converter=model['configuration']['converter']['output']+'/bin/cabal2nix';results=[]
def tree():return {str(p.relative_to(root/'cell')):hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'cell').rglob('*') if p.is_file()}
def run(name,expected):
 command=['python3',str(source/'scripts/check-generated-recipe-freshness.py'),'--commands',str(commands),'--inputs',str(root/'cell/inputs'),'--recipes',str(root/'cell/recipes'),'--converter',converter];before=tree();start=time.monotonic()
 with (root/(name+'.log')).open('w') as out:r=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT)
 assert r.returncode==expected,(name,r.returncode);assert tree()==before;results.append({'name':name,'command':command,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-start,'inputs_and_artifacts_unchanged':True})
run('positive-relocated',0)
for name,relative in [('metadata','inputs/base64-bytestring.cabal'),('archive','inputs/base64-bytestring-1.2.1.0.tar.gz'),('recipe','recipes/packages/base64-bytestring.nix')]:
 path=root/'cell'/relative;original=path.read_bytes()
 try:path.write_bytes(original+b'\ncontrolled drift\n');run('reject-'+name,1)
 finally:path.write_bytes(original)
(root/'receipt.json').write_text(json.dumps({'status':'passed','results':results,'same_model_flags_metadata_and_raw_recipe_bytes':True,'freshness_adapter':'Only the URI changes to a private metadata-only directory, using --src-expression=src and --no-hpack from the original argument model. No home override or nested writable Nix store. Exact ordinary-generator bytes remain mandatory.'},indent=2)+'\n');print('Freshness rejection and relocation checks passed')

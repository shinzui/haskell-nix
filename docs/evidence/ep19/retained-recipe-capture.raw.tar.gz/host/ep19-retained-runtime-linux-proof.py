from pathlib import Path
import subprocess,json,time
results=[]
for channel in ['github','hackage']:
 for name,args in [('no-ifd',['noIfd','--option','allow-import-from-derivation','false']),('identity',['identity'])]:
  command=['nix','eval','--impure','--json','--file','/tmp/ep19-retained-runtime-public-linux.nix','--argstr','channel',channel]+args+['--max-jobs','0','--builders',''];start=time.monotonic();prefix='/tmp/ep19-retained-runtime-linux-'+channel+'-'+name
  with Path(prefix+'.json').open('w') as out,Path(prefix+'.log').open('w') as err:r=subprocess.run(command,stdout=out,stderr=err)
  results.append({'channel':channel,'name':name,'command':command,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-start});assert r.returncode==0,(channel,name)
Path('/tmp/ep19-retained-runtime-linux-receipt.json').write_text(json.dumps({'status':'passed','results':results,'execution':'Actual x86_64 Linux toolchain under Rosetta in Apple container; independent warm store. No physical x86 performance or fresh-worker claim.'},indent=2)+'\n');print('Both retained Linux channels pass public constructor and no-IFD checks',flush=True)

{ channel ? "github", system ? "x86_64-linux" }:
let
 root = /workspace;
 f = builtins.getFlake "git+file:///workspace?rev=2b46e2dc2488bc1c5c8c91080956a66b66b9a948";
 p = import f.inputs.nixpkgs { inherit system; }; h = p.haskell.lib.compose;
 mk = import (root + "/lib/mkRuntimePackageSet.nix") {lib=p.lib;inherit root;};
 input = builtins.fromJSON (builtins.readFile /tmp/ep19-recipe-factory-linux-v1/rei-source/nix/runtime-selection.json);
 previous=mk (input // {generation=3;inherit channel;});
 selected=mk (input // {generation=4;inherit channel;});
 app=import /tmp/ep19-recipe-factory-linux-v1/rei-source/nix/haskell-overlay.nix {
  pkgs=p;haskellLib=h;gitRev="bad0388";sourceRoot=/tmp/ep19-recipe-factory-linux-v1/rei-source;
 };
 before=previous.mkApplicationScope p app;
 after=selected.mkApplicationScope p app;
 scoped=p.haskell.packages.ghc9124.override {overrides=p.lib.composeExtensions (selected.haskellExtension h p) app;};
 owned=builtins.filter (name: selected.metadata.ownership.${name}.source != "Boot") (builtins.attrNames selected.metadata.ownership);
 in {
 noIfd=scoped.base64-bytestring.drvPath;
 application=after.rei-cli;
 identity=assert before.rei-cli.drvPath==after.rei-cli.drvPath;
  assert builtins.all (name: before.${name}.drvPath==after.${name}.drvPath) owned;
  {runtime=selected.metadata.fingerprint;previousRuntime=previous.metadata.fingerprint;ownedPackagesCompared=builtins.length owned;
   selectedRoot=after.base64-bytestring.drvPath;consumer=after.rei-cli.drvPath;previousConsumer=before.rei-cli.drvPath;};
 }

{ channel ? "github", system ? "aarch64-darwin" }:
let
 root = /Users/shinzui/Keikaku/bokuno/haskell-nix;
 f = builtins.getFlake "git+file:///Users/shinzui/Keikaku/bokuno/haskell-nix?rev=2b46e2dc2488bc1c5c8c91080956a66b66b9a948";
 p = import f.inputs.nixpkgs { inherit system; }; h = p.haskell.lib.compose;
 mk = import (root + "/lib/mkRuntimePackageSet.nix") {lib=p.lib;inherit root;};
 input = builtins.fromJSON (builtins.readFile /tmp/ep18-rei-resource-aware-split-v2/baseline/nix/runtime-selection.json);
 previous=mk (input // {generation=3;inherit channel;});
 selected=mk (input // {generation=4;inherit channel;});
 app=import /tmp/ep18-rei-resource-aware-split-v2/baseline/nix/haskell-overlay.nix {
  pkgs=p;haskellLib=h;gitRev="bad0388";sourceRoot=/tmp/ep18-rei-resource-aware-split-v2/baseline;
 };
 before=previous.mkApplicationScope p app;
 after=selected.mkApplicationScope p app;
 scoped=p.haskell.packages.ghc9124.override {overrides=p.lib.composeExtensions (selected.haskellExtension h p) app;};
 owned=builtins.filter (name: selected.metadata.ownership.${name}.source != "Boot") (builtins.attrNames selected.metadata.ownership);
 in {
 noIfd=scoped.base64-bytestring.drvPath;
 application=after.rei-cli;
 identity=assert before.rei-cli.drvPath==after.rei-cli.drvPath;
  assert builtins.all (name: before.${name}.drvPath==after.${name}.drvPath) owned;
  {runtime=selected.metadata.fingerprint;previousRuntime=previous.metadata.fingerprint;ownedPackagesCompared=builtins.length owned;
   selectedRoot=after.base64-bytestring.drvPath;consumer=after.rei-cli.drvPath;previousConsumer=before.rei-cli.drvPath;};
 }

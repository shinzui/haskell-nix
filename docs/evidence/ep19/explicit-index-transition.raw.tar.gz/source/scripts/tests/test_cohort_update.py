"""Snapshot and promotion regressions; these never invoke Cabal or Nix."""
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch


scripts_directory = Path(__file__).parents[1]
sys.path.insert(0, str(scripts_directory))
spec = importlib.util.spec_from_file_location("cohort_update", scripts_directory / "cohort-update.py")
updater = importlib.util.module_from_spec(spec)
spec.loader.exec_module(updater)


class SnapshotTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name) / "root"
        self.stage = Path(self.temporary.name) / "stage"
        self.runtime = Path(self.temporary.name) / "external-runtime.freeze"
        names = ["cabal/" + name for name in [
            "cohort.freeze", "cohort-sources.json", "common.config", "floors.config",
            "contributors.json", "inventory-inputs.json", "policy-floors.json",
            "compiler-boot-packages.json", "policy-roots.json",
        ]] + ["flake.nix", "flake.lock", "cabal.project", "packages/first-party-lock.json",
              "config/first-party-families.json", "cabal/inventory/one.json",
              "cabal/rei-family-cohort/rei-family-cohort.cabal", "nix/tooling.nix"]
        for name in names:
            path = self.root / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text("original " + name)
        (self.root / "cabal/inventory-inputs.json").write_text(json.dumps({
            "indexState": "2026-10-05T22:39:44Z", "channelRevision": "recorded-revision",
            "compiler": "ghc-9.12.4",
        }))
        (self.root / "cabal/policy-roots.json").write_text("[]\n")
        (self.root / "cabal/common.config").write_text("index-state: hackage.haskell.org 2026-10-05T22:39:44Z\n")
        self.runtime.write_text("original runtime")

    def test_changed_removed_and_added_inputs_invalidate_snapshot(self):
        mutations = [
            ("cabal/inventory/one.json", "delete"),
            ("cabal/inventory/new.json", "write"),
            ("cabal/rei-family-cohort/rei-family-cohort.cabal", "write"),
            ("cabal/rei-family-cohort/new.cabal", "write"),
            ("flake.lock", "write"),
            ("nix/tooling.nix", "write"),
            ("cabal/policy-roots.json", "write"),
            ("overlays/new.nix", "write"),
        ]
        for name, operation in mutations:
            with self.subTest(name=name):
                baseline = updater.capture_inputs(self.root, self.runtime)
                path = self.root / name
                before = path.read_bytes() if path.exists() else None
                if operation == "delete":
                    path.unlink()
                else:
                    path.parent.mkdir(parents=True, exist_ok=True)
                    path.write_text("changed")
                self.assertNotEqual(updater.capture_inputs(self.root, self.runtime), baseline)
                if before is None:
                    path.unlink()
                else:
                    path.write_bytes(before)
        baseline = updater.capture_inputs(self.root, self.runtime)
        self.runtime.write_text("changed runtime")
        self.assertNotEqual(updater.capture_inputs(self.root, self.runtime), baseline)

    def test_staging_uses_captured_bytes_after_live_inputs_change(self):
        baseline = updater.capture_inputs(self.root, self.runtime)
        (self.root / "cabal/common.config").write_text("new live config")
        self.runtime.write_text("new live runtime")
        captured, runtime = updater.stage_inputs(self.root, self.stage, baseline, self.runtime)
        self.assertEqual((self.stage / "common.config").read_bytes(), baseline[self.root / "cabal/common.config"])
        self.assertEqual((captured / "cabal/inventory/one.json").read_bytes(), baseline[self.root / "cabal/inventory/one.json"])
        self.assertEqual(runtime.read_text(), "original runtime")

    def test_runtime_can_also_be_the_existing_cohort_freeze(self):
        runtime = self.root / "cabal/cohort.freeze"
        baseline = updater.capture_inputs(self.root, runtime)
        captured, staged_runtime = updater.stage_inputs(self.root, self.stage, baseline, runtime)
        self.assertEqual((captured / "cabal/cohort.freeze").read_bytes(), baseline[runtime])
        self.assertEqual(staged_runtime.read_bytes(), baseline[runtime])

    def run_workflow(self, mutate=None, reject_retained=False, advance=None, fail_replace_at=None):
        commands = []
        actual_replace = updater.os.replace
        replacements = 0

        def replace(source, destination):
            nonlocal replacements
            replacements += 1
            if replacements == fail_replace_at:
                raise OSError("injected publication failure")
            return actual_replace(source, destination)

        def option(command, name):
            return Path(command[command.index(name) + 1])

        def fake_run(command, **kwargs):
            commands.append(command)
            if command[:2] == ["cabal", "build"]:
                return
            if command[:2] == ["cabal", "freeze"]:
                self.assertNotIn("GHC_PACKAGE_PATH", kwargs["env"])
                return
            name = command[2]
            if name == "normalise-freeze":
                option(command, "--out").write_text("candidate freeze")
                (self.stage / "cohort-sources.json").write_text("candidate sources")
            elif name in ["report", "impact", "update-constraints"]:
                option(command, "--out").write_text("candidate " + name)
            elif name == "check-retained" and reject_retained:
                raise subprocess.CalledProcessError(1, command)

        def fake_solve(command, **kwargs):
            commands.append(command)
            self.assertNotIn("GHC_PACKAGE_PATH", kwargs["env"])
            if mutate is not None:
                mutate()
            return subprocess.CompletedProcess(command, 0)

        arguments = ["cohort-update.py", "leaf", "--runtime-freeze", str(self.runtime)]
        if advance is not None:
            arguments += ["--advance-index-state", advance]
        with patch.object(updater.Path, "cwd", return_value=self.root), \
             patch.object(updater.tempfile, "mkdtemp", return_value=str(self.stage)), \
             patch.object(updater, "run", side_effect=fake_run), \
             patch.object(updater.subprocess, "run", side_effect=fake_solve), \
             patch.object(updater.subprocess, "check_output", return_value="/fake/cli\n"), \
             patch.object(updater.os, "replace", side_effect=replace), \
             patch.dict("os.environ", {"COHORT_GHC": "/fake/compiler/ghc", "COHORT_GHC_PKG": "/fake/compiler/ghc-pkg", "GHC_PACKAGE_PATH": "/unrelated/package-db"}), \
             patch("sys.argv", arguments):
            updater.main()
        return commands

    def test_reports_and_checks_use_captured_inputs_before_promotion(self):
        commands = self.run_workflow()
        report = next(command for command in commands if command[2] == "report")
        impact = next(command for command in commands if command[2] == "impact")
        retained = next(command for command in commands if command[2] == "check-retained")
        for command, option in [(report, "--inventory"), (report, "--lock"), (report, "--catalog"),
                                (report, "--policy-floors"), (impact, "--before"),
                                (impact, "--inventory"), (retained, "--before")]:
            self.assertTrue(Path(command[command.index(option) + 1]).is_relative_to(self.stage / "inputs"))
        for command in commands:
            if command[2] in ["normalise-freeze", "check"]:
                self.assertEqual(command[command.index("--compiler") + 1], "ghc-9.12.4")
            if command[:2] == ["cabal", "freeze"] or "--dry-run" in command:
                self.assertIn("--with-compiler=/fake/compiler/ghc", command)
                self.assertIn("--with-hc-pkg=/fake/compiler/ghc-pkg", command)
        self.assertEqual((self.root / "cabal/cohort.freeze").read_text(), "candidate freeze")

    def test_new_inventory_aborts_without_promoting(self):
        original = (self.root / "cabal/cohort.freeze").read_bytes()
        with self.assertRaisesRegex(SystemExit, "Recorded inputs changed"):
            self.run_workflow(mutate=lambda: (self.root / "cabal/inventory/new.json").write_text("new"))
        self.assertEqual((self.root / "cabal/cohort.freeze").read_bytes(), original)
        self.assertFalse((self.root / "cabal/cohort-impact.txt").exists())

    def test_retained_identity_failure_aborts_without_promoting(self):
        original = (self.root / "cabal/cohort.freeze").read_bytes()
        with self.assertRaises(subprocess.CalledProcessError):
            self.run_workflow(reject_retained=True)
        self.assertEqual((self.root / "cabal/cohort.freeze").read_bytes(), original)

    def test_explicit_index_transition_keeps_original_guard_and_publishes_consistent_inputs(self):
        original = updater.capture_inputs(self.root, self.runtime)
        requested = "2026-10-06T00:00:00Z"
        commands = self.run_workflow(advance=requested)
        retained = next(c for c in commands if c[2] == "update-constraints")
        self.assertEqual(retained[retained.index("--index-state") + 1], "2026-10-05T22:39:44Z")
        for command in commands:
            if "--dry-run" in command or command[:2] == ["cabal", "freeze"]:
                self.assertIn("--index-state=" + requested, command)
            if command[2] == "normalise-freeze":
                self.assertEqual(command[command.index("--index-state") + 1], requested)
        self.assertEqual((self.root / "cabal/common.config").read_text(), "index-state: hackage.haskell.org " + requested + "\n")
        inputs = json.loads((self.root / "cabal/inventory-inputs.json").read_text())
        self.assertEqual(inputs, dict(json.loads(original[self.root / "cabal/inventory-inputs.json"]), indexState=requested))
        self.assertEqual((self.stage / "inputs/cabal/common.config").read_bytes(), original[self.root / "cabal/common.config"])
        self.assertEqual(self.runtime.read_bytes(), original[self.runtime])

    def test_index_transition_identity_failure_preserves_every_recorded_input(self):
        before = updater.capture_inputs(self.root, self.runtime)
        with self.assertRaises(subprocess.CalledProcessError):
            self.run_workflow(advance="2026-10-06T00:00:00Z", reject_retained=True)
        self.assertEqual(updater.capture_inputs(self.root, self.runtime), before)

    def test_index_transition_partial_publication_failure_restores_all_outputs(self):
        before = updater.capture_inputs(self.root, self.runtime)
        with self.assertRaisesRegex(OSError, "injected publication failure"):
            self.run_workflow(advance="2026-10-06T00:00:00Z", fail_replace_at=5)
        self.assertEqual(updater.capture_inputs(self.root, self.runtime), before)
        self.assertFalse((self.root / "cabal/cohort-report.txt").exists())
        self.assertFalse((self.root / "cabal/cohort-impact.txt").exists())

    def test_invalid_index_transition_stops_before_staging_or_running_tools(self):
        for cutoff in ["2026-10-05T22:39:44Z", "2026-10-01T00:00:00Z", "2099-01-01T00:00:00Z", "2026-10-6T00:00:00Z", "HEAD"]:
            with self.subTest(cutoff=cutoff), \
                 patch.object(updater.tempfile, "mkdtemp", side_effect=AssertionError("staging must not run")), \
                 patch.object(updater.Path, "cwd", return_value=self.root), \
                 patch.dict("os.environ", {"COHORT_GHC": "/fake/ghc", "COHORT_GHC_PKG": "/fake/ghc-pkg"}), \
                 patch("sys.argv", ["cohort-update.py", "leaf", "--advance-index-state", cutoff]), \
                 self.assertRaises(SystemExit):
                updater.main()


if __name__ == "__main__":
    unittest.main()

from pathlib import Path
import hashlib,io,json,tarfile
repo=Path('/Users/shinzui/Keikaku/bokuno/haskell-nix');tmp=Path('/tmp');members={}
for n in [2,3]:
 for name in [f'ep19-retained-evaluation-v{n}.py',f'ep19-retained-evaluation-v{n}-driver.log',f'ep19-retained-evaluation-v{n}/receipt.json']:members[name]=(tmp/name).read_bytes()
members['ep19-retained-evaluation.nix']=(tmp/'ep19-retained-evaluation.nix').read_bytes();members['record.py']=Path(__file__).read_bytes()
r=json.loads(members['ep19-retained-evaluation-v3/receipt.json']);assert not r['measurements'];assert r['foreign_compiler_processes'];assert r['idle_preflight'][-1]['elapsed_seconds']<60
archive=repo/'docs/evidence/ep19/retained-evaluation-idle-preflight.raw.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for name,data in sorted(members.items()):
  info=tarfile.TarInfo(name);info.size=len(data);tar.addfile(info,io.BytesIO(data))
hashes={n:hashlib.sha256(d).hexdigest() for n,d in sorted(members.items())}
with tarfile.open(archive) as tar:
 for row in tar.getmembers():assert hashlib.sha256(tar.extractfile(row).read()).hexdigest()==hashes[row.name]
receipt={'schema_version':1,'revision':r['revision'],'status':'Idle preflight interrupted; no warm-up or timed trials ran','observed_idle_seconds':r['idle_preflight'][-1]['elapsed_seconds'],'required_idle_seconds':60,'foreign_processes':r['foreign_compiler_processes'],'timed_samples':0,'threshold':0.2,'monitor_correction':'The first setup matched Setup Assistant within a macOS path. The corrected monitor matches the complete executable basename and separately detects the actual Cabal process; no samples came from either setup.','timer_correction':'The prepared driver waits directly for evaluator termination while a separate thread monitors foreign work, avoiding poll-interval quantization of evaluation timings. This timing path was not reached.','scope':'Generation 3 versus generation 4, scoped base64-bytestring and full immutable Rei CLI queries. Existing accepted native/cache evidence remains unchanged.','next_action':'Coordinate a quiet native-host window before retrying; do not claim new performance acceptance.','raw_archive':{'path':str(archive.relative_to(repo)),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':hashes}}
(repo/'docs/evidence/ep19/retained-evaluation-idle-preflight.json').write_text(json.dumps(receipt,indent=2)+'\n');print('Verified',len(hashes),'raw members; zero timings')

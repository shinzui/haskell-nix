from pathlib import Path
import hashlib,io,json,re,subprocess,tarfile
repo=Path('/Users/shinzui/Keikaku/bokuno/haskell-nix');tmp=Path('/tmp');work=tmp/'ep19-targeted-update-rehearsal';members={}
def add(p,name): members[name]=Path(p).read_bytes()
receipt=json.loads((tmp/'ep19-targeted-update-receipt.json').read_text())
for name in ['cohort.freeze','cohort-sources.json','cohort-report.txt']:
 original=subprocess.check_output(['git','show','aad00f5:cabal/'+name],cwd=repo)
 assert (work/'cabal'/name).read_bytes()==original,name
 add(work/'cabal'/name,'accepted/'+name)
assert (work/'cabal/cohort-impact.txt').read_text()==''
assert (work/'cabal/common.config').read_bytes()==subprocess.check_output(['git','show','aad00f5:cabal/common.config'],cwd=repo)
for path,digest in receipt['conflict']['accepted_output_hashes_unchanged'].items():assert hashlib.sha256((work/'cabal'/path).read_bytes()).hexdigest()==digest
for name in ['ep19-Diff-upstream-tags.txt','ep19-targeted-update-Diff.log','ep19-targeted-update-Diff-stock.log','ep19-targeted-update-Diff-conflict.log','ep19-targeted-update-noop-receipt.json','ep19-targeted-update-receipt.json','ep19-targeted-update-preflight.log','ep19-targeted-update-preflight-valid.log','ep19-targeted-update-preflight-valid-driver.json','ep19-targeted-update-original-common.config','ep19-targeted-update-worktree.log','ep19-target-update-candidate-probe.py','ep19-target-update-flagless-probe.py','ep19-retained-evaluation.py','ep19-retained-evaluation.nix','ep19-retained-evaluation-driver.log']:add(tmp/name,'host/'+name)
for dirname in ['ep19-target-update-candidate-probe','ep19-target-update-flagless-probe','ep19-target-update-release-metadata','ep19-retained-evaluation']:
 for p in sorted((tmp/dirname).glob('*')):
  if p.is_file():add(p,dirname+'/'+p.name)
for label,log in [('initial','ep19-targeted-update-Diff.log'),('noop','ep19-targeted-update-Diff-stock.log'),('conflict','ep19-targeted-update-Diff-conflict.log'),('preflight-valid','ep19-targeted-update-preflight-valid.log')]:
 stage=Path(re.search(r'Targeted candidate and diagnostic logs: (\S+)',(tmp/log).read_text())[1])
 for name in ['retained.config','cohort.project','common.config','solve.log','cohort.freeze','cohort-sources.json','cohort-report.txt','cohort-impact.txt','dist-newstyle/cache/plan.json']:
  p=stage/name
  if p.is_file():add(p,'stages/'+label+'/'+name)
source=Path('/tmp/cohort-update-dgfugj9_/dist-newstyle/src/dhall-has_-9bd938b25d4bccb232be1abac10f02b16d1e713fed0f9f1b597e16cd0ea88184/dhall/dhall.cabal');assert re.search(r'Diff\s+>= 0.2\s+&& < 1.1',source.read_text());add(source,'primary/dhall.cabal')
add(repo/'scripts/cohort-update.py','code/cohort-update.py');add(Path(__file__),'record.py')
lock=json.loads((repo/'packages/runtime-lock.json').read_text())
for row in lock['runtimes']['keiro-runtime']:
 for path,digest in row['projections'].items():assert hashlib.sha256((repo/path).read_bytes()).hexdigest()==digest,path
archive=repo/'docs/evidence/ep19/targeted-maintenance-diagnostics.raw.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for name,data in sorted(members.items()):
  info=tarfile.TarInfo(name);info.size=len(data);tar.addfile(info,io.BytesIO(data))
hashes={name:hashlib.sha256(data).hexdigest() for name,data in sorted(members.items())}
with tarfile.open(archive) as tar:
 for row in tar.getmembers():assert hashlib.sha256(tar.extractfile(row).read()).hexdigest()==hashes[row.name]
receipt.update({'schema_version':1,'revision':'aad00f5','status':'No-op and negative conflict rehearsal; positive targeted update remains open','stock_compiler_preflight':{'missing_environment_exit_code':1,'fails_before_staging_and_build':True,'valid_workflow':json.loads((tmp/'ep19-targeted-update-preflight-valid-driver.json').read_text())},'retained_generations_all_projection_hashes_unchanged':True,'benchmark':json.loads((tmp/'ep19-retained-evaluation/receipt.json').read_text()),'upstream_release_evidence':{'registry':'https://hackage-content.haskell.org/package/Diff/preferred.json','tag_command':['git','ls-remote','--tags','https://github.com/seereason/Diff.git','refs/tags/2*'],'tag_2_0_1_commit':'0e94a65616f6429495863d743181cfe01a192aad'},'limits':['No real version/source/metadata/flag update occurred; no positive update, rollback-after-update or adoption acceptance.','The original default-shell attempt built the updater before reporting the missing stock compiler. Early compiler preflight now rejects that setup before staging/building; the stock-shell solve still passes.','No successful or uncontaminated evaluation timings were taken; foreign Cabal/GHC was detected before warm-up. Existing performance thresholds remain unmet.','Initial build and diagnostic attempts were not timed. Only the final warm no-op workflow has an elapsed receipt; no full generation/migration amortization claim.','The live registry survey does not prove that newer releases satisfy the frozen index or existing bounds.','Canonical owner of the blocking source is mori://dhall-lang/dhall-haskell, project-relative dhall/dhall.cabal at 03b40e85d0c677350ad2a2f75ef92627d5952cee; artifact-level source URI pending. Mori registry discovery remains unavailable because its database is absent.'],'raw_archive':{'path':str(archive.relative_to(repo)),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':hashes}})
(repo/'docs/evidence/ep19/targeted-maintenance-diagnostics.json').write_text(json.dumps(receipt,indent=2)+'\n');print('Verified',len(hashes),'members')

from pathlib import Path
import json,subprocess,concurrent.futures
sources=json.loads(Path('cabal/cohort-sources.json').read_text());root=Path('/tmp/ep19-target-update-candidate-probe');root.mkdir(exist_ok=False)
names=['file-embed','base64-bytestring','aeson','scientific','vector','unordered-containers','tasty','QuickCheck','cryptohash-sha256','entropy','random','optparse-applicative']
def probe(name):
 output=root/(name+'.json');result=subprocess.run(['curl','--fail','--location','--silent','--show-error','https://hackage.haskell.org/package/'+name+'/preferred.json','--output',str(output)],capture_output=True,text=True)
 if result.returncode:return {'package':name,'error':result.stderr.strip()}
 value=json.loads(output.read_text());versions=value['normal-version'];latest=max(versions,key=lambda v:tuple(map(int,v.split('.'))));current=sources[name]['version'];return {'package':name,'selected':current,'registry_preferred_latest':latest,'higher_release':tuple(map(int,latest.split('.')))>tuple(map(int,current.split('.')))}
with concurrent.futures.ThreadPoolExecutor(4) as pool:rows=list(pool.map(probe,names))
(root/'receipt.json').write_text(json.dumps({'scope':'Live registry discovery only. No bounds, pins, source selections or index-state changed. Upstream tags and fixed-index solver acceptance are still required before choosing a candidate.','packages':rows},indent=2)+'\n')
for row in rows:print(row)

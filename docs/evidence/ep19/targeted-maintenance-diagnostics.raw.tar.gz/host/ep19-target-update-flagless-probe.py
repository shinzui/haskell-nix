from pathlib import Path
import json,subprocess,concurrent.futures
sources=json.loads(Path('packages/runtime-lock.json').read_text())['runtimes']['keiro-runtime'][-1]['ownership'];root=Path('/tmp/ep19-target-update-flagless-probe');root.mkdir(exist_ok=False)
names=[name for name,p in sources.items() if p['source']=='Hackage' and all(not i.get('flags',{}) for i in p['identities'])]
def probe(name):
 output=root/(name+'.json');r=subprocess.run(['curl','--fail','--location','--silent','--show-error','--max-time','20','https://hackage.haskell.org/package/'+name+'/preferred.json','--output',str(output)],capture_output=True,text=True)
 if r.returncode:return {'package':name,'error':r.stderr.strip()}
 data=json.loads(output.read_text());latest=max(data['normal-version'],key=lambda v:tuple(map(int,v.split('.'))));current=sources[name]['version'];return {'package':name,'selected':current,'registry_preferred_latest':latest,'higher_release':tuple(map(int,latest.split('.')))>tuple(map(int,current.split('.')))}
with concurrent.futures.ThreadPoolExecutor(4) as pool:rows=list(pool.map(probe,names))
(root/'receipt.json').write_text(json.dumps({'scope':'Live registry discovery only; no bounds/pins changed and no claim that a release is admissible at the frozen index.','packages':rows},indent=2)+'\n')
print('Checked',len(rows),'flagless runtime Hackage packages')
for row in rows:
 if row.get('higher_release') or 'error' in row:print(row)

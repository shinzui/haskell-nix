import hashlib,json,platform,re,statistics,subprocess,time
from pathlib import Path
out=Path('/tmp/ep19-retained-evaluation');out.mkdir(exist_ok=True)
receipt={'revision':'3453274d8dd718c016549b64f8cc3d8345864220','minimum_saving':0.2,'baseline_generation':3,'candidate_generation':4,'system':platform.platform(),'cache_state':'Warm immutable source and converter outputs; fresh evaluator processes; eval-cache false identically; no target output build.','measurements':[],'foreign_compiler_processes':[]}
base=['nix','eval','--json','--impure','--offline','--no-write-lock-file','--option','eval-cache','false','--builders','','--file','/tmp/ep19-retained-evaluation.nix']
receipt['command_prefix']=base

def save(): (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
def foreign():
 lines=subprocess.check_output(['ps','-axo','pid=,comm='],text=True).splitlines()
 return [x.strip() for x in lines if re.search(r'/(ghc(?:-[0-9.]+)?|cabal)(?:\s|$)',x)]
def run(scope,trial,label):
 name=f'{scope}-{trial}-{label}';cmd=['/usr/bin/time','-l','-o',str(out/(name+'.time')),*base,'--arg','generation',str(3 if label=='baseline' else 4),'--argstr','scope',scope]
 if found:=foreign(): receipt['foreign_compiler_processes']+=found;save();raise SystemExit('Foreign compiler detected; campaign excluded')
 started=time.perf_counter()
 with (out/(name+'.out')).open('w') as stdout,(out/(name+'.log')).open('w') as stderr:
  proc=subprocess.Popen(cmd,stdout=stdout,stderr=stderr)
  while proc.poll() is None:
   if found:=foreign(): receipt['foreign_compiler_processes']+=found
   time.sleep(.2)
 elapsed=time.perf_counter()-started
 stats=(out/(name+'.time')).read_text();match=re.search(r'(\d+)\s+maximum resident set size',stats)
 row={'scope':scope,'trial':trial,'label':label,'exit_code':proc.returncode,'elapsed_seconds':elapsed,'max_rss_bytes_darwin':int(match.group(1)) if match else None,'output':(out/(name+'.out')).read_text().strip()};receipt['measurements'].append(row);save();print(name,proc.returncode,round(elapsed,4),flush=True)
 if proc.returncode or receipt['foreign_compiler_processes']:raise SystemExit('Failed or contaminated campaign; no acceptance claim')
 return row['output']
for scope in ['scoped','consumer']:
 expected=run(scope,0,'baseline');assert run(scope,0,'candidate')==expected
 for trial in range(1,6):
  for label in (['baseline','candidate'] if trial%2 else ['candidate','baseline']):assert run(scope,trial,label)==expected
 rows=[r for r in receipt['measurements'] if r['scope']==scope and r['trial']>0]
 med={label:statistics.median(r['elapsed_seconds'] for r in rows if r['label']==label) for label in ['baseline','candidate']}
 saving=1-med['candidate']/med['baseline'];receipt.setdefault('results',{})[scope]={'median_seconds':med,'saving_fraction':saving,'threshold_passed':saving>=.2,'spread_seconds':{label:[min(r['elapsed_seconds'] for r in rows if r['label']==label),max(r['elapsed_seconds'] for r in rows if r['label']==label)] for label in med}};save()
receipt['status']='measured';save()

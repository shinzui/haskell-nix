{ generation, scope }:
let
  f = builtins.getFlake "git+file:///Users/shinzui/Keikaku/bokuno/haskell-nix?rev=3453274d8dd718c016549b64f8cc3d8345864220";
  root = f.outPath;
  p = import f.inputs.nixpkgs { system = "aarch64-darwin"; };
  h = p.haskell.lib.compose;
  mk = import (root + "/lib/mkRuntimePackageSet.nix") { lib = p.lib; inherit root; };
  input = builtins.fromJSON (builtins.readFile /tmp/ep18-rei-resource-aware-split-v2/baseline/nix/runtime-selection.json);
  selected = mk (input // { inherit generation; channel = "github"; });
  app = import /tmp/ep18-rei-resource-aware-split-v2/baseline/nix/haskell-overlay.nix {
    pkgs = p; haskellLib = h; gitRev = "bad0388";
    sourceRoot = /tmp/ep18-rei-resource-aware-split-v2/baseline;
  };
  scoped = p.haskell.packages.ghc9124.override { overrides = selected.haskellExtension h p; };
  consumer = selected.mkApplicationScope p app;
in if scope == "scoped" then scoped.base64-bytestring.drvPath
   else if scope == "consumer" then consumer.rei-cli.drvPath
   else throw "unknown evaluation workload"

from pathlib import Path
import subprocess,shutil,json,time,hashlib
repo=Path('/tmp/ep19-targeted-update-rehearsal');returned=Path('/tmp/ep19-http2-linux-returned');rows=json.loads(Path('/tmp/ep19-http2-linux-artifacts-receipt.json').read_text());assert len(rows)==6 and all(x['exit_code']==0 for x in rows)
for channel in ['github','hackage']:
 dest=repo/'config/generated-recipes/keiro-runtime/x86_64-linux'/channel/'recipes';shutil.copytree(returned/channel/'recipes',dest,dirs_exist_ok=True)
 darwin=repo/'config/generated-recipes/keiro-runtime/aarch64-darwin'/channel/'recipes/packages'
 for name in ['base64-bytestring','http2']:assert (dest/'packages'/f'{name}.nix').read_bytes()==(darwin/f'{name}.nix').read_bytes()
subprocess.run(['git','add','config/generated-recipes'],cwd=repo,check=True)
cli=repo/'dist-newstyle/build/aarch64-osx/ghc-9.12.4/haskell-nix-update-0.1.0.0/x/haskell-nix-update/build/haskell-nix-update/haskell-nix-update';command=[str(cli),'runtime','snapshot','--name','keiro-runtime','--cohort-freeze','cabal/cohort.freeze'];start=time.perf_counter()
with open('/tmp/ep19-http2-runtime-capture.log','w') as log:r=subprocess.run(command,cwd=repo,stdout=log,stderr=subprocess.STDOUT)
Path('/tmp/ep19-http2-runtime-capture-receipt.json').write_text(json.dumps({'command':command,'exit_code':r.returncode,'elapsed_seconds':time.perf_counter()-start},indent=2)+'\n');raise SystemExit(r.returncode)

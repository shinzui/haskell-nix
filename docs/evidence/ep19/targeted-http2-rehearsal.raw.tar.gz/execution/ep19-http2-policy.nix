{ generation ? 5, scope ? "consumer" }:
let
  f = builtins.getFlake "git+file:///tmp/ep19-targeted-update-rehearsal";
  root = f.outPath;
  p = import f.inputs.nixpkgs { system = "aarch64-darwin"; };
  h = p.haskell.lib.compose;
  mk = import (root + "/lib/mkRuntimePackageSet.nix") { lib = p.lib; inherit root; };
  input = builtins.fromJSON (builtins.readFile /tmp/ep18-rei-resource-aware-split-v2/baseline/nix/runtime-selection.json);
  selected = mk (input // { inherit generation; channel = "github"; captureCompatibility = true; });
  app = import /tmp/ep18-rei-resource-aware-split-v2/baseline/nix/haskell-overlay.nix {
    pkgs = p; haskellLib = h; gitRev = "bad0388";
    sourceRoot = /tmp/ep18-rei-resource-aware-split-v2/baseline;
  };
  scoped = p.haskell.packages.ghc9124.override { overrides = selected.haskellExtension h p; };
  consumer = selected.mkApplicationScope p app;
in if scope == "scoped" then {
     base64 = scoped.base64-bytestring.drvPath;
     http2 = scoped.http2.drvPath;
   }
   else if scope == "consumer" then { drv = consumer.rei-cli.drvPath; out = consumer.rei-cli.outPath; }
   else if scope == "policy" then selected.compatibilityReport { pkgs = p; scope = consumer; names = [ "http2" "kiroku-metrics" "wai-app-static" "wai-extra" "wai-websockets" "warp" ]; }
   else if scope == "graph" then builtins.mapAttrs (name: _: scoped.${name}.drvPath) (p.lib.filterAttrs (_: entry: entry.source != "Boot") selected.metadata.ownership)
   else if scope == "package" then consumer.rei-cli
   else throw "unknown workload"

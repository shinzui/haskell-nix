let f = import /tmp/ep19-http2-consumer.nix; in f { generation = 5; scope = "scoped"; }

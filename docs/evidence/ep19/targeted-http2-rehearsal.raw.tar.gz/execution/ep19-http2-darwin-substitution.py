from pathlib import Path
import time,json,subprocess
ready=Path('/tmp/ep19-http2-darwin-publication-driver.json')
while not ready.exists():time.sleep(1)
assert json.loads(ready.read_text())['exit_code']==0
store=Path('/private/tmp/ep19-http2-darwin-empty-store');assert not store.exists(),'Use a new empty verification store; never clear one.'
command=['python3','scripts/cohort-cache.py','verify','--receipt','/tmp/ep19-http2-darwin-publication.json','--store','local?root='+str(store),'--evidence','/tmp/ep19-http2-darwin-substitution.json'];start=time.perf_counter()
with open('/tmp/ep19-http2-darwin-substitution.log','w') as log:r=subprocess.run(command,cwd='/Users/shinzui/Keikaku/bokuno/haskell-nix',stdout=log,stderr=subprocess.STDOUT)
Path('/tmp/ep19-http2-darwin-substitution-driver.json').write_text(json.dumps({'command':command,'exit_code':r.returncode,'elapsed_seconds':time.perf_counter()-start},indent=2)+'\n');raise SystemExit(r.returncode)

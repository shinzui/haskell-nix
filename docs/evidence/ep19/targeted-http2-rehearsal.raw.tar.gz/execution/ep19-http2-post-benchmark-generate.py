from pathlib import Path
import os,subprocess,time,json
repo=Path('/tmp/ep19-targeted-update-rehearsal'); terminal=[Path('/tmp/ep18-rei-resource-aware-paired-v4-driver-receipt.json'),Path('/tmp/ep18-rei-resource-aware-paired-v4-preflight.json')]
while not any(p.exists() for p in terminal):time.sleep(2)
cli=repo/'dist-newstyle/build/aarch64-osx/ghc-9.12.4/haskell-nix-update-0.1.0.0/x/haskell-nix-update/build/haskell-nix-update/haskell-nix-update'
command=[str(cli),'cohort','generate','--context-output','/tmp/ep19-http2-generation-context.json','--repository',str(repo)]
env=os.environ.copy();env['NIX_CONFIG']=env.get('NIX_CONFIG','')+'\nbuilders =\n';start=time.perf_counter()
with open('/tmp/ep19-http2-generate.log','w') as log:r=subprocess.run(command,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
Path('/tmp/ep19-http2-generate-receipt.json').write_text(json.dumps({'command':command,'exit_code':r.returncode,'elapsed_seconds':time.perf_counter()-start,'benchmark_terminal_evidence':[str(p) for p in terminal if p.exists()]},indent=2)+'\n');raise SystemExit(r.returncode)

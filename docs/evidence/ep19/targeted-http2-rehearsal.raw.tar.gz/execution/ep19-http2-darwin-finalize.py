from pathlib import Path
import subprocess,json,time,hashlib
repo=Path('/Users/shinzui/Keikaku/bokuno/haskell-nix');old=json.loads(Path('/tmp/ep19-http2-rollback-view.json').read_text());new=json.loads(Path('/tmp/ep19-http2-consumer-view.json').read_text());rows=[]
for args in [['--version'],['--help'],['help','time'],['--bash-completion-script','rei']]:
 observations=[]
 for label,value in [('baseline',old),('candidate',new)]:
  command=[value['out']+'/bin/rei',*args];r=subprocess.run(command,capture_output=True);name=f'ep19-http2-darwin-behavior-{len(rows)}-{label}';Path('/tmp',name+'.stdout').write_bytes(r.stdout);Path('/tmp',name+'.stderr').write_bytes(r.stderr);assert r.returncode==0,(command,r.stderr)
  observations.append({'label':label,'command':command,'exit_code':r.returncode,'stdout_sha256':hashlib.sha256(r.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(r.stderr).hexdigest()})
 assert observations[0]['stdout_sha256']==observations[1]['stdout_sha256'];rows.append({'arguments':args,'outputsIdentical':True,'observations':observations})
Path('/tmp/ep19-http2-darwin-behavior.json').write_text(json.dumps(rows,indent=2)+'\n')
command=['python3','scripts/cohort-cache.py','publish','--root',new['drv']+'^out','--receipt','/tmp/ep19-http2-darwin-publication.json'];started=time.perf_counter()
with open('/tmp/ep19-http2-darwin-publication.log','w') as log:r=subprocess.run(command,cwd=repo,stdout=log,stderr=subprocess.STDOUT)
Path('/tmp/ep19-http2-darwin-publication-driver.json').write_text(json.dumps({'command':command,'exit_code':r.returncode,'elapsed_seconds':time.perf_counter()-started},indent=2)+'\n');raise SystemExit(r.returncode)

from pathlib import Path
import json,hashlib,subprocess,time,os
repo=Path('/tmp/ep19-targeted-update-rehearsal');full=json.loads(Path('/tmp/ep19-http2-generation-context.json').read_text());entry=json.loads(Path('/tmp/ep19-http2-generated-entry.json').read_text());metadata=Path('/tmp/ep19-http2-5.4.9.cabal').read_bytes();archive=Path('/tmp/ep19-http2-5.4.9.tar.gz').read_bytes();identity=full['sources']['http2']['identities'][0]
assert hashlib.sha256(metadata).hexdigest()==identity['pkg-cabal-sha256'];assert hashlib.sha256(archive).hexdigest()==identity['pkg-src-sha256'];assert entry['version']=='5.4.9'
revision={k:v for k,v in json.loads(Path('/tmp/ep19-http2-5.4.9-revisions.json').read_text())[0].items() if k in ['number','sha256','time']}
cli=repo/'dist-newstyle/build/aarch64-osx/ghc-9.12.4/haskell-nix-update-0.1.0.0/x/haskell-nix-update/build/haskell-nix-update/haskell-nix-update';rows=[]
for system in ['aarch64-darwin','x86_64-linux']:
 for channel in ['github','hackage']:
  base=repo/'config/generated-recipes/keiro-runtime'/system/channel;path=base/'inputs/context.json';context=json.loads(path.read_text());generation=context['generationContext'];generation['freeze']['indexState']=full['freeze']['indexState'];generation['freeze']['versions']['http2']='5.4.9'
  if 'http2' in full['freeze']['flags']:generation['freeze']['flags']['http2']=full['freeze']['flags']['http2']
  generation['sources']['http2']=full['sources']['http2'];context['packages']['http2']={'archivePath':'http2-5.4.9.tar.gz','metadataPath':'http2.cabal','nativeArguments':{},'revision':revision,'unpackedHash':entry['sha256']}
  (base/'inputs/http2.cabal').write_bytes(metadata);(base/'inputs/http2-5.4.9.tar.gz').write_bytes(archive);path.write_text(json.dumps(context,sort_keys=True,separators=(',',':'))+'\n')
  if system=='aarch64-darwin':
   for mode in ['generate','check','generate']:
    command=[str(cli),'cohort','recipes',mode,'--context',str(path),'--out',str(base/'recipes')];start=time.perf_counter();log=Path('/tmp',f'ep19-http2-artifacts-{system}-{channel}-{len(rows)}.log')
    with log.open('w') as handle:result=subprocess.run(command,cwd=repo,stdout=handle,stderr=subprocess.STDOUT)
    rows.append({'system':system,'channel':channel,'mode':mode,'command':command,'exit_code':result.returncode,'elapsed_seconds':time.perf_counter()-start,'log':str(log)})
    Path('/tmp/ep19-http2-darwin-artifacts-receipt.json').write_text(json.dumps(rows,indent=2)+'\n')
    if result.returncode:raise SystemExit(result.returncode)
print('Staged all four input contexts; Darwin generate/check/repeat passed.')

from pathlib import Path
import subprocess,json,time,hashlib
base=Path('/tmp/ep19-http2-cells');cli='/nix/store/dc4vdm9x1hrplps9ynzb9nah9mp13v24-haskell-nix-update-0.1.0.0/bin/haskell-nix-update';rows=[]
for channel in ['github','hackage']:
 cell=base/channel
 for mode in ['generate','check','generate']:
  command=[cli,'cohort','recipes',mode,'--context',str(cell/'inputs/context.json'),'--out',str(cell/'recipes')];start=time.perf_counter();log=Path('/tmp',f'ep19-http2-linux-{channel}-{len(rows)}.log')
  with log.open('w') as f:result=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT)
  rows.append({'channel':channel,'mode':mode,'command':command,'exit_code':result.returncode,'elapsed_seconds':time.perf_counter()-start,'log':str(log),'artifacts':{str(p.relative_to(cell/'recipes')):hashlib.sha256(p.read_bytes()).hexdigest() for p in (cell/'recipes').rglob('*') if p.is_file()}})
  Path('/tmp/ep19-http2-linux-artifacts-receipt.json').write_text(json.dumps(rows,indent=2)+'\n')
  if result.returncode:raise SystemExit(result.returncode)
print('Both Linux cells generate/check/repeat passed.')

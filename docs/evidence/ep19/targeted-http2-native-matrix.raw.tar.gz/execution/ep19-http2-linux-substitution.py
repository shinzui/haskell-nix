from pathlib import Path
import subprocess,json,time
ready=Path('/tmp/ep19-http2-linux-publish-driver.json');started=time.perf_counter()
while True:
 if ready.exists():
  rows=json.loads(ready.read_text())
  assert all(row['exit_code']==0 for row in rows)
  if any(row['phase']=='publication' for row in rows):break
 if time.perf_counter()-started>600:raise SystemExit('Publisher has not completed; no substitution claim')
 time.sleep(1)
subprocess.run(['container','copy','/tmp/ep19-http2-linux-publication.json','mp3-linux-builder:/tmp/ep19-http2-linux-publication.json'],check=True,stdout=subprocess.DEVNULL)
check=['container','exec','mp3-linux-builder','/nix/store/b5bpi6zfajzzrwwpgba2q6li3nnya4bs-python3-3.14.7/bin/python3','-c','from pathlib import Path; assert not Path("/tmp/ep19-http2-linux-empty-store").exists()'];subprocess.run(check,check=True)
command=['container','exec','-e','NIX_CONFIG=experimental-features = nix-command flakes\nfilter-syscalls = false\nsandbox = false\nbuilders =','mp3-linux-builder','/nix/store/b5bpi6zfajzzrwwpgba2q6li3nnya4bs-python3-3.14.7/bin/python3','/workspace/scripts/cohort-cache.py','verify','--receipt','/tmp/ep19-http2-linux-publication.json','--store','local?root=/tmp/ep19-http2-linux-empty-store','--evidence','/tmp/ep19-http2-linux-substitution.json'];start=time.perf_counter()
with open('/tmp/ep19-http2-linux-substitution.log','w') as log:r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
Path('/tmp/ep19-http2-linux-substitution-driver.json').write_text(json.dumps({'command':command,'exit_code':r.returncode,'elapsed_seconds':time.perf_counter()-start},indent=2)+'\n');assert r.returncode==0
subprocess.run(['container','copy','mp3-linux-builder:/tmp/ep19-http2-linux-substitution.json','/tmp/ep19-http2-linux-substitution.json'],check=True,stdout=subprocess.DEVNULL);print('New empty translated-Linux store substituted published consumer closure with zero builds.')

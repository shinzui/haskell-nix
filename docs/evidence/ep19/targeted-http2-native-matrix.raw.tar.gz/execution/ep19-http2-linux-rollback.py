from pathlib import Path
import subprocess,json,time
view=json.loads(Path('/tmp/ep19-http2-linux-rollback-view.json').read_text());assert view['drv']=='/nix/store/gswfags3naialnr46c7dqhbcy0sv4xiy-rei-cli-7.1.0.0.drv';command=['nix','build','--no-link','--json','--builders','','--max-jobs','0',view['drv']+'^out'];start=time.perf_counter()
with open('/tmp/ep19-http2-linux-rollback-build.json','w') as out,open('/tmp/ep19-http2-linux-rollback-build.log','w') as log:r=subprocess.run(command,stdout=out,stderr=log)
Path('/tmp/ep19-http2-linux-rollback-receipt.json').write_text(json.dumps({'generation':4,'command':command,'exit_code':r.returncode,'elapsed_seconds':time.perf_counter()-start,'previousExactConsumerDerivationRestored':r.returncode==0,'view':view},indent=2)+'\n');assert r.returncode==0

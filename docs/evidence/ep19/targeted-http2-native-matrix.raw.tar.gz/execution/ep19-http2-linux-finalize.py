from pathlib import Path
import subprocess,json,hashlib,time
actual=json.loads(Path('/tmp/ep19-http2-linux-consumer-build.json').read_text())[0];expected=json.loads(Path('/tmp/ep19-http2-normalized-linux-consumer.json').read_text());assert actual['drvPath']==expected['drv'] and actual['outputs']['out']==expected['out'];old='/nix/store/dg97m5ypp1742m19hp2wjsavsklb31ki-rei-cli-7.1.0.0';new=actual['outputs']['out'];rows=[]
for args in [['--version'],['--help'],['help','time'],['--bash-completion-script','rei']]:
 observations=[]
 for label,path in [('baseline',old),('candidate',new)]:
  command=[path+'/bin/rei',*args];r=subprocess.run(command,capture_output=True);name=f'ep19-http2-linux-behavior-{len(rows)}-{label}';Path('/tmp',name+'.stdout').write_bytes(r.stdout);Path('/tmp',name+'.stderr').write_bytes(r.stderr);assert r.returncode==0,(command,r.stderr)
  observations.append({'label':label,'command':command,'exit_code':r.returncode,'stdout_sha256':hashlib.sha256(r.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(r.stderr).hexdigest()})
 assert observations[0]['stdout_sha256']==observations[1]['stdout_sha256'];rows.append({'arguments':args,'outputsIdentical':True,'observations':observations})
Path('/tmp/ep19-http2-linux-behavior.json').write_text(json.dumps(rows,indent=2)+'\n')
paths=[actual['drvPath'],new];metadata=subprocess.check_output(['nix','path-info','--json','--recursive',*paths]);Path('/tmp/ep19-http2-linux-build-closure-metadata.json').write_bytes(metadata)
command=['nix','copy','--to','file:///tmp/ep19-linux-publication-bridge?compression=zstd&parallel-compression=false',*paths];start=time.perf_counter()
with open('/tmp/ep19-http2-linux-bridge-export.log','w') as log:r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
Path('/tmp/ep19-http2-linux-bridge-export-driver.json').write_text(json.dumps({'command':command,'exit_code':r.returncode,'elapsed_seconds':time.perf_counter()-start,'execution':'Translated Apple x86 Linux guest; same actual native consumer derivation as generation 7.'},indent=2)+'\n');assert r.returncode==0;print('Native Linux consumer behavior agrees; original derivation/output exported through owned temporary file cache.')

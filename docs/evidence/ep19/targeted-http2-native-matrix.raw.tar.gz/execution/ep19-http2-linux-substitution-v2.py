from pathlib import Path
import subprocess,json,time
store=Path('/tmp/ep19-http2-linux-empty-store-v2');assert not store.exists();command=['/nix/store/b5bpi6zfajzzrwwpgba2q6li3nnya4bs-python3-3.14.7/bin/python3','/workspace/scripts/cohort-cache.py','verify','--receipt','/tmp/ep19-http2-linux-publication.json','--store','local?root='+str(store),'--evidence','/tmp/ep19-http2-linux-substitution-v2.json'];start=time.perf_counter()
with open('/tmp/ep19-http2-linux-substitution-v2.log','w') as log:r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
Path('/tmp/ep19-http2-linux-substitution-v2-driver.json').write_text(json.dumps({'command':command,'exit_code':r.returncode,'elapsed_seconds':time.perf_counter()-start,'networkSettings':{'stalled-download-timeout':30,'http-connections':4,'max-substitution-jobs':4},'qualification':'Independent second empty store; original incomplete verification store preserved.'},indent=2)+'\n');raise SystemExit(r.returncode)

from pathlib import Path
import subprocess
names=['ep19-http2-linux-consumer-build.json','ep19-http2-linux-consumer-build.log','ep19-http2-linux-behavior.json','ep19-http2-linux-build-closure-metadata.json','ep19-http2-linux-bridge-export.log','ep19-http2-linux-bridge-export-driver.json']
for trial in range(4):
 for label in ['baseline','candidate']:
  for suffix in ['stdout','stderr']:names.append(f'ep19-http2-linux-behavior-{trial}-{label}.{suffix}')
for name in names:subprocess.run(['container','copy','mp3-linux-builder:/tmp/'+name,'/tmp/'+name],check=True,stdout=subprocess.DEVNULL)
print('Copied native Linux build, behavior and original closure evidence.')

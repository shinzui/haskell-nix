from pathlib import Path
import subprocess,json,time
expected=json.loads(Path('/tmp/ep19-http2-linux-publication.json').read_text())['paths'];r=subprocess.run(['nix','path-info','--store','local?root=/tmp/ep19-http2-linux-empty-store','--all','--json'],capture_output=True,text=True,check=True);present=json.loads(r.stdout);missing={k:v for k,v in expected.items() if k not in present};process=Path('/proc/1710088');state={}
if process.exists():
 stats=(process/'stat').read_text().split();state={'state':stats[2],'cpuTicks':int(stats[13])+int(stats[14]),'waitChannel':(process/'wchan').read_text().strip()}
print(json.dumps({'validPaths':len(present),'missingExpectedPaths':len(missing),'largestMissing':[{'path':p,'narSize':v['narSize']} for p,v in sorted(missing.items(),key=lambda x:-x[1]['narSize'])[:4]],'process':state},indent=2))

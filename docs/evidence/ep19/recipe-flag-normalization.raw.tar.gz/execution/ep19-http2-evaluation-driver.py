from pathlib import Path
import subprocess,time,json
control=['container','exec','mp3-linux-builder','/nix/store/b5bpi6zfajzzrwwpgba2q6li3nnya4bs-python3-3.14.7/bin/python3','/tmp/ep19-linux-owned-build-control.py'];start=time.perf_counter();subprocess.run([*control,'pause'],check=True)
try:
 with open('/tmp/ep19-http2-evaluation-v1.log','w') as log:r=subprocess.run(['python3','/tmp/ep19-http2-evaluation-v1.py'],stdout=log,stderr=subprocess.STDOUT)
finally:
 resumed=subprocess.run([*control,'resume'],capture_output=True,text=True);Path('/tmp/ep19-http2-evaluation-resume.log').write_text(resumed.stdout+resumed.stderr);assert resumed.returncode==0,'Owned Linux build needs resume via controller'
Path('/tmp/ep19-http2-evaluation-driver.json').write_text(json.dumps({'exit_code':r.returncode,'elapsed_seconds_including_idle_preflight':time.perf_counter()-start,'ownedLinuxBuildResumed':True},indent=2)+'\n');raise SystemExit(r.returncode)

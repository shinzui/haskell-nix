let
  f = builtins.getFlake "git+file:///Users/shinzui/Keikaku/bokuno/haskell-nix?rev=7258125d6becdb96b53734de295bb63a7a4dbfdf";
  p = import f.inputs.nixpkgs { system = "aarch64-darwin"; };
  tests = import /Users/shinzui/Keikaku/bokuno/haskell-nix/checks/unit.nix { lib = p.lib; };
  names = builtins.attrNames tests;
in {
  count = builtins.length names;
  failures = builtins.filter (name: tests.${name}.expr != tests.${name}.expected) names;
}

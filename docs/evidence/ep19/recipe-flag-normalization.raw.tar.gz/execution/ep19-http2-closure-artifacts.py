from pathlib import Path
import json,hashlib,subprocess,time,sys
system=sys.argv[1];base=Path(sys.argv[2]);cli=sys.argv[3];rows=[]
def hashes(path):return {str(p.relative_to(path)):hashlib.sha256(p.read_bytes()).hexdigest() for p in path.rglob('*') if p.is_file()}
for channel in ['github','hackage']:
 cell=base/channel;accepted=None
 for index,mode in enumerate(['generate','check','generate']):
  command=[cli,'cohort','recipes',mode,'--context',str(cell/'inputs/context.json'),'--out',str(cell/'recipes')];log=Path('/tmp',f'ep19-http2-closure-{system}-{channel}-{index}.log');start=time.perf_counter()
  with log.open('w') as f:r=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT)
  current=hashes(cell/'recipes');rows.append({'system':system,'channel':channel,'mode':mode,'command':command,'exit_code':r.returncode,'elapsed_seconds':time.perf_counter()-start,'log':str(log),'artifacts':current})
  Path('/tmp',f'ep19-http2-closure-{system}-artifacts.json').write_text(json.dumps(rows,indent=2)+'\n')
  if r.returncode:raise SystemExit(r.returncode)
  if accepted is not None:assert current==accepted,'Regenerated output differs'
  accepted=current
print(system,'19 raw recipes generate/check/repeat in both channels passed byte-for-byte.')

{ generation, scope }:
let query = import /tmp/ep19-http2-consumer-immutable.nix;
in if scope == "scoped" then (query { inherit generation; scope = "scoped"; }).http2
else if scope == "consumer" then (query { inherit generation; scope = "consumer"; }).drv
else throw "unknown workload"

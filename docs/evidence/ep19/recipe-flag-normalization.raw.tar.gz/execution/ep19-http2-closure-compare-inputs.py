from pathlib import Path
import json,subprocess
old=json.loads(Path('/tmp/ep19-http2-after-graph-v2.json').read_text());new=json.loads(Path('/tmp/ep19-http2-closure-runtime-graph.json').read_text());impact=json.loads(Path('/tmp/ep19-http2-closure-derivation-impact.json').read_text());names=impact['changedConvertedPackages'];paths=sorted({p for n in names for p in [old[n],new[n]]});raw=subprocess.check_output(['nix','derivation','show',*paths]);Path('/tmp/ep19-http2-closure-direct-derivations.json').write_bytes(raw);export=json.loads(raw);data=export.get('derivations',export)
def get(path):return data.get(path,data.get(Path(path).name))
rows=[]
for name in names:
 a,b=get(old[name]),get(new[name]);fields={k:{'before':a['env'].get(k),'after':b['env'].get(k)} for k in sorted(set(a['env'])|set(b['env'])) if a['env'].get(k)!=b['env'].get(k) and k not in ['out','outputs']};rows.append({'package':name,'environmentDifferences':fields,'inputDerivationsDiffer':a.get('inputDrvs',a.get('inputs'))!=b.get('inputDrvs',b.get('inputs'))});print(name,fields)
Path('/tmp/ep19-http2-closure-input-comparison.json').write_text(json.dumps(rows,indent=2)+'\n')

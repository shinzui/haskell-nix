{ generation ? 5, scope ? "consumer" }:
let
  f = builtins.getFlake "git+file:///workspace?rev=df51c0e3d0e9e2326ef73ef949d2a3132db74342";
  root = f.outPath;
  p = import f.inputs.nixpkgs { system = "x86_64-linux"; };
  h = p.haskell.lib.compose;
  mk = import (root + "/lib/mkRuntimePackageSet.nix") { lib = p.lib; inherit root; };
  input = builtins.fromJSON (builtins.readFile /tmp/ep19-http2-rei-source/nix/runtime-selection.json);
  selected = mk (input // { inherit generation; channel = "github"; });
  app = import /tmp/ep19-http2-rei-source/nix/haskell-overlay.nix {
    pkgs = p; haskellLib = h; gitRev = "bad0388";
    sourceRoot = /tmp/ep19-http2-rei-source;
  };
  scoped = p.haskell.packages.ghc9124.override { overrides = selected.haskellExtension h p; };
  consumer = selected.mkApplicationScope p app;
in if scope == "scoped" then {
     base64 = scoped.base64-bytestring.drvPath;
     http2 = scoped.http2.drvPath;
   }
   else if scope == "consumer" then { drv = consumer.rei-cli.drvPath; out = consumer.rei-cli.outPath; }
   else if scope == "graph" then builtins.mapAttrs (name: _: scoped.${name}.drvPath) (p.lib.filterAttrs (_: entry: entry.source != "Boot") selected.metadata.ownership)
   else if scope == "package" then consumer.rei-cli
   else throw "unknown workload"

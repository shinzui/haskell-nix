from pathlib import Path
import json,hashlib,urllib.request,concurrent.futures,shutil
repo=Path('/tmp/ep19-targeted-update-rehearsal');full=json.loads(Path('/tmp/ep19-http2-generation-context.json').read_text());sources=full['sources'];entries=json.loads(Path('/tmp/ep19-http2-all-selected-entries.json').read_text());closed=set();todo=['http2']
while todo:
 name=todo.pop()
 if name in closed:continue
 closed.add(name);todo.extend(sources[name]['dependencies'])
names=sorted(n for n in closed if sources[n]['source']=='Hackage');assert len(names)==18
cache=Path('/tmp/ep19-http2-closure-input-cache');cache.mkdir(exist_ok=True)
def fetch(name):
 entry=entries[name];version=entry['version'];identities=sources[name]['identities'];metadata_hashes={i['pkg-cabal-sha256'] for i in identities};archive_hashes={i['pkg-src-sha256'] for i in identities};assert len(metadata_hashes)==len(archive_hashes)==1
 revision_number=0 if entry['revision'] is None else int(entry['revision']['number'])
 def get(url,accept=None):
  request=urllib.request.Request(url,headers={} if accept is None else {'Accept':accept});return urllib.request.urlopen(request,timeout=45).read()
 revisions=json.loads(get(f'https://hackage.haskell.org/package/{name}-{version}/revisions/','application/json'));selected=next(r for r in revisions if r['number']==revision_number);assert selected['sha256'] in metadata_hashes and selected['time']<=full['freeze']['indexState'];revision={k:selected[k] for k in ['number','sha256','time']}
 metadata=get(f'https://hackage-content.haskell.org/package/{name}-{version}/revision/{revision_number}.cabal');archive=get(f'https://hackage-content.haskell.org/package/{name}-{version}.tar.gz');assert hashlib.sha256(metadata).hexdigest() in metadata_hashes;assert hashlib.sha256(archive).hexdigest() in archive_hashes
 (cache/f'{name}.cabal').write_bytes(metadata);(cache/f'{name}-{version}.tar.gz').write_bytes(archive)
 return name,{'metadataPath':f'{name}.cabal','archivePath':f'{name}-{version}.tar.gz','unpackedHash':entry['sha256'],'revision':revision,'nativeArguments':{}}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:inputs=dict(pool.map(fetch,names))
for system in ['aarch64-darwin','x86_64-linux']:
 for channel in ['github','hackage']:
  base=repo/'config/generated-recipes/keiro-runtime'/system/channel;path=base/'inputs/context.json';context=json.loads(path.read_text());generation=context['generationContext']
  for name,value in inputs.items():
   generation['sources'][name]=sources[name];generation['freeze']['versions'][name]=full['freeze']['versions'][name]
   if name in full['freeze']['flags']:generation['freeze']['flags'][name]=full['freeze']['flags'][name]
   context['packages'][name]=value
   for field in ['metadataPath','archivePath']:shutil.copyfile(cache/value[field],base/'inputs'/value[field])
  path.write_text(json.dumps(context,sort_keys=True,separators=(',',':'))+'\n')
Path('/tmp/ep19-http2-closure-inputs.json').write_text(json.dumps({'root':'http2','dependencyClosure':sorted(closed),'generatedHackagePackages':names,'newBoundedArtifactCountIncludingBase64':19,'selectedInputs':inputs,'selectionAuthority':'Existing cohort generator output and solved source observations; no package version or bounds changes.'},indent=2)+'\n');print('Staged existing selected identities for 18-package http2 closure in all four input cells.')

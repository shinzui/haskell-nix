let
  f = builtins.getFlake "git+file:///workspace?rev=7258125d6becdb96b53734de295bb63a7a4dbfdf";
  p = import f.inputs.nixpkgs { system = "x86_64-linux"; };
  tests = import /workspace/checks/unit.nix { lib = p.lib; };
  names = builtins.attrNames tests;
in {
  count = builtins.length names;
  failures = builtins.filter (name: tests.${name}.expr != tests.${name}.expected) names;
}

from pathlib import Path
import os,sys,signal,json,time
record=Path('/tmp/ep19-http2-linux-pause.json')
if sys.argv[1]=='resume':
 data=json.loads(record.read_text());resumed=[]
 for item in data.get('processes',[]):
  try:os.kill(item['pid'],signal.SIGCONT);resumed.append(item['pid'])
  except ProcessLookupError:pass
 data['resumedAtUnix']=time.time();data['resumedPids']=resumed;record.write_text(json.dumps(data,indent=2)+'\n');print('Resumed',len(resumed),'owned build processes.');raise SystemExit(0)
processes={};roots=[]
for path in Path('/proc').iterdir():
 if not path.name.isdigit():continue
 try:
  fields=(path/'stat').read_text().split();name=(path/'comm').read_text().strip();pid=int(path.name);item={'pid':pid,'parent':int(fields[3]),'state':fields[2],'name':name};processes[pid]=item
  if name=='nix' and b'/tmp/ep19-http2-linux-consumer.nix' in (path/'cmdline').read_bytes():roots.append(pid)
 except (OSError,ValueError,IndexError):pass
if not roots:
 record.write_text(json.dumps({'status':'owned build already finished','processes':[],'pausedAtUnix':time.time()},indent=2)+'\n');print('No active owned build; nothing paused.');raise SystemExit(0)
assert len(roots)==1,roots
owned=set(roots)
while True:
 expanded=owned|{pid for pid,row in processes.items() if row['parent'] in owned}
 if expanded==owned:break
 owned=expanded
selected=[processes[pid] for pid in sorted(owned) if pid not in roots and processes[pid]['state']!='Z'];assert selected,'Cannot identify owned compiler children safely'
for item in reversed(selected):os.kill(item['pid'],signal.SIGSTOP)
record.write_text(json.dumps({'status':'owned child processes paused for isolated host evaluation','rootPid':roots[0],'processes':selected,'pausedAtUnix':time.time()},indent=2)+'\n');print(json.dumps(selected))

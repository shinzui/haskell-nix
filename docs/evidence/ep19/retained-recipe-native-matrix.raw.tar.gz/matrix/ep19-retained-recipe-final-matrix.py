from pathlib import Path
import subprocess,concurrent.futures,time,json,shlex
rev=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();results={}
def run(system):
 prefix='/tmp/ep19-retained-recipe-final-'+system;root='git+file:///workspace' if system=='linux' else 'git+file:///Users/shinzui/Keikaku/bokuno/haskell-nix';target=root+'?rev='+rev
 nix=['nix','flake','check',target,'--print-build-logs','--max-jobs','1','--cores','1' if system=='linux' else '16','--builders','']
 if system=='linux':command=['container','exec','--env','NIX_CONFIG=experimental-features = nix-command flakes\nfilter-syscalls = false\nsandbox = false','mp3-linux-builder','sh','-c',shlex.join(nix)+' > '+prefix+'.out 2> '+prefix+'.log']
 else:command=nix
 start=time.monotonic()
 with Path(prefix+'-driver.log').open('w') as out:
  if system=='linux':r=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT)
  else:r=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT)
 receipt={'revision':rev,'command':command,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-start,'system':'x86_64-linux' if system=='linux' else 'aarch64-darwin','scope':'Full immutable flake check. Linux uses Rosetta, independent warm store, sandbox/filter-syscalls false and one build core; correctness only.'}
 Path(prefix+'-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');return system,receipt
with concurrent.futures.ThreadPoolExecutor(2) as pool:
 futures=[pool.submit(run,s) for s in ['darwin','linux']]
 for future in concurrent.futures.as_completed(futures):
  system,receipt=future.result();results[system]=receipt;Path('/tmp/ep19-retained-recipe-final-matrix-progress.json').write_text(json.dumps(results,indent=2)+'\n');print(system,receipt['exit_code'],flush=True)
assert all(r['exit_code']==0 for r in results.values()),results
print('FULL_RETAINED_RECIPE_MATRIX_PASSED',flush=True)

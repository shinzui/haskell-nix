from pathlib import Path
import json,subprocess,hashlib,shutil,time,os
root=Path('/tmp/ep19-source-pin-context-inputs');out=Path('/tmp/ep19-source-pin-artifacts-v1');log=Path('/tmp/ep19-source-pin-exercise');log.mkdir(exist_ok=False)
binary='/Users/shinzui/Keikaku/bokuno/haskell-nix/dist-newstyle/build/aarch64-osx/ghc-9.12.4/haskell-nix-update-0.1.0.0/x/haskell-nix-update/build/haskell-nix-update/haskell-nix-update';results=[]
def tree(d):return {str(p.relative_to(d)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(d.rglob('*')) if p.is_file()}
first=tree(out)
def run(name,operation,context=root/'context.json',target=out,expected=0):
 cmd=[binary,'cohort','recipes',operation,'--context',str(context),'--out',str(target)];env=os.environ.copy();env.update({'HTTP_PROXY':'http://127.0.0.1:9','HTTPS_PROXY':'http://127.0.0.1:9','ALL_PROXY':'http://127.0.0.1:9'});start=time.monotonic();r=subprocess.run(cmd,capture_output=True,text=True,env=env);(log/(name+'.log')).write_text(r.stdout+r.stderr);results.append({'name':name,'command':cmd,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-start});assert r.returncode==expected,(name,r.stderr)
run('repeat','generate');assert tree(out)==first
run('check','check');assert tree(out)==first
relocated=Path('/tmp/ep19-source-pin-context-relocated');shutil.copytree(root,relocated);second=Path('/tmp/ep19-source-pin-artifacts-relocated');run('relocated','generate',relocated/'context.json',second);assert tree(second)==first
for name in ['cmark-gfm.cabal','cmark-gfm-hs-a9014e8.tar.gz']:
 p=root/name;original=p.read_bytes()
 try:
  p.write_bytes(original+b'\ncontrolled source drift\n');run('reject-'+name,'generate',expected=1);assert tree(out)==first
 finally:p.write_bytes(original)
p=root/'context.json';original=p.read_bytes();cfg=json.loads(original)
try:
 cfg['packages']['cmark-gfm']['sourcePin']['revision']='b'*40;p.write_text(json.dumps(cfg));run('reject-revision','generate',expected=1);assert tree(out)==first
finally:p.write_bytes(original)
(log/'receipt.json').write_text(json.dumps({'status':'passed','results':results,'artifact_tree_sha256s':first,'repeat_and_relocation_byte_identical':True,'changed_metadata_archive_revision_rejected':True,'accepted_outputs_unchanged':True,'network':'Unreachable HTTP proxies; all source verification and checking uses supplied local inputs.'},indent=2)+'\n');print('source pin artifact exercises passed')

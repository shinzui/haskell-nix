let
 f=builtins.getFlake "git+file:///workspace?rev=5c294266c3fbcfb2130e86c798ff3de18343fe50";
 p=import f.inputs.nixpkgs {system="x86_64-linux";}; h=p.haskell.lib.compose;
 runtime=f.lib.mkRuntimePackageSet {runtime="keiro-runtime";generation=1;channel="github";disableProfiling=true;disableHaddock=true;applicationSelections={kioku=8;okf=5;openapi-hs=1;relay-pagination=3;servant-openapi-hs=1;shikumi-baikai=9;};};
 extension=import /tmp/ep19-artifacts-linux-5c29426/artifacts/extension.nix {pkgs=p;haskellLib=h;policyExtension=_:previous:{base64-bytestring=h.dontCheck previous.base64-bytestring;};};
 legacy=runtime.mkApplicationScope p (_:_:{ }); checked=runtime.mkApplicationScope p extension;
 scoped=p.haskell.packages.ghc9124.override {overrides=p.lib.composeExtensions (runtime.haskellExtension h p) extension;};
 in { scoped=scoped.base64-bytestring.drvPath;
 identity=assert legacy.base64-bytestring.drvPath==checked.base64-bytestring.drvPath; assert checked.base64-bytestring.drvPath==scoped.base64-bytestring.drvPath;
 {legacy=legacy.base64-bytestring.drvPath;candidate=checked.base64-bytestring.drvPath;compiler=checked.ghc.drvPath;runtime=runtime.metadata.fingerprint;};}

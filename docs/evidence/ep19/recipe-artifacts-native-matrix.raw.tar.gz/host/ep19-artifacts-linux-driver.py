from pathlib import Path
import subprocess,json,time,tarfile,hashlib,os
revision='5c294266c3fbcfb2130e86c798ff3de18343fe50';root=Path('/tmp/ep19-artifacts-linux-'+revision[:7]);root.mkdir(exist_ok=False);results=[]
def run(name,command,expected=0):
 start=time.monotonic();env=os.environ.copy();env.update({'HTTP_PROXY':'http://127.0.0.1:9','HTTPS_PROXY':'http://127.0.0.1:9','ALL_PROXY':'http://127.0.0.1:9'})
 with (root/(name+'.log')).open('w') as err,(root/(name+'.out')).open('w') as out:r=subprocess.run(command,stdout=out,stderr=err,env=env)
 results.append({'name':name,'command':command,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-start});(root/'progress.json').write_text(json.dumps(results,indent=2)+'\n');assert r.returncode==expected,(name,r.returncode,(root/(name+'.log')).read_text()[-3000:]);return (root/(name+'.out')).read_text()
# All source metadata is already supplied in the reviewed evidence bundle.
payload=root/'payload';payload.mkdir()
with tarfile.open('/workspace/docs/evidence/ep19/recipe-artifacts-prototype.raw.tar.gz') as t:t.extractall(payload,filter='data')
expr='let f = builtins.getFlake "git+file:///workspace?rev='+revision+'"; p = import f.inputs.nixpkgs { system="x86_64-linux"; }; in p.buildPackages.haskellPackages.cabal2nix-unstable.bin'
# The actual translation tool is already warm from the accepted native gates.
tool=json.loads(run('converter',['nix','build','--impure','--expr',expr,'--json','--no-link','--max-jobs','1','--cores','8','--builders','']))[0]
converter=tool['outputs']['bin'];version=run('converter-version',[converter+'/bin/cabal2nix','--version']).strip()
context=payload/'inputs/context.json';value=json.loads(context.read_text());value['configuration']['system']='x86_64-linux';value['configuration']['converter']={'derivation':tool['drvPath'],'output':converter,'version':version};context.write_text(json.dumps(value,sort_keys=True,indent=2)+'\n')
updater=json.loads(Path('/tmp/ep19-recipe-artifacts-native-linux-outputs.json').read_text())[0]['outputs']['out']+'/bin/haskell-nix-update';output=root/'artifacts'
run('generate',[updater,'cohort','recipes','generate','--context',str(context),'--out',str(output)])
def tree(path):return {str(p.relative_to(path)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(path.rglob('*')) if p.is_file()}
first=tree(output);run('check',[updater,'cohort','recipes','check','--context',str(context),'--out',str(output)]);assert tree(output)==first
run('repeat',[updater,'cohort','recipes','generate','--context',str(context),'--out',str(output)]);assert tree(output)==first
source=context.parent/'base64-bytestring.cabal';original=source.read_bytes()
try:
 source.write_bytes(original+b'\ncontrolled drift\n');run('reject-metadata',[updater,'cohort','recipes','generate','--context',str(context),'--out',str(output)],1);assert tree(output)==first
finally:source.write_bytes(original)
parity=root/'parity.nix';parity.write_text('''let
 f=builtins.getFlake "git+file:///workspace?rev='''+revision+'''";
 p=import f.inputs.nixpkgs {system="x86_64-linux";}; h=p.haskell.lib.compose;
 runtime=f.lib.mkRuntimePackageSet {runtime="keiro-runtime";generation=1;channel="github";disableProfiling=true;disableHaddock=true;applicationSelections={kioku=8;okf=5;openapi-hs=1;relay-pagination=3;servant-openapi-hs=1;shikumi-baikai=9;};};
 extension=import '''+str(output)+'''/extension.nix {pkgs=p;haskellLib=h;policyExtension=_:previous:{base64-bytestring=h.dontCheck previous.base64-bytestring;};};
 legacy=runtime.mkApplicationScope p (_:_:{ }); checked=runtime.mkApplicationScope p extension;
 scoped=p.haskell.packages.ghc9124.override {overrides=p.lib.composeExtensions (runtime.haskellExtension h p) extension;};
 in { scoped=scoped.base64-bytestring.drvPath;
 identity=assert legacy.base64-bytestring.drvPath==checked.base64-bytestring.drvPath; assert checked.base64-bytestring.drvPath==scoped.base64-bytestring.drvPath;
 {legacy=legacy.base64-bytestring.drvPath;candidate=checked.base64-bytestring.drvPath;compiler=checked.ghc.drvPath;runtime=runtime.metadata.fingerprint;};}
''')
scoped=json.loads(run('no-ifd',['nix','eval','--impure','--json','--file',str(parity),'scoped','--option','allow-import-from-derivation','false','--max-jobs','0','--builders','']))
identity=json.loads(run('parity',['nix','eval','--impure','--json','--file',str(parity),'identity','--max-jobs','0','--builders','']));assert scoped==identity['candidate']==identity['legacy']
(root/'receipt.json').write_text(json.dumps({'revision':revision,'status':'passed','system':'x86_64-linux','execution':'Apple amd64 guest using Rosetta translation; independent warm store, sandbox/filter-syscalls false. Correctness only.','results':results,'artifact_tree_sha256s':first,'identity':identity,'scope':'One generated Hackage root. Actual Rei consumer parity is separately accepted on Darwin. Complete source-pin conversion, retained factory adapter, performance and production adoption remain pending.'},indent=2)+'\n');print('LINUX_ARTIFACTS_PASSED',flush=True)

import json,subprocess,re,tempfile,os,time
from pathlib import Path
r=Path(__file__).parent;summary=json.loads((r/'executable-final-pairs/summary.json').read_text());rows={x['label']:x for x in summary['trials'] if x['trial']==1};assert len(rows)==2
text=Path('/tmp/ep18-rei-delivery-baseline/rei-cli/rei-cli.cabal').read_text();library=text.split('\nlibrary\n',1)[1].split('\nexecutable ',1)[0];field=library.split('  exposed-modules:\n',1)[1].split('\n  build-depends:',1)[0];modules=re.findall(r'^    ([A-Z][\w.]*)$',field,re.M);assert len(modules)==297
record={'module_count':len(modules),'checks':[]};start=time.perf_counter()
with tempfile.TemporaryDirectory(prefix='ep18-public-sdk-') as temporary:
 env={k:v for k,v in os.environ.items() if not any(x in k for x in ['DATABASE','PG_CONNECTION','REI_CONFIG','MORI_CONFIG'])};env.update(HOME=temporary,XDG_CONFIG_HOME=temporary,NO_COLOR='1',TERM='dumb')
 source=Path(temporary)/'PublicModules.hs';source.write_text('module PublicModules where\n'+''.join('import '+m+' ()\n' for m in modules))
 for label in ['baseline','candidate']:
  drv=rows[label]['identity']['registrationCompiler'];t=time.perf_counter();result=json.loads(subprocess.check_output(['nix','build',drv+'^out','--json','--no-link','--max-jobs','1']));compiler=result[0]['outputs']['out']
  q=subprocess.run([compiler+'/bin/ghc','-fno-code','-hide-all-packages','-package','base','-package','rei-cli',str(source)],cwd=temporary,env=env,capture_output=True,timeout=60);(r/('public-'+label+'.log')).write_bytes(q.stdout+q.stderr);assert q.returncode==0,(label,q.stderr[-1000:]);record['checks'].append({'label':label,'compiler':drv,'passed':True,'elapsed_seconds':time.perf_counter()-t})
 assert rows['baseline']['identity']['sdkRegistrationCompiler']==rows['candidate']['identity']['sdkRegistrationCompiler']
 drv=rows['candidate']['identity']['sdkRegistrationCompiler'];result=json.loads(subprocess.check_output(['nix','build',drv+'^out','--json','--no-link','--max-jobs','1']));compiler=result[0]['outputs']['out'];t=time.perf_counter()
 q=subprocess.run([compiler+'/bin/ghci','-ignore-dot-ghci','-v0'],input=b':module +Rei.Cli.Commands.Info\nprint versionString\n:quit\n',cwd=temporary,env=env,capture_output=True,timeout=60);(r/'public-sdk-ghci.log').write_bytes(q.stdout+q.stderr);assert q.returncode==0 and b'dirty' in q.stdout and not q.stderr,(q.stdout,q.stderr)
 record['ghci']={'compiler':drv,'passed':True,'elapsed_seconds':time.perf_counter()-t}
record['total_elapsed_seconds']=time.perf_counter()-start;(r/'public-library-check.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))

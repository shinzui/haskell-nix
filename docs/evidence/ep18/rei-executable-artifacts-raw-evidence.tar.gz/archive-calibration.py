import sys,importlib.util,json,os
from pathlib import Path
from types import SimpleNamespace
sys.path.insert(0,'/Users/shinzui/Keikaku/bokuno/haskell-nix/scripts')
spec=importlib.util.spec_from_file_location('measurement','/Users/shinzui/Keikaku/bokuno/haskell-nix/scripts/measure-application-nix-builds.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
r=Path(__file__).parent;destination=r/'archive-calibration';destination.mkdir()
args=SimpleNamespace(expression=Path('/Users/shinzui/Keikaku/bokuno/haskell-nix/checks/fixtures/application-builds/producer.nix'),normal_default=True,output_dir=destination,cores=16,require_idle_compilers=False,idle_wait_seconds=60,resource_policy='mac-studio',replace=None,edit=Path('rei-cli/src/Rei/Cli/Commands/Help.hs'))
record=m.run_trial(args,'candidate',Path('/tmp/ep18-rei-archive-candidate'),0,'calibration')
(destination/'summary.json').write_text(json.dumps({'purpose':'Single native combined-archive omission feasibility calibration; not performance acceptance.','trial':record},indent=2)+'\n')

{ source }:
let
  app = builtins.getFlake "git+file://${source}";
  system = "aarch64-darwin";
  packages = app.packages.${system};
  package = packages.default;
  pkgs = import app.inputs.nixpkgs { inherit system; };
in {
  inherit package;
  identity = {
    root = package.drvPath;
    core = packages.rei-core.drvPath;
    compiler = pkgs.haskell.packages.ghc9124.ghc.drvPath;
    component = "cli";
    experimentMode = "package-split";
    packageSplit = packages ? rei-cli-foundation;
    foundation = if packages ? rei-cli-foundation then packages.rei-cli-foundation.drvPath else null;
    splitManifest = "/tmp/ep18-rei-delivery-prepared/split-manifest.json";
    compatibilityReport = { enabled = false; accepted = false; reason = "Ordinary producer #default, no intermediates"; };
  };
}

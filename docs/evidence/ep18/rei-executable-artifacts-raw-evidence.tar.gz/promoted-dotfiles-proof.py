import json,subprocess,os,tempfile,hashlib,re
from pathlib import Path
r=Path(__file__).parent;producer=json.loads((r/'promoted-producer-default-v2.stdout').read_text())[0];wrapper=json.loads((r/'promoted-dotfiles-wrapper.stdout').read_text())[0]
g=json.loads(subprocess.check_output(['nix','derivation','show','--recursive',wrapper['drvPath']]));(r/'promoted-dotfiles-wrapper.graph.json').write_text(json.dumps(g,sort_keys=True)+'\n');nodes=g.get('derivations',g);root=Path(producer['drvPath']).name;names=[k for k,v in nodes.items() if v['env'].get('pname')=='rei-cli'];assert names==[root] or names==[producer['drvPath']],names
log=(r/'promoted-dotfiles-wrapper.log').read_text();assert not re.search(r'> \[\s*\d+ of\s*\d+\] Compiling',log)
with tempfile.TemporaryDirectory(prefix='ep18-dotfiles-version-') as home:
 env={k:v for k,v in os.environ.items() if not any(x in k for x in ['DATABASE','PG_CONNECTION','REI_CONFIG','MORI_CONFIG'])};env.update(HOME=home,XDG_CONFIG_HOME=home)
 texts=[]
 for row in [producer,wrapper]:
  q=subprocess.run([row['outputs']['out']+'/bin/rei','--version'],env=env,capture_output=True,timeout=30);assert q.returncode==0 and b'98a5047' in q.stdout;assert not q.stderr;texts.append(q.stdout)
 assert texts[0]==texts[1]
repo=Path('/Users/shinzui/.config/dotfiles.nix');unchanged=(repo/'flake.lock').read_bytes()==subprocess.check_output(['git','show','HEAD:flake.lock'],cwd=repo);assert unchanged
record={'producer_project':'mori://shinzui/rei','consumer_project':'mori://shinzui/dotfiles.nix','revision':'98a5047da9ac99a54a899405bc166a42a073355d','producer':producer,'wrapper':wrapper,'sole_actual_cli_derivation':names[0],'matching_truthful_version':True,'wrapper_ghc_compilations':0,'dotfiles_lock_unchanged':True,'scope':'Actual yujin package overlay, normal project pins with a read-only immutable source override; no activation.'}
(r/'promoted-dotfiles-proof.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))

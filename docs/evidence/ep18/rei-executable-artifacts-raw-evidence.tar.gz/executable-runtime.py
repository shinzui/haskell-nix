import json,subprocess,os,time,tempfile,statistics,hashlib
from pathlib import Path
r=Path(__file__).parent
rows={'baseline':json.loads((r/'fresh-setup/fresh-setup-1-baseline.receipt.json').read_text()),'candidate':json.loads((r/'executable-calibration/calibration-0-candidate.receipt.json').read_text())}
outputs={k:v['build_result'][0]['outputs']['out'] for k,v in rows.items()}
record={'qualification':'Twenty warm alternating startup observations per command; static baseline has a behavior-neutral source comment. No build-speed acceptance is inferred.','commands':[],'closure':{}}
with tempfile.TemporaryDirectory(prefix='ep18-linkage-runtime-') as home:
 env={k:v for k,v in os.environ.items() if not any(x in k for x in ['DATABASE','PG_CONNECTION','REI_CONFIG','MORI_CONFIG','DYLD','LD_LIBRARY'])};env.update(HOME=home,XDG_CONFIG_HOME=home,NO_COLOR='1',TERM='dumb')
 for args in [['--version'],['--help'],['help','time'],['completions','zsh'],['--bash-completion-script','rei']]:
  times={k:[] for k in outputs};hashes={}
  for trial in range(20):
   for label in (['baseline','candidate'] if trial%2==0 else ['candidate','baseline']):
    start=time.perf_counter();p=subprocess.run([outputs[label]+'/bin/rei',*args],env=env,capture_output=True,timeout=30);elapsed=time.perf_counter()-start
    assert p.returncode==0,(label,args,p.stderr[-500:]);digest=hashlib.sha256(p.stdout+b'\0'+p.stderr).hexdigest();assert label not in hashes or hashes[label]==digest
    hashes[label]=digest;times[label].append(elapsed)
  assert len(set(hashes.values()))==1,(args,hashes)
  record['commands'].append({'arguments':args,'seconds':times,'median_seconds':{k:statistics.median(v) for k,v in times.items()},'matching_behavior':True})
for label,out in outputs.items():
 data=json.loads(subprocess.check_output(['nix','path-info','--json','--recursive',out]));data={x['path']:x for x in data} if isinstance(data,list) else data
 record['closure'][label]={'paths':len(data),'nar_bytes':sum(x['narSize'] for x in data.values())}
(r/'executable-runtime.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'commands':[{'arguments':x['arguments'],'median_seconds':x['median_seconds']} for x in record['commands']],'closure':record['closure']}))

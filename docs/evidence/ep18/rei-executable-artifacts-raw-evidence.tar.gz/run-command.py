import argparse,json,subprocess,time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--cwd',required=True);p.add_argument('--label',required=True);p.add_argument('command',nargs=argparse.REMAINDER);a=p.parse_args()
r=Path(__file__).parent; start=time.time();t=time.monotonic()
with (r/(a.label+'.stdout')).open('w') as out,(r/(a.label+'.log')).open('w') as err:
 code=subprocess.run(a.command,cwd=a.cwd,stdout=out,stderr=err).returncode
d={'command':a.command,'cwd':a.cwd,'start':start,'elapsed_seconds':time.monotonic()-t,'exit_code':code}
(r/(a.label+'.json')).write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d));raise SystemExit(code)

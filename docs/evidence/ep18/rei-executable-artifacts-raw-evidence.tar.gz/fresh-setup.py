import sys,importlib.util,json,os,time
from pathlib import Path
from types import SimpleNamespace
sys.path.insert(0,'/Users/shinzui/Keikaku/bokuno/haskell-nix/scripts')
spec=importlib.util.spec_from_file_location('measurement','/Users/shinzui/Keikaku/bokuno/haskell-nix/scripts/measure-application-nix-builds.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
r=Path(__file__).parent;destination=r/'fresh-setup';destination.mkdir()
os.environ['MP4_APPLICATION_SPLIT_MANIFEST']='/tmp/ep18-rei-delivery-prepared/split-manifest.json'
roots={label:Path('/tmp/ep18-rei-delivery-'+label) for label in ['baseline','candidate']}
paths={label:root/('rei-cli-foundation' if label=='candidate' else 'rei-cli')/'src/Rei/Cli/Commands/Action/Types.hs' for label,root in roots.items()}
original={label:p.read_bytes() for label,p in paths.items()};assert original['baseline']==original['candidate']
args=SimpleNamespace(expression=Path('/Users/shinzui/Keikaku/bokuno/haskell-nix/checks/fixtures/application-builds/producer.nix'),normal_default=True,output_dir=destination,cores=16,require_idle_compilers=False,idle_wait_seconds=60,resource_policy='mac-studio',replace=None)
records=[]
try:
 for label,p in paths.items():p.write_bytes(original[label]+b'\n-- EP-18 fresh production package setup, delivery v1.\n')
 for label,root in roots.items():
  args.edit=paths[label].relative_to(root);records.append(m.run_trial(args,label,root,1,'fresh-setup'))
 (destination/'summary.json').write_text(json.dumps({'purpose':'One fresh content-equivalent application/foundation creation pair. Shared core/dependencies already warm; not a paired speedup claim. Extra candidate time screens migration and foundation-refresh cost.','trials':records,'candidate_extra_seconds':records[1]['elapsed_seconds']-records[0]['elapsed_seconds']},indent=2)+'\n')
finally:
 for label,p in paths.items():p.write_bytes(original[label])

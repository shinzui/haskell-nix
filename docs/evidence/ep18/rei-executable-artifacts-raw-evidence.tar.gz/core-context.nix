{ source }:
let
 app = builtins.getFlake "git+file://${source}";
 pkgs = import app.inputs.nixpkgs { system = "aarch64-darwin"; };
 runtime = app.inputs.haskell-nix.lib.mkRuntimePackageSet (builtins.fromJSON (builtins.readFile (builtins.toPath source + "/nix/runtime-selection.json")));
 scope = runtime.mkApplicationScope pkgs (app.lib.haskellExtension pkgs.haskell.lib.compose pkgs);
in { compiler = scope.ghcWithPackages (p: [ p.rei-core ]); core = scope.rei-core.drvPath; }

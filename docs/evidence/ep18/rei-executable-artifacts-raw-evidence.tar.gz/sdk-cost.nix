let
  app = builtins.getFlake "git+file:///tmp/ep18-rei-sdk-cost-source";
  pkgs = import app.inputs.nixpkgs { system = "aarch64-darwin"; };
  runtime = app.inputs.haskell-nix.lib.mkRuntimePackageSet (builtins.fromJSON (builtins.readFile /tmp/ep18-rei-sdk-cost-source/nix/runtime-selection.json));
  scope = runtime.mkApplicationScope pkgs (app.lib.haskellExtension pkgs.haskell.lib.compose pkgs);
  executable = pkgs.haskell.lib.compose.overrideCabal (_: { enableSharedLibraries = false; enableStaticLibraries = false; }) scope.rei-cli;
  fresh = package: (scope.ghcWithPackages (_: [ package ])).overrideAttrs (old: { name = old.name + "-ep18-qualified-cost-v1"; });
in { baseline = fresh scope.rei-cli; candidate = fresh executable; }

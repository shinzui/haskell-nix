import sys,importlib.util,json,os,time,subprocess,tempfile
from pathlib import Path
from types import SimpleNamespace
sys.path.insert(0,'/Users/shinzui/Keikaku/bokuno/haskell-nix/scripts')
spec=importlib.util.spec_from_file_location('measurement','/Users/shinzui/Keikaku/bokuno/haskell-nix/scripts/measure-application-nix-builds.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
r=Path(__file__).parent;out=r/'core-change';out.mkdir();os.environ['MP4_APPLICATION_BUILD_EXPERIMENT']='executable'
roots={'baseline':Path('/tmp/ep18-rei-delivery-baseline'),'candidate':Path('/tmp/ep18-rei-executable-candidate')};edit=Path('rei-core/src/Rei/Infrastructure/CategoryStream.hs');original={k:(p/edit).read_bytes() for k,p in roots.items()};assert original['baseline']==original['candidate']
needle=b'CategoryStream: Name must be at least 1 character long';assert original['baseline'].count(needle)==1
args=SimpleNamespace(expression=Path('/Users/shinzui/Keikaku/bokuno/haskell-nix/checks/fixtures/application-builds/producer.nix'),normal_default=True,output_dir=out,cores=16,require_idle_compilers=False,idle_wait_seconds=60,resource_policy='mac-studio',replace=None,edit=edit)
records=[]
try:
 for label,p in roots.items():(p/edit).write_bytes(original[label].replace(needle,b'MP4 core behavior delivery: Name must be at least 1 character long'))
 command=['nix','build',str(roots['baseline'])+'#rei-core','--json','--no-link','--print-build-logs','--no-write-lock-file','--max-jobs','1','--cores','16'];t=time.perf_counter()
 with (out/'common-core.log').open('w') as log:
  built=subprocess.run(command,stdout=subprocess.PIPE,stderr=log,text=True)
 assert built.returncode==0;common={'command':command,'elapsed_seconds':time.perf_counter()-t,'build_result':json.loads(built.stdout)}
 for label,p in roots.items():records.append(m.run_trial(args,label,p,0,'core-change'))
 assert len({x['identity']['core'] for x in records})==1
 probe=json.loads(subprocess.check_output(['nix','build','--impure','--file',str(r/'core-context.nix'),'--argstr','source',str(roots['candidate']),'compiler','--json','--no-link','--max-jobs','1']))[0]['outputs']['out']
 with tempfile.TemporaryDirectory(prefix='ep18-core-probe-') as home:
  env={k:v for k,v in os.environ.items() if not any(x in k for x in ['DATABASE','PG_CONNECTION','REI_CONFIG','MORI_CONFIG'])};env.update(HOME=home,XDG_CONFIG_HOME=home)
  q=subprocess.run([probe+'/bin/ghci','-ignore-dot-ghci','-v0'],input=b':module +Rei.Infrastructure.CategoryStream\nprint (parseEither mempty)\n:quit\n',env=env,capture_output=True,timeout=60);(out/'core-behavior.log').write_bytes(q.stdout+q.stderr);assert q.returncode==0 and b'MP4 core behavior delivery' in q.stdout and not q.stderr
 result={'qualification':'One common core build plus ordinary downstream defaults. Add the same common cost to both sides; this phased attribution has an additional invocation/evaluation and is not a five-pair core speedup statistic.','common':common,'trials':records,'common_core_identity':records[0]['identity']['core'],'changed_core_behavior':True,'approximate_total_seconds':{x['label']:common['elapsed_seconds']+x['elapsed_seconds'] for x in records}}
 (out/'summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'common_seconds':common['elapsed_seconds'],'default_seconds':{x['label']:x['elapsed_seconds'] for x in records},'approximate_total_seconds':result['approximate_total_seconds'],'changed_core_behavior':True}))
finally:
 for label,p in roots.items():(p/edit).write_bytes(original[label])

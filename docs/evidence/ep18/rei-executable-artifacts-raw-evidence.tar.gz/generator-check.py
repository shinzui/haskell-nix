import subprocess,json,os,hashlib,time
from pathlib import Path
r=Path(__file__).parent;root=Path('/tmp/ep18-rei-delivery-candidate')
tool=json.loads((r/'production-generator-tool.stdout').read_text())[0]['outputs']['out']+'/bin/keiro-dsl'
files=[p for folder in ('rei-cli','rei-cli-foundation') for p in (root/folder).rglob('*') if p.is_file()]
before={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
start=time.monotonic()
with (r/'generator.log').open('w') as log:
 result=subprocess.run(['just','keiro-scaffold'],cwd=root,env=os.environ|{'KEIRO_DSL_TOOL':tool},stdout=log,stderr=subprocess.STDOUT)
after={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
record={'command':['just','keiro-scaffold'],'exit_code':result.returncode,'elapsed_seconds':time.monotonic()-start,'cli_files':len(files),'cli_bytes_preserved':before==after,'tool':tool}
(r/'generator.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record));assert result.returncode==0 and before==after

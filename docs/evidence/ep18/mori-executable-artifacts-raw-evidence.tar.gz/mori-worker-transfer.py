import json,subprocess,time,hashlib
from pathlib import Path
r=Path(__file__).parent;out=r/'mori-worker-transfer';out.mkdir(exist_ok=True);store='local?root='+str((out/'worker').resolve())
summary=json.loads((r/'mori-executable-final-pairs/summary.json').read_text());trials=summary['trials'];roots={label:next(x for x in trials if x['label']==label)['build_result'][0]['outputs']['out'] for label in ['baseline','candidate']}
def run(label,command,success=True):
 t=time.perf_counter();q=subprocess.run(command,capture_output=True);(out/(label+'.log')).write_bytes(q.stderr);(out/(label+'.stdout')).write_bytes(q.stdout);d={'command':command,'elapsed_seconds':time.perf_counter()-t,'exit_code':q.returncode};assert (q.returncode==0)==success,q.stderr[-2000:];return q,d
closures={k:json.loads(subprocess.check_output(['nix','path-info','--recursive','--json',v])) for k,v in roots.items()}
common=sorted(set(closures['baseline'])&set(closures['candidate']));records={}
_,records['preseed_common']=run('preseed-common',['nix','copy','--no-check-sigs','--to',store,*common])
for label in ['baseline','candidate']:
 path=roots[label]
 _,records[label+'_missing']=run(label+'-missing',['nix','build','--store',store,'--option','substituters','','--option','builders','',path,'--no-link'],False)
 _,records[label+'_copy']=run(label+'-copy',['nix','copy','--no-check-sigs','--to',store,path])
 _,records[label+'_reuse']=run(label+'-reuse',['nix','build','--store',store,'--option','substituters','','--option','builders','',path,'--no-link'])
 q,records[label+'_identity']=run(label+'-identity',['nix','path-info','--store',store,'--json',path]);remote=json.loads(q.stdout)[path];assert remote['narHash']==closures[label][path]['narHash']
 d=records[label+'_copy'];d['marginal_paths']=sorted(set(closures[label])-set(common));d['marginal_nar_bytes']=sum(closures[label][x]['narSize'] for x in d['marginal_paths']);d['full_closure_nar_bytes']=sum(x['narSize'] for x in closures[label].values())
receipt={'status':'passed','qualification':'Independent local store seeded with the exact shared runtime closure. Missing outputs fail with builders and substituters disabled; copied original outputs then realise with matching NAR hashes and no compilation. Local transfer is not an internet-cache performance or cross-platform claim.','project_uri':'mori://shinzui/mori','roots':roots,'common_paths':len(common),'records':records,'additional_transfer_seconds':max(0,records['candidate_copy']['elapsed_seconds']-records['baseline_copy']['elapsed_seconds'])}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))

import json,subprocess,os,time,tempfile,hashlib
from pathlib import Path
r=Path(__file__).parent;root=Path('/tmp/ep18-mori-profile-guards');out=r/'mori-profile-guards';out.mkdir();readme=root/'README.md';original_readme=readme.read_bytes();readme.write_bytes(original_readme+b'\nEP-18 isolated guard baseline.\n')
env=os.environ|{'MP4_APPLICATION_BUILD_EXPERIMENT':'executable'};expression=str(r/'producer-mori.nix');records=[]
def identity():return json.loads(subprocess.check_output(['nix','eval','--json','--impure','--file',expression,'--argstr','source',str(root),'identity'],env=env))
def build(label,error=None):
 command=['nix','build',str(root)+'#default','--json','--no-link','--print-build-logs','--no-write-lock-file','--max-jobs','1','--cores','16'];t=time.perf_counter();q=subprocess.run(command,capture_output=True,env=env);elapsed=time.perf_counter()-t;(out/(label+'.log')).write_bytes(q.stderr);record={'probe':label,'command':command,'elapsed_seconds':elapsed,'exit_code':q.returncode,'log_sha256':hashlib.sha256(q.stderr).hexdigest()}
 if error=='type':assert q.returncode and b'mp4GuardTypeError' in q.stderr and (b'No instance for' in q.stderr or b"Couldn't match" in q.stderr),q.stderr[-2000:]
 elif error=='module':assert q.returncode and b'Mori.Command.Help' in q.stderr and (b"can't find source" in q.stderr.lower() or b'could not find module' in q.stderr.lower()),q.stderr[-2000:]
 else:assert q.returncode==0,q.stderr[-2000:];record['build_result']=json.loads(q.stdout)
 records.append(record);return record
try:
 base=identity()
 for label,relative,addition in [('root-prose','README.md',b'\nUnrelated prose guard.\n'),('core-planning-prose','mori-core/README.md',b'\nUnrelated planning prose guard.\n'),('api-sibling','mori-api/src/Mori/Api/Server.hs',b'\n-- Unrelated API source guard.\n')]:
  path=root/relative
  if not path.exists():
   if label=='core-planning-prose':
    candidates=sorted((root/'rei-core/docs').rglob('*.md'));assert candidates;path=candidates[0]
   else:raise AssertionError(relative)
  content=path.read_bytes()
  try:
   path.write_bytes(content+addition);value=identity();assert (value['root']!=base['root'] if label=='api-sibling' else value['root']==base['root']) and value['core']==base['core'];records.append({'probe':label,'root_preserved':label!='api-sibling','core_preserved':True,'identity':value})
  finally:path.write_bytes(content)
 path=root/'mori-cli/src/Mori/Command/Help.hs';content=path.read_bytes()
 try:
  path.write_bytes(content+b'\nmp4GuardTypeError :: Int\nmp4GuardTypeError = "invalid type"\n');build('native-type-error','type')
 finally:path.write_bytes(content)
 try:
  path.unlink();build('native-removed-module','module')
 finally:path.write_bytes(content)
 path=root/'mori-cli/help/sealed-evaluation.md';content=path.read_bytes()
 try:
  path.write_bytes(content+b'\n# EP18 embedded resource delivery.\n');value=identity();assert value['root']!=base['root'] and value['core']==base['core'];record=build('native-embedded-resource')
  binary=record['build_result'][0]['outputs']['out']+'/bin/mori'
  with tempfile.TemporaryDirectory(prefix='ep18-resource-home-') as home:
   clean={k:v for k,v in env.items() if not any(x in k for x in ['DATABASE','PG_CONNECTION','REI_CONFIG','MORI_CONFIG'])};clean.update(HOME=home,XDG_CONFIG_HOME=home)
   q=subprocess.run([binary,'help','sealed-evaluation'],env=clean,capture_output=True,timeout=30);assert q.returncode==0 and b'EP18 embedded resource delivery.' in q.stdout;record['exact_changed_resource_observed']=True
 finally:path.write_bytes(content)
 assert identity()==base
 (out/'receipt.json').write_text(json.dumps({'project_uri':'mori://shinzui/mori','source_revision':'6fd93ae7ed870d192f345d8b9a86202b7a0ad6ea','scope':'Isolated working-source probes at a fixed dirty stamp; no checkpoint or layout change.','baseline':base,'probes':records,'status':'passed'},indent=2)+'\n');print(json.dumps({'status':'passed','probes':len(records),'native_seconds':sum(x.get('elapsed_seconds',0) for x in records)}))
finally:readme.write_bytes(original_readme)

import importlib.util,json,os,re,subprocess,sys,time,hashlib
from pathlib import Path
root=Path('/tmp/ep18-mori-consume-only-full-cost-v1')
project=Path('/Users/shinzui/Keikaku/bokuno/haskell-nix')
os.environ['MP4_APPLICATION_CHECKOUT']='/tmp/ep20-mori-shell-baseline'
spec=importlib.util.spec_from_file_location('measurement',project/'scripts/measure-application-nix-builds.py');measurement=importlib.util.module_from_spec(spec);spec.loader.exec_module(measurement)
declaration=json.loads((root/'declaration.json').read_text())
for name,digest in declaration['codeSha256'].items():
 assert hashlib.sha256((project/name).read_bytes()).hexdigest()==digest,name

def phase(label,command):
 receipt=root/(label+'.receipt.json');assert not receipt.exists(),label
 memory=measurement.CompilerMemory();memory.thread.start();memory.ready.wait()
 if memory.preexisting or memory.errors:
  memory.finish();raise ValueError('Compiler host is not idle: '+str(memory.preexisting))
 start=time.perf_counter()
 with (root/(label+'.stdout')).open('w') as output,(root/(label+'.log')).open('w') as log:
  process=subprocess.Popen(command,stdout=output,stderr=subprocess.PIPE,text=True)
  counts={};events=[]
  try:
   for line in process.stderr:
    log.write(line);log.flush()
    if 'Running phase:' in line:events.append({'elapsed_seconds':time.perf_counter()-start,'message':line.strip()})
    match=re.search(r'^(\S+)> \[\s*\d+ of\s*\d+\] Compiling ',line)
    if match:counts[match[1]]=counts.get(match[1],0)+1
   code=process.wait()
  finally:
   process.stderr.close();sample=memory.finish()
 elapsed=time.perf_counter()-start
 record={'command':command,'elapsed_seconds':elapsed,'exitCode':code,'compiledModules':counts,'phaseEvents':events,'sampledHostCompilerMemory':sample,'stdout':label+'.stdout','log':label+'.log'}
 receipt.write_text(json.dumps(record,indent=2)+'\n')
 print(label,round(elapsed,3),'seconds',code,counts,flush=True)
 assert code==0,(label,code)
 return (root/(label+'.stdout')).read_text(),record

common=['--impure','--file',str(project/'checks/fixtures/application-builds/owned-pair.nix'),'--argstr','source',str(root/'current')]
if sys.argv[1] in ('seed','seed-build'):
 if sys.argv[1]=='seed':
  data,_=phase('checkpoint-declaration',['nix','eval','--json',*common,'checkpointDeclaration'])
  checkpoint=json.loads(data)
  (root/'requested-origin.json').write_text(json.dumps(checkpoint,indent=2)+'\n')
  drv=checkpoint['derivation']
  data,_=phase('checkpoint-metadata',['nix','derivation','show',drv])
 else:
  checkpoint=json.loads((root/'requested-origin.json').read_text());drv=checkpoint['derivation']
  data=(root/'checkpoint-metadata.stdout').read_text()
 metadata=json.loads(data)
 recipe=metadata['derivations'][Path(drv).name] if 'derivations' in metadata else metadata[drv]
 paths=[v['path'] if v['path'].startswith('/') else '/nix/store/'+v['path'] for v in recipe['outputs'].values()]
 for path in paths:
  found=subprocess.run(['nix-store','--check-validity',path],capture_output=True,text=True)
  assert found.returncode!=0 and 'is not valid' in found.stderr,(path,found.stderr)
 _,record=phase('fresh-checkpoint',['nix','build',drv+'^out,intermediates','--json','--print-build-logs','--max-jobs','1','--cores','16','--out-link',str(root/'retained-checkpoint')])
 assert record['compiledModules'].get('mori-core',0)>=582,record['compiledModules']
 subprocess.run(['nix-store','--check-validity',*paths],check=True,capture_output=True)
 (root/'origin.json').write_text(json.dumps(checkpoint,indent=2)+'\n')
 print('Fresh successful origin bound:',drv,flush=True)
elif sys.argv[1]=='first-use':
 metadata_path=root/'current'/'.mp4-pilot.json';metadata=json.loads(metadata_path.read_text());metadata.update(policy='incremental',validatedCheckpointFile=str(root/'origin.json'));metadata_path.write_text(json.dumps(metadata,indent=2)+'\n')
 data,candidate=phase('first-use-candidate',['nix','build','--no-link','--json','--print-build-logs','--max-jobs','1','--cores','16',*common,'package'])
 assert 0<candidate['compiledModules'].get('mori-core',0)<20,candidate['compiledModules']
 candidate_build=json.loads(data)[0]
 metadata['policy']='clean';metadata_path.write_text(json.dumps(metadata,indent=2)+'\n')
 data,baseline=phase('first-use-clean',['nix','build','--no-link','--json','--print-build-logs','--max-jobs','1','--cores','16',*common,'package'])
 assert baseline['compiledModules'].get('mori-core',0)>=582,baseline['compiledModules']
 clean_build=json.loads(data)[0]
 metadata['policy']='incremental';metadata_path.write_text(json.dumps(metadata,indent=2)+'\n')
 data,_=phase('changed-value-probe',['nix','build','--no-link','--json','--print-build-logs','--max-jobs','1','--cores','16',*common,'probe'])
 probe=json.loads(data)[0]['outputs']['out']+'/bin/core-probe'
 result=subprocess.run([probe],capture_output=True,text=True,check=True)
 assert 'MP4 full-cost v1:consume-only-20261017:' in result.stdout,result.stdout
 commands=[['--version'],['help','sealed-evaluation']];observed=[]
 for arguments in commands:
  pair=[]
  for build in (candidate_build,clean_build):
   result=subprocess.run([build['outputs']['out']+'/bin/mori',*arguments],capture_output=True,check=True)
   pair.append((result.stdout,result.stderr))
  assert pair[0]==pair[1],arguments
  observed.append({'arguments':arguments,'stdoutSha256':hashlib.sha256(pair[0][0]).hexdigest(),'stderrSha256':hashlib.sha256(pair[0][1]).hexdigest()})
 (root/'behavior.json').write_text(json.dumps({'status':'passed','cliBehavior':observed,'changedValue':subprocess.check_output([probe],text=True)},indent=2)+'\n')
elif sys.argv[1]=='guards':
 phase('native-guards',[sys.executable,str(project/'scripts/check-application-source-guards.py'),'--application','mori','--component','core','--checkout','/tmp/ep20-mori-shell-baseline','--source',str(root/'current'),'--seed-source',str(root/'seed'),'--seed-revision','364f9a2','--validated-checkpoint-file',str(root/'origin.json'),'--no-retain-current-intermediates','--application-revision',declaration['sourceBase'],'--alternate-stamp','cost-v1','--output-dir',str(root/'native-guards'),'--expression',str(project/'checks/fixtures/application-builds/owned.nix'),'--native'])

elif sys.argv[1]=='transfer':
 checkpoint=json.loads((root/'origin.json').read_text())
 metadata=json.loads((root/'checkpoint-metadata.stdout').read_text())
 recipe=metadata['derivations'][Path(checkpoint['derivation']).name] if 'derivations' in metadata else metadata[checkpoint['derivation']]
 paths=[v['path'] if v['path'].startswith('/') else '/nix/store/'+v['path'] for v in recipe['outputs'].values()]
 data,_=phase('checkpoint-closure-metadata',['nix','path-info','--recursive','--json',*paths])
 closure=json.loads(data)
 validity=[]
 for path in paths:
  command=['nix-store','--store','local?root=/private/tmp/ep18-fresh-checkpoint-transfer-v1','--check-validity',path]
  result=subprocess.run(command,capture_output=True,text=True)
  assert result.returncode!=0 and 'is not valid' in result.stderr,(path,result.stderr)
  validity.append({'command':command,'exitCode':result.returncode,'stderr':result.stderr})
 (root/'transfer-initial-validity.json').write_text(json.dumps(validity,indent=2)+'\n')
 _,record=phase('checkpoint-local-transfer',['nix','copy','--to','local?root=/private/tmp/ep18-fresh-checkpoint-transfer-v1','--no-check-sigs',*paths])
 subprocess.run(['nix-store','--store','local?root=/private/tmp/ep18-fresh-checkpoint-transfer-v1','--check-validity',*paths],check=True,capture_output=True)
 data,_=phase('current-runtime-closure-metadata',['nix','path-info','--recursive','--json',json.loads((root/'first-use-candidate.stdout').read_text())[0]['outputs']['out']])
 runtime=json.loads(data)
 assert all(path not in runtime for path in paths)
 candidate=json.loads((root/'first-use-candidate.stdout').read_text())[0]
 data,_=phase('current-derivation-metadata',['nix','derivation','show',candidate['drvPath']])
 graph=json.loads(data)
 # Inspect the exact current core recipe through its owned identity.
 data,_=phase('current-identity',['nix','eval','--json',*common,'identity']);identity=json.loads(data)
 data,_=phase('current-core-metadata',['nix','derivation','show',identity['core']]);core_graph=json.loads(data)
 core_recipe=core_graph['derivations'][Path(identity['core']).name] if 'derivations' in core_graph else core_graph[identity['core']]
 assert list(core_recipe['outputs'])==['out'],core_recipe['outputs']
 summary={'scope':'Independent local-store transfer; unsigned locally built checkpoint copied with explicit --no-check-sigs, not a remote cache publication/download','checkpointPaths':paths,'transferredClosurePaths':len(closure),'transferredLogicalNarBytes':sum(item['narSize'] for item in closure.values()),'marginalRetainedNarBytes':sum(item['narSize'] for path,item in closure.items() if path not in runtime),'runtimePaths':len(runtime),'checkpointAbsentFromRuntime':True,'currentCoreOutputs':list(core_recipe['outputs']),'transferElapsedSeconds':record['elapsed_seconds']}
 (root/'retention-transfer.json').write_text(json.dumps(summary,indent=2)+'\n')
 print(summary,flush=True)

elif sys.argv[1]=='origin-replay':
 phase('checkpoint-origin-replay',['nix','build','--no-link','--json','--print-build-logs','--max-jobs','1','--cores','16',str(project)+'#checks.aarch64-darwin.application-checkpoint'])

# Note Q&A

The user has selected a single note from their personal Rei
workspace and would like an answer to a question about it. The full
body of the note is provided below verbatim.

## Note Body

{{note_body}}

## User Question

{{user_question}}

## Task

Answer the user's question concisely, grounding your response in the
note body above. If the note does not contain enough information to
answer the question, say so explicitly rather than inventing facts.
Quote short fragments of the note when they are directly relevant.

Output plain prose. Do not echo the note. Do not wrap the answer in
code fences. Do not add a preamble like "Here is the answer:". Begin
your answer now.

# Note Revision Task

## Original Note

{{existing_content}}

## Category Guidance

{{category_guidance}}

## Revision Instructions

{{user_instructions}}

## Task

Produce a revised version of the note that incorporates the
revision instructions while preserving any structure and
conventions implied by the category guidance above.

### Requirements

1. Output the FULL revised note body (do not output only a diff).
2. Preserve the level-1 heading at the top unless the
   instructions explicitly ask to retitle.
3. Output ONLY the raw markdown content - no explanations, no
   code fences, no preamble.

Begin the revised note now:

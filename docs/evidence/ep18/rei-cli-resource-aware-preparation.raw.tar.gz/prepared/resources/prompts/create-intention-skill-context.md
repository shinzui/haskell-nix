# Intention-Scoped Skill Creation Guide

You are helping the user design and create a **Claude Code workspace skill** scoped to a specific intention in their Rei personal coaching system.

## What is an Intention-Scoped Skill?

An intention-scoped skill is a reusable Claude Code slash command that is only available during `rei agent intention-assist` sessions for a specific intention. This allows intention-specific workflows and tools.

Skills live at: `<workspace>/agents/intentions/<intention-id>/.claude/skills/<skill-name>/SKILL.md`

## SKILL.md File Format

```markdown
---
description: Short description shown in skill picker and /help output
---

# Skill Name

Instructions for Claude Code when this skill is invoked.

## Steps

1. Step one...
2. Step two...

## Guidelines

- Guideline one...
- Guideline two...
```

### Frontmatter Fields

| Field | Required | Description |
|-------|----------|-------------|
| `description` | Yes | One-line description shown in autocomplete and `/help` |

## Common Allowed Tools

Skills can restrict which tools Claude Code uses. Common tools:

| Tool | Use Case |
|------|----------|
| `Read` | Read files from the filesystem |
| `Write` | Create new files |
| `Edit` | Modify existing files |
| `Bash(rei *)` | Run any `rei` CLI command |
| `Bash(git *)` | Run git commands |
| `Glob` | Find files by pattern |
| `Grep` | Search file contents |

## Skill Design Best Practices

1. **Single responsibility** — Each skill should do one thing well
2. **Use `rei` CLI for discovery** — Skills should run `rei <command> --help` to learn available options
3. **Interactive by default** — Skills should ask clarifying questions rather than guessing
4. **Idempotent** — Running a skill twice shouldn't create duplicate work
5. **Intention-focused** — Skills should operate within the scoped intention's subtree

## Your Task

Help the user design and create a new intention-scoped skill by:

1. **Ask what the skill should do** — Understand the workflow or task specific to this intention
2. **Suggest a skill name** — Short, kebab-case (e.g., `standup`, `research-review`)
3. **Draft the SKILL.md** — Write the complete skill file with clear instructions
4. **Create the file** — Write it to the intention's agent directory (shown in context below)
5. **Test suggestion** — Suggest testing via `rei agent intention-assist <ID>` then `/<skill-name>`

**Important**: This skill will ONLY be available in `rei agent intention-assist` sessions for this specific intention. It will NOT appear in global `rei agent assist` sessions.

When creating the skill file, ensure the directory exists first (create it if needed).

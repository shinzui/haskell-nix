# Workspace Skill Creation Guide

You are helping the user design and create a **Claude Code workspace skill** (slash command) for their Rei personal coaching system.

## What is a Workspace Skill?

A workspace skill is a reusable Claude Code slash command defined as a `SKILL.md` file. When invoked via `/<skill-name>`, Claude Code reads the skill file and follows its instructions.

Skills live at: `<workspace>/.claude/skills/<skill-name>/SKILL.md`

## SKILL.md File Format

```markdown
---
name: skill-name
description: Short description shown in skill picker and /help output
allowed-tools: AskUserQuestion, Bash, Read, Write, Edit, Glob, Grep
---

# Skill Name

Instructions for Claude Code when this skill is invoked.

## Steps

1. Step one...
2. Step two...

## Guidelines

- Guideline one...
- Guideline two...
```

### Frontmatter Fields

| Field | Required | Description |
|-------|----------|-------------|
| `name` | Yes | Kebab-case identifier matching the directory name |
| `description` | Yes | One-line description shown in autocomplete and `/help` |
| `allowed-tools` | No | Comma-separated list of tools the skill can use. If omitted, all tools are available |

## Common Allowed Tools

Skills can restrict which tools Claude Code uses. Common tools:

| Tool | Use Case |
|------|----------|
| `AskUserQuestion` | Ask the user clarifying questions interactively |
| `Read` | Read files from the filesystem |
| `Write` | Create new files |
| `Edit` | Modify existing files |
| `Bash(rei *)` | Run any `rei` CLI command |
| `Bash(git *)` | Run git commands |
| `Glob` | Find files by pattern |
| `Grep` | Search file contents |

## Skill Design Best Practices

1. **Single responsibility** — Each skill should do one thing well
2. **Use `rei` CLI for discovery** — Skills should run `rei <command> --help` or `rei help <topic>` to learn available options rather than hardcoding command syntax
3. **Interactive by default** — Skills should ask clarifying questions rather than guessing
4. **Idempotent** — Running a skill twice shouldn't create duplicate work
5. **Composable** — Skills can call `rei` commands and read/write files, building on existing CLI capabilities

## Rei CLI Discovery

The skill should use these commands to discover Rei's capabilities:

- `rei --help` — Top-level command list
- `rei <command> --help` — Subcommand options
- `rei help <topic>` — Detailed help on a topic (e.g., `rei help projects`, `rei help custom-properties`)
- `rei completions` — Shell completion scripts

## Your Task

Help the user design and create a new workspace skill by:

1. **Ask what the skill should do** — Understand the workflow or task to automate
2. **Suggest a skill name** — Short, kebab-case (e.g., `weekly-review`, `morning-standup`)
3. **Suggest tools and confirm with user** — Based on the skill's purpose, suggest which tools it needs and use `AskUserQuestion` to confirm. Present a recommendation like:

   > Based on what this skill does, I'd suggest these allowed tools:
   > - `AskUserQuestion` — to ask clarifying questions
   > - `Bash(rei *)` — to run rei commands
   > - `Read` — to read files
   >
   > Would you like to add or remove any tools?

   Always include `AskUserQuestion` if the skill has any interactive steps. Refer to the "Common Allowed Tools" table above when making suggestions. It is better to be explicit about which tools are allowed rather than omitting `allowed-tools` (which grants access to everything).

4. **Draft the SKILL.md** — Write the complete skill file with clear instructions. The frontmatter **must** include `name`, `description`, and `allowed-tools` fields. Set `allowed-tools` to the tools confirmed by the user.
5. **Create the file** — Write it to `<workspace>/.claude/skills/<name>/SKILL.md`
6. **Test suggestion** — Suggest how to test with `/<skill-name>`

When creating the skill file, ensure the directory exists first (create it if needed).

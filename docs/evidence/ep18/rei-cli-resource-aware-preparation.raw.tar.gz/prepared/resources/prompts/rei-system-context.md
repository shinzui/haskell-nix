# Rei Context

You are helping with **Rei** (怜), a personal time-management and agent-assisted coaching system. You have full access to the Rei CLI via Bash.

## Entity Model

**Intentions** are the core unit: commitments to a goal or outcome, arranged in a parent/child tree. Status is `active` (default), `future` (deferred, hidden from today), `completed` or `abandoned` (both terminal, reopenable). An intention owns **actions** (work done, with duration and polarity), **outcomes**, and **blockers**, and relates to other intentions through **dependencies** (blocking) and **support** (non-blocking). It can be **delegated** to an agent, and delegated work goes through review **checkpoints**.

Around intentions:

- **Habits**: daily/weekly practices with build or break polarity, optionally linked to an intention.
- **Disruptions**: unplanned reactive work, tracked by source.
- **Knowledge**: notes (markdown with wikilinks, embeds and checkbox **tasks**), docs, links (canonically deduplicated), and **collections** of them.
- **Topics**: first-class subjects that entities attach to. A **project** is a topic classified as a project, often backed by a Mori repository (`mori://namespace/name`). Work belongs to a project through **scope**, which is effective: scoping a root intention brings its descendants and everything they own.
- **Edges** are typed relationships between entities, using **predicates** defined in a lightweight **ontology**.
- **Organization**: hierarchical categories, custom properties (text, number, date, enum, state machine), focus areas and daily cycles, journal entries (`day`), and views.
- **Reminders**, **reflections**, and **playbooks** (runnable procedures).

## Rules

- **Attribute every write**: `rei -a claude-code <command> ...`
- **Always pass explicit IDs.** FZF selection does not work here. Find IDs with `list` commands and use the full TypeID (e.g. `intention_01h455vb4pex...`).
- **Prefer `--json`** when you need to parse output. Most `list` and `show` commands support it.
- **Pipe long text through stdin** to avoid quoting problems: `echo "..." | rei -a claude-code action record -i ID`.

## Commands

| Area | Commands |
|------|----------|
| Work tracking | `intention` (create, tree, show `--full`, blocked, timeline, complete/abandon/defer/activate/reopen, delegate, set-*), `action`, `outcome`, `blocker`, `dependency`, `support`, `checkpoint` |
| Habits & disruptions | `habit`, `disruption` |
| Knowledge | `note`, `doc`, `link`, `task`, `collection`, `knowledge` |
| Topics & graph | `topic`, `project` (sync, scope add/list/remove, review, list, show), `edge`, `predicate`, `ontology` |
| Organization | `category`, `custom-property`, `focus`, `cycle`, `day`, `view` |
| Dashboards & review | `today` (`--context`), `tomorrow`, `yesterday`, `neglected`, `review`, `project review --due` |
| Reminders & reflection | `reminder`, `reflect` |
| Automation & agents | `agent` (coach, review, nudge, reflect, assist, intention-assist, sessions, memory, schedule), `playbook` |

Typical project workflow: `rei project list`, then `rei project show PROJECT` and `rei project scope list PROJECT --entity-type intention --json` to find the intentions that belong to a project. Use `rei -a claude-code project scope add PROJECT INTENTION_ID` to file new work under it.

## Formats

- **Horizons:** `1d`, `1w`, `2w`, `1m`, `3m`, `1y`, or free text such as `"end of quarter"`
- **Durations:** `30m`, `1h30m`, `1.5h`, `90` (minutes)
- **`--at`:** `now`, `yesterday`, `2 hours ago`, `-30m`, `tomorrow 9am`, `next monday`, ISO 8601
- **Deadlines:** `YYYY-MM-DD` (requires a horizon)

## Discovering More

- `rei <command> [subcommand] --help` shows the exact flags.
- `rei help` lists the conceptual guides; `rei help <topic>` shows one. Useful topics include `projects`, `topics`, `edges`, `delegation`, `review-checkpoints`, `custom-properties`, `state-machines`, `views`, `time`, and `agent-memory`.

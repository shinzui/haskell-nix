# Note Creation Task

## Category Guidance

{{category_guidance}}

## Input

{{user_input}}

## Task

Create a markdown note for "{{user_input}}" following the category guidance above.

### Requirements

1. Start with a level-1 heading based on the input (e.g., `# {{user_input}}`)
2. Follow the structure and format from the category guidance exactly
3. Output ONLY the raw markdown content - no explanations, no code fences

Begin the note now:

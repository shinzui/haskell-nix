#compdef rei
# Zsh completion for rei
# Add to ~/.zfunc/_rei and ensure fpath includes ~/.zfunc
#
# Candidates come from optparse-applicative's runtime completion protocol, so
# they always match the real parser. Launching rei costs ~40ms though, which is
# too slow to pay on every TAB, so results are cached in two layers:
#
#   1. an associative array that lives as long as the shell session
#   2. a file under ${XDG_CACHE_HOME:-~/.cache}/rei/completions
#
# Both layers are stamped with the resolved rei binary and its mtime. Nix
# rebuilds change the path and cabal rebuilds change the mtime, so upgrading rei
# invalidates the caches automatically. Set REI_COMPLETION_CACHE=0 to bypass
# them entirely.

zmodload -F zsh/stat b:zstat 2>/dev/null
zmodload -F zsh/files b:mkdir b:mv b:rm 2>/dev/null

typeset -gA _rei_completion_cache

# Identity of the rei binary, used to invalidate both caches. Sets _rei_stamp.
# ${commands} and zstat are builtins, so this costs no subprocesses.
_rei_binary_stamp() {
    typeset -g _rei_stamp=

    local bin=${commands[rei]}
    if [[ -z $bin ]]; then
        rehash
        bin=${commands[rei]}
    fi
    [[ -n $bin ]] || return 1

    bin=${bin:A}
    local -a st
    zstat -A st +mtime $bin 2>/dev/null
    _rei_stamp="${bin}:${st[1]:-0}"
}

# Ask rei for every candidate valid at the current position; sets _rei_raw. The
# current word is sent empty on purpose: optparse then returns the full
# candidate set rather than a prefix-filtered one, zsh does the filtering
# itself, and the cache key stays independent of what has been typed so far.
_rei_query() {
    typeset -ga _rei_raw

    local -a cmdline
    cmdline=(
        --bash-completion-enriched
        --bash-completion-index $((CURRENT - 1))
        --bash-completion-word ${words[1]}
    )

    local word
    for word in "${(@)words[2,CURRENT-1]}"; do
        cmdline+=(--bash-completion-word $word)
    done
    cmdline+=(--bash-completion-word '')

    # Quote the expansion: zsh drops empty elements from unquoted arrays, and
    # the trailing empty word is what asks for the unfiltered candidate set.
    _rei_raw=(${(f)"$(rei "${cmdline[@]}" 2>/dev/null)"})
}

# Only cache positions whose preceding words all look like subcommands or flags.
# Free-form arguments (titles, entity IDs) would otherwise spawn an unbounded
# number of cache entries that are never read twice.
_rei_cacheable() {
    (( CURRENT - 2 <= 6 )) || return 1

    local word
    for word in ${words[2,CURRENT-1]}; do
        (( ${#word} <= 24 )) || return 1
        [[ -z ${word//[A-Za-z0-9._-]/} ]] || return 1
    done
}

_rei() {
    (( CURRENT > 1 )) || return 1

    typeset -ga _rei_raw
    _rei_raw=()

    if [[ $REI_COMPLETION_CACHE == 0 ]] || ! _rei_cacheable || ! _rei_binary_stamp; then
        _rei_query
    else
        local key=${(j.:.)words[2,CURRENT-1]}
        key=${key//[^A-Za-z0-9._-]/_}
        : ${key:=_root}

        local entry=$_rei_stamp/$key
        if [[ -n ${_rei_completion_cache[$entry]} ]]; then
            _rei_raw=(${(f)_rei_completion_cache[$entry]})
        else
            local cache_dir=${XDG_CACHE_HOME:-$HOME/.cache}/rei/completions
            local cache_file=$cache_dir/$key

            if [[ -r $cache_file ]]; then
                local -a cached
                cached=(${(f)"$(<$cache_file)"})
                [[ ${cached[1]} == $_rei_stamp ]] && _rei_raw=(${cached[2,-1]})
            fi

            if (( ! ${#_rei_raw} )); then
                _rei_query
                if (( ${#_rei_raw} )); then
                    # Write through a temp file so a completion interrupted
                    # midway cannot leave a truncated cache behind.
                    [[ -d $cache_dir ]] || mkdir -p $cache_dir 2>/dev/null
                    if print -rl -- $_rei_stamp $_rei_raw > $cache_file.$$ 2>/dev/null; then
                        mv -f $cache_file.$$ $cache_file 2>/dev/null ||
                            rm -f $cache_file.$$ 2>/dev/null
                    fi
                fi
            fi

            (( ${#_rei_raw} )) && _rei_completion_cache[$entry]=${(F)_rei_raw}
        fi
    fi

    local -a completions
    local line word desc
    for line in $_rei_raw; do
        word=${line%%$'\t'*}
        desc=${line#*$'\t'}
        if [[ "$word" != "$desc" ]]; then
            completions+=("${word//:/\\:}:${desc}")
        else
            completions+=("$word")
        fi
    done

    if (( ${#completions} )); then
        _describe 'rei' completions
    fi
}

_rei

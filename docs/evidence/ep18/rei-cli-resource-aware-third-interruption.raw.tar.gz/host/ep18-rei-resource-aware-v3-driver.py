from pathlib import Path
import os,subprocess,json,hashlib,time,threading,signal,re
repo=Path('/Users/shinzui/Keikaku/bokuno/rei-project/rei');overlay=repo/'nix/haskell-overlay.nix';original=overlay.read_bytes();assert original==subprocess.check_output(['git','show','bad0388f722af9e29187c2adfef5ed97fd0ca92f:nix/haskell-overlay.nix'],cwd=repo)
base=Path('/tmp/ep18-rei-resource-aware-paired-v3');start=time.perf_counter();quiet=None;preflight=[]
def processes(compilers=False):
 r=subprocess.run(['ps','-axo','pid=,comm='],capture_output=True,text=True,check=True);result=[]
 for line in r.stdout.splitlines():
  bits=line.split(None,1)
  if len(bits)!=2:continue
  name=Path(bits[1]).name
  if name.endswith('-test') or name in ['cabal','.cabal-wrapped'] or (compilers and re.fullmatch(r'ghc(?:-[\d.]+)?|clang(?:-[\d.]+)?|ld(?:64)?|(?:ghc-)?iserv.*|Setup',name)):
   result.append({'pid':int(bits[0]),'name':name})
 return result
while True:
 busy=processes(True);now=time.perf_counter()
 if busy:
  quiet=None;preflight.append({'elapsed_seconds':now-start,'processes':busy})
 elif quiet is None:quiet=now
 if quiet is not None and now-quiet>=60:break
 if now-start>600:
  Path(str(base)+'-preflight.json').write_text(json.dumps({'status':'no continuous idle minute within ten minutes; timings not started','observations':preflight},indent=2)+'\n');raise SystemExit(3)
 time.sleep(.5)
command=['python3','scripts/measure-application-nix-builds.py','--expression','checks/fixtures/application-builds/split.nix','--baseline-source','/tmp/ep18-rei-resource-aware-split-v2/baseline','--candidate-source','/tmp/ep18-rei-resource-aware-split-v2/candidate','--edit','rei-cli/src/Rei/Cli/Commands/Help.hs','--replace','timeTopicContent = $(embedStringFile','timeTopicContent = "MP4 paired leaf {trial} resource-aware-v3\\n" <> $(embedStringFile','--project-uri','mori://shinzui/rei','--source-revision','bad0388f722af9e29187c2adfef5ed97fd0ca92f','--output-dir',str(base),'--require-idle-compilers']
env=os.environ.copy();env['MP4_APPLICATION_CHECKOUT']=str(repo);measured_start=time.perf_counter();observations=[]
with open(str(base)+'-driver.log','w') as log:
 process=subprocess.Popen(command,env=env,stdout=log,stderr=subprocess.STDOUT)
 interrupted=False
 while process.poll() is None:
  busy=processes()
  if busy:
   observations.append({'elapsed_seconds':time.perf_counter()-measured_start,'processes':busy})
   if not interrupted:process.send_signal(signal.SIGINT);interrupted=True
  time.sleep(.5)
 code=process.wait()
Path(str(base)+'-driver-receipt.json').write_text(json.dumps({'command':command,'exit_code':code,'elapsed_seconds':time.perf_counter()-measured_start,'preflight_elapsed_seconds':measured_start-start,'preflight_foreign_observations':preflight,'overlay_sha256':hashlib.sha256(original).hexdigest(),'overlay_unchanged_after':overlay.read_bytes()==original,'foreign_test_process_observations':observations,'auto_interrupted_for_foreign_work':interrupted},indent=2)+'\n');print('exit_code',code)

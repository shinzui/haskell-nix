# Own recipes only; shared dependencies come from mori://shinzui/haskell-nix.
{ pkgs, gitRev, haskellLib, sourceRoot ? ../. }:
final: _prev:
let
  own = name:
    haskellLib.dontHaddock (haskellLib.disableLibraryProfiling
      (haskellLib.dontCheck (final.callCabal2nix name
        (builtins.path {
          path = sourceRoot + "/${name}";
          name = "${name}-source";
          # Keep package assets, including migrations, prompts and fixtures.
          filter = path: type:
            !(builtins.elem (builtins.baseNameOf path)
              [ ".git" "dist-newstyle" "result" "README.md" ])
            # Planning prose is not a Cabal or compile-time input. Restrict
            # this exclusion to the audited package directory: Markdown in
            # src/, help/ and prompts/ is embedded in the shipped application.
            && !(name == "rei-core" && type == "directory"
            && builtins.baseNameOf path == "docs"
            && builtins.baseNameOf (builtins.dirOf path) == "rei-core");
        })
        { })));
in
{
  rei-core = own "rei-core";
  rei-api-contract = own "rei-api-contract";
  rei-api-client = own "rei-api-client";
  rei-api = own "rei-api";
  rei-cli = haskellLib.overrideCabal
    (drv: {
      # Scope provenance to its consuming module. A package-wide CPP flag
      # invalidates every module's compiler-option fingerprint on each commit.
      postPatch = (drv.postPatch or "") + ''
        substituteInPlace src/Rei/Cli/Commands/Info.hs \
          --replace-fail '#ifdef GIT_HASH' '#if 1' \
          --replace-fail 'nixGitHash = Just GIT_HASH' ${pkgs.lib.escapeShellArg "nixGitHash = Just ${builtins.toJSON (builtins.substring 0 7 gitRev)}"}
      '';
    })
    (own "rei-cli");
}

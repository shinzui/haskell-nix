module Mori.Automation.ConfigHash
  ( configHashText,
    sha256HexOfLazy,
  )
where

import Crypto.Hash (Digest, SHA256, hashlazy)
import Data.Aeson (ToJSON, encode)
import Data.ByteString.Lazy qualified as BL
import Data.Text (Text)
import Data.Text qualified as Text

-- | Hash exact bytes with a self-describing, lowercase SHA-256 representation.
sha256HexOfLazy :: BL.ByteString -> Text
sha256HexOfLazy bytes =
  "sha256:" <> Text.pack (show (hashlazy bytes :: Digest SHA256))

-- | Content-stable fingerprint of Aeson's encoded JSON bytes.
configHashText :: (ToJSON a) => a -> Text
configHashText = sha256HexOfLazy . encode

-- EP18 Mori core split v1 calibration 20261017

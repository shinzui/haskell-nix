{-# LANGUAGE TemplateHaskell #-}

-- | Help topics for the CLI
module Rei.Cli.Commands.Help
  ( HelpCommand (..),
    helpCommandParser,
    handleHelpCommand,
  )
where

import Data.FileEmbed (embedStringFile)
import Data.Foldable (forM_)
import Data.List (find)
import Data.Text qualified as T
import Data.Text.IO qualified as TIO
import Options.Applicative
import Rei.Cli.Fzf (Candidate (..), FzfResult (..), detectFzfConfig, isFzfAvailable, runFzf, withHeader, withPreview, withPrompt)
import Rei.Cli.Pretty (bold, dim)
import Rei.Prelude

--------------------------------------------------------------------------------
-- Help Topics
--------------------------------------------------------------------------------

-- | A help topic with its name, description, and content
data HelpTopic = HelpTopic
  { topicName :: !Text,
    topicDescription :: !Text,
    topicContent :: !Text
  }

-- | All available help topics
helpTopics :: [HelpTopic]
helpTopics =
  [ HelpTopic "time" "Understanding time formats and the --at flag" timeTopicContent,
    HelpTopic "custom-properties" "Extending entities with custom metadata fields" customPropertiesTopicContent,
    HelpTopic "dashboard" "Configurable intention panels in the today command" dashboardTopicContent,
    HelpTopic "intention-filtering" "Filtering options for intention list command" intentionFilteringTopicContent,
    HelpTopic "state-machines" "Workflow tracking with state machine properties" stateMachinesTopicContent,
    HelpTopic "views" "Reusable multi-section configurations for displaying intentions" viewsTopicContent,
    HelpTopic "collections" "Curated groups of notes, links, and documents" collectionsTopicContent,
    HelpTopic "journal-entries" "Daily tracking with journal entry properties" journalEntriesTopicContent,
    HelpTopic "disruptions" "Tracking recurring interruptions and their patterns" disruptionsTopicContent,
    HelpTopic "templates" "Template syntax, helpers, and workspace customization" templatesTopicContent,
    HelpTopic "cycles" "Focus cycles, daily adherence, and cycle reports" cyclesTopicContent,
    HelpTopic "config" "Configuration file and environment variable reference" configTopicContent,
    HelpTopic "review-checkpoints" "Structured review workflow for agent and human work" reviewCheckpointsTopicContent,
    HelpTopic "agent-sessions" "Agent focus modes, sessions, memory, and interactive mode" agentSessionsTopicContent,
    HelpTopic "delegation" "Delegating intentions to agents with scope and autonomy" delegationTopicContent,
    HelpTopic "multi-agent-orchestration" "Scheduled and event-triggered agent work" multiAgentOrchestrationTopicContent,
    HelpTopic "agent-memory" "Agent memory types, anchors, lifecycle, and supersession" agentMemoryTopicContent,
    HelpTopic "agent-memory-filesystem" "Workspace markdown projection of agent memories" agentMemoryFilesystemTopicContent,
    HelpTopic "agent-schedules" "Automated recurring and event-triggered agent work" agentSchedulesTopicContent,
    HelpTopic "edges" "Typed relationships between entities via predicates" edgesTopicContent,
    HelpTopic "topics" "First-class subjects, attachments, and ontology queries" topicsTopicContent,
    HelpTopic "projects" "Projects as typed topics: scope, review cadence, and Mori sync" projectsTopicContent,
    HelpTopic "reminders" "Scheduling, triage, and the reminders Rei creates for you" remindersTopicContent,
    HelpTopic "kit" "Installing and managing skills and subagents" kitTopicContent
  ]

-- | Embedded topic content
timeTopicContent :: Text
timeTopicContent = $(embedStringFile "help/time.md")

customPropertiesTopicContent :: Text
customPropertiesTopicContent = $(embedStringFile "help/custom-properties.md")

intentionFilteringTopicContent :: Text
intentionFilteringTopicContent = $(embedStringFile "help/intention-filtering.md")

dashboardTopicContent :: Text
dashboardTopicContent = $(embedStringFile "help/dashboard.md")

stateMachinesTopicContent :: Text
stateMachinesTopicContent = $(embedStringFile "help/state-machines.md")

viewsTopicContent :: Text
viewsTopicContent = $(embedStringFile "help/views.md")

collectionsTopicContent :: Text
collectionsTopicContent = $(embedStringFile "help/collections.md")

journalEntriesTopicContent :: Text
journalEntriesTopicContent = $(embedStringFile "help/journal-entries.md")

disruptionsTopicContent :: Text
disruptionsTopicContent = $(embedStringFile "help/disruptions.md")

templatesTopicContent :: Text
templatesTopicContent = $(embedStringFile "help/templates.md")

cyclesTopicContent :: Text
cyclesTopicContent = $(embedStringFile "help/cycles.md")

configTopicContent :: Text
configTopicContent = $(embedStringFile "help/config.md")

reviewCheckpointsTopicContent :: Text
reviewCheckpointsTopicContent = $(embedStringFile "help/review-checkpoints.md")

agentSessionsTopicContent :: Text
agentSessionsTopicContent = $(embedStringFile "help/agent-sessions.md")

delegationTopicContent :: Text
delegationTopicContent = $(embedStringFile "help/delegation.md")

multiAgentOrchestrationTopicContent :: Text
multiAgentOrchestrationTopicContent = $(embedStringFile "help/multi-agent-orchestration.md")

agentMemoryTopicContent :: Text
agentMemoryTopicContent = $(embedStringFile "help/agent-memory.md")

agentMemoryFilesystemTopicContent :: Text
agentMemoryFilesystemTopicContent = $(embedStringFile "help/agent-memory-filesystem.md")

agentSchedulesTopicContent :: Text
agentSchedulesTopicContent = $(embedStringFile "help/agent-schedules.md")

edgesTopicContent :: Text
edgesTopicContent = $(embedStringFile "help/edges.md")

topicsTopicContent :: Text
topicsTopicContent = $(embedStringFile "help/topics.md")

projectsTopicContent :: Text
projectsTopicContent = $(embedStringFile "help/projects.md")

remindersTopicContent :: Text
remindersTopicContent = $(embedStringFile "help/reminders.md")

kitTopicContent :: Text
kitTopicContent = $(embedStringFile "help/kit.md")

-- | Find a topic by name
findTopic :: Text -> Maybe HelpTopic
findTopic name = find (\t -> topicName t == T.toLower name) helpTopics

--------------------------------------------------------------------------------
-- Data Types
--------------------------------------------------------------------------------

data HelpCommand
  = ListTopics
  | ListTopicsPlain
  | ShowTopic !Text
  deriving stock (Show)

--------------------------------------------------------------------------------
-- Parser
--------------------------------------------------------------------------------

helpCommandParser :: Parser HelpCommand
helpCommandParser =
  listFlag <|> showTopicParser <|> pure ListTopics
  where
    listFlag =
      flag'
        ListTopicsPlain
        ( long "list"
            <> short 'l'
            <> help "List all help topics without interactive selection"
        )

showTopicParser :: Parser HelpCommand
showTopicParser =
  ShowTopic
    <$> strArgument
      ( metavar "TOPIC"
          <> help ("Help topic to display: " <> T.unpack topicList)
      )
  where
    topicList = T.intercalate ", " (map topicName helpTopics)

--------------------------------------------------------------------------------
-- Handlers
--------------------------------------------------------------------------------

handleHelpCommand :: HelpCommand -> IO ()
handleHelpCommand = \case
  ListTopics -> selectOrListTopics
  ListTopicsPlain -> listTopics
  ShowTopic name -> showTopic name

selectOrListTopics :: IO ()
selectOrListTopics = do
  cfg <- detectFzfConfig
  if isFzfAvailable cfg
    then selectTopicWithFzf cfg
    else listTopics
  where
    selectTopicWithFzf cfg = do
      let candidates = map formatTopicCandidate helpTopics
          opts =
            withPrompt "Help topic> "
              <> withHeader "Select a guide (type to filter)"
              <> withPreview "rei help {2}"
      result <- runFzf cfg opts candidates
      case result of
        FzfSelected topic -> do
          TIO.putStrLn ""
          TIO.putStrLn $ topicContent topic
        FzfNoMatch -> TIO.putStrLn "No matching topics."
        FzfCancelled -> pure ()
        FzfError _ -> listTopics

    formatTopicCandidate topic =
      Candidate
        { candidateDisplay = padRight 30 (topicName topic) <> topicDescription topic,
          candidateValue = topic
        }

    padRight n t = t <> T.replicate (max 0 (n - T.length t)) " "

listTopics :: IO ()
listTopics = do
  TIO.putStrLn ""
  TIO.putStrLn $ bold "HELP TOPICS"
  TIO.putStrLn ""
  forM_ helpTopics $ \topic -> do
    TIO.putStrLn $ "  " <> bold (topicName topic) <> "        " <> topicDescription topic
  TIO.putStrLn ""
  TIO.putStrLn $ "Use " <> dim "'rei help <topic>'" <> " for detailed information."
  TIO.putStrLn $ "For command help, use " <> dim "'rei <command> --help'" <> "."
  TIO.putStrLn ""

showTopic :: Text -> IO ()
showTopic name = do
  case findTopic name of
    Just topic -> do
      TIO.putStrLn ""
      TIO.putStrLn $ topicContent topic
    Nothing -> do
      TIO.putStrLn $ "Unknown help topic: " <> name
      TIO.putStrLn ""
      let names = map topicName helpTopics
      TIO.putStrLn $ "Available topics: " <> T.intercalate ", " names

import hashlib,json,tarfile
from datetime import datetime,timezone
from pathlib import Path

repo=Path('/Users/shinzui/Keikaku/bokuno/haskell-nix')
app=Path('/tmp/ep18-mac-studio-resource-aware-v1')
verification=Path('/tmp/ep18-mac-studio-resource-aware-v1-verification')
evaluation=Path('/tmp/ep19-mac-studio-http2-evaluation-v1')
read=lambda p:json.loads(p.read_text())
summary=read(app/'summary.json')
verified=read(verification/'receipt.json')
evaluated=read(evaluation/'receipt.json')
assert len(summary['trials'])==10 and verified['status']=='passed'
assert len(evaluated['measurements'])==24 and evaluated['status'].startswith('measured')
assert summary['resource_policy_accepted']
assert all(r['host_resources']['assessment']['accepted'] for r in evaluated['measurements'])
appdriver=read(Path(str(app)+'-driver.json'))
assert appdriver['exit_code']==0 and appdriver['overlay_unchanged'] and all(appdriver['restored_sources'].values())
verification_driver=read(Path(str(verification)+'-driver.json'))
evaldriver=read(Path(str(evaluation)+'-driver.json'))
assert verification_driver['exit_code']==evaldriver['exit_code']==0

def observed(rows):
    samples=[s for row in rows for s in row['host_resources']['samples']]
    return {'samples':len(samples),'minimumCpuIdlePercent':min(s['cpu_idle_percent'] for s in samples),
            'minimumMemoryAvailabilityPercent':min(s['memory_free_percent'] for s in samples),
            'allResourceChecksPassed':all(row['host_resources']['assessment']['accepted'] for row in rows),
            'processNamesObserved':sorted({p['name'] for s in samples for p in s['compiler_and_test_processes']})}

files={}
# Store immutable graph nodes once and reconstruct every original byte stream.
# The verifier already proves shared-node equality; preserve its original hashes.
graph_nodes={}; graph_documents={}
for p in sorted(verification.glob('pair-*.graph.json')):
    document=read(p)
    assert 'derivations' in document
    for key,node in document['derivations'].items():
        assert key not in graph_nodes or graph_nodes[key]==node
        graph_nodes[key]=node
    envelope={k:v for k,v in document.items() if k!='derivations'}
    rebuilt=envelope | {'derivations':{k:graph_nodes[k] for k in document['derivations']}}
    assert (json.dumps(rebuilt,sort_keys=True)+'\n').encode()==p.read_bytes()
    graph_documents[p.name]={'envelope':envelope,'nodeKeys':list(document['derivations']),
                             'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
witness=verification/'graph-witness.json'
witness.write_text(json.dumps({'nodes':graph_nodes,'documents':graph_documents},sort_keys=True)+'\n')
for prefix,directory in [('application',app),('verification',verification),('evaluation',evaluation)]:
    for p in directory.iterdir():
        if p.is_file() and not p.name.endswith('.graph.json'):files[prefix+'/'+p.name]=p
for suffix in ['-protocol.json','-driver.json']:
    p=Path(str(app)+suffix);files['application/'+p.name]=p
for directory in [verification,evaluation]:
    p=Path(str(directory)+'-driver.json');files['execution/'+p.name]=p
p=Path(str(verification)+'.log');files['execution/'+p.name]=p
for name in ['scripts/benchmark_resources.py','scripts/measure-application-nix-builds.py','scripts/measure-recipe-evaluation.py','scripts/verify-application-build-pairs.py','scripts/tests/test_benchmark_resources.py','checks/fixtures/application-builds/split.nix','checks/fixtures/application-builds/owned.nix']:
    files['code/'+name]=repo/name
for name in ['ep19-http2-evaluation.nix','ep19-http2-consumer-immutable.nix','record-mac-studio-benchmarks.py']:
    files['execution/'+name]=Path('/tmp')/name
source=Path('/tmp/ep18-rei-resource-aware-split-v2')
files['sources/split-manifest.json']=source/'split-manifest.json'
for label in ['baseline','candidate']:
    for name in ['.mp4-pilot.json','nix/haskell-overlay.nix','nix/runtime-selection.json','rei-cli/src/Rei/Cli/Commands/Help.hs','rei-cli/rei-cli.cabal','flake.lock']:
        files['sources/'+label+'/'+name]=source/label/name
out=repo/'docs/evidence/masterplan-4'
out.mkdir(exist_ok=True)
archive=out/'mac-studio-benchmarks.raw.tar.gz'
if archive.exists():
    assert read(out/'mac-studio-benchmarks.json')['raw']['sha256']==hashlib.sha256(archive.read_bytes()).hexdigest()
with tarfile.open(archive,'w:gz',compresslevel=6) as bundle:
    for name,p in sorted(files.items()):bundle.add(p,arcname=name,recursive=False)
members={name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for name,p in sorted(files.items())}
result={
    'schemaVersion':1,'recordedAt':datetime.now(timezone.utc).isoformat(),
    'status':'Fresh Mac Studio campaigns complete; retain separate speed, stability, correctness and adoption outcomes.',
    'hardware':summary['hardware'],'resourcePolicy':summary['resource_policy'],
    'application':{
        'projectUri':summary['project_uri'],'sourceRevision':summary['source_revision'],
        'boundary':{'foundationModules':293,'remainingOriginalModules':4,'reviewedResources':7},
        'timings':summary['timings'],'savingFraction':summary['saving_fraction'],
        'timingThresholdPassed':summary['timing_threshold_passed'],'resourcePolicyAccepted':summary['resource_policy_accepted'],
        'compiledGhcEvents':{label:[sum(r['compiled_modules'].values()) for r in summary['trials'] if r['label']==label] for label in ['baseline','candidate']},
        'observedHostResources':observed(summary['trials']),
        'verification':{'status':verified['status'],'pairs':len(verified['pairs']),
            'unchangedSharedGraphNodes':verified['pairs'][0]['shared_graph_nodes_unchanged'],
            'unchangedSharedHaskellInstances':verified['pairs'][0]['shared_haskell_instances_unchanged'],
            'publicModules':293,'behaviorCommands':['--version','--help','help time','--bash-completion-script rei'],
            'completeSuiteEvidence':'../ep18/rei-cli-resource-aware-native-validation.json','completeSuiteCases':4241,
            'completeSuiteQualification':'Existing complete-suite receipt for the unchanged preparation/fixture; this fresh campaign verifies all five behavior/graph pairs and public imports.',
            'sourceScriptsMatchDeclaration':all(hashlib.sha256((repo/k).read_bytes()).hexdigest()==v for k,v in appdriver['script_hashes'].items())},
        'producerOverlayUnchanged':appdriver['overlay_unchanged'],'disposableSourcesRestored':appdriver['restored_sources'],
        'costObservations':{'pairedCampaignIncludingWarmupAndMonitoringSeconds':appdriver['elapsed_seconds'],
            'newBehaviorGraphValidationSeconds':verification_driver['elapsed_seconds'],
            'priorObservedSetupValidationAndExcludedCampaignsSeconds':1902.55,
            'perEditMedianSavingSeconds':summary['timings']['baseline']['median_seconds']-summary['timings']['candidate']['median_seconds'],
            'qualification':'Campaign/diagnostic costs are observations, not a complete production migration quote. Cached warmups do not measure fresh foundation creation. Producer workflow/ownership, complete cost and adoption remain open.'},
        'adoption':'Opt-in disposable pilot; no producer layout, pins or production defaults changed.'},
    'recipeEvaluation':{
        'projectUri':evaluated['project_uri'],'sourceRevision':evaluated['source_revision'],
        'baselineGeneration':evaluated['baseline_generation'],'candidateGeneration':evaluated['candidate_generation'],
        'results':evaluated['results'],'pairsPerScope':5,'measurementCount':len(evaluated['measurements']),
        'observedHostResources':observed(evaluated['measurements']),
        'targetBuilds':False,'builderPolicy':'Local and remote builders disabled; offline; warm existing source and converter outputs.',
        'identityEquality':'Each scoped http2 or independently checked Rei CLI result equals both warmups and all ten measured query results for that scope.',
        'priorNativeAndRollbackEvidence':'../ep19/targeted-http2-native-matrix.json',
        'campaignElapsedIncludingMonitoringSeconds':evaldriver['elapsed_seconds'],
        'adoption':'Regeneration/migration/verification/transfer cost and production support/adoption remain separate; no production selection changed.'},
    'previousExcludedCampaigns':'Remain excluded; none of their timing samples are merged into these fresh campaigns.',
    'raw':{'file':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':members,
           'graphWitness':'verification/graph-witness.json','reconstructedGraphs':len(graph_documents),
           'graphSerialization':'For each document, combine its envelope with derivations selected from nodes by nodeKeys; json.dumps(sort_keys=True) plus newline reproduces the original verifier graph SHA256 exactly.'},
}
(out/'mac-studio-benchmarks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['hardware','application','recipeEvaluation']},indent=2))
print('Raw archive bytes:',archive.stat().st_size)
